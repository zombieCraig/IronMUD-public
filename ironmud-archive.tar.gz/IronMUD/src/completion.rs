//! Tab completion engine for IronMUD
//!
//! Provides context-aware completion for:
//! - Command names
//! - Room vnums (for rgoto, redit, link, etc.)
//! - Item vnums (for oedit, ospawn, etc.)
//! - Mobile vnums (for medit, mspawn, etc.)
//! - Area prefixes (for aedit, spedit, etc.)

use unicode_width::UnicodeWidthStr;


/// Result of a completion request
#[derive(Debug, Clone)]
pub struct CompletionResult {
    /// List of possible completions
    pub completions: Vec<String>,
    /// Common prefix shared by all completions (for auto-complete)
    pub common_prefix: String,
    /// The type of completion being offered
    pub completion_type: CompletionType,
    /// Original partial text that was completed
    pub partial: String,
}

impl CompletionResult {
    pub fn empty() -> Self {
        Self {
            completions: Vec::new(),
            common_prefix: String::new(),
            completion_type: CompletionType::None,
            partial: String::new(),
        }
    }

    pub fn new(completions: Vec<String>, partial: &str, completion_type: CompletionType) -> Self {
        let common_prefix = find_common_prefix(&completions);
        Self {
            completions,
            common_prefix,
            completion_type,
            partial: partial.to_string(),
        }
    }

    pub fn is_empty(&self) -> bool {
        self.completions.is_empty()
    }

    pub fn is_unique(&self) -> bool {
        self.completions.len() == 1
    }
}

/// Type of completion being offered
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum CompletionType {
    None,
    Command,
    RoomVnum,
    ItemVnum,
    MobileVnum,
    AreaPrefix,
    Direction,
    PlayerName,
    MeditSubcommand,
    TriggerAction,
    TriggerType,
    TriggerScript,
    OeditSubcommand,
    ItemTriggerAction,
    ItemTriggerType,
    ItemType,
    ReditSubcommand,
    RoomTriggerAction,
    RoomTriggerType,
    RoomFlag,
    ExtraDescAction,
    AeditSubcommand,
    PermissionLevel,
    SpeditSubcommand,
    SpawnEntityType,
    SetSubcommand,
    RcopyCategory,
    SkillName,
    RecipeVnum,
    ReceditSubcommand,
    IngredientAction,
    ToolAction,
    ToolLocation,
    RecipeSkill,
    AdminSubcommand,
    TreatTarget,
    BodyPart,
    TreatableCondition,
    TransportVnum,
    TeditSubcommand,
    TransportType,
    StopAction,
    PressTarget,
    MobileTransportAction,
}

/// Context for command argument completion
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum ArgumentContext {
    /// No specific context - no completion available
    None,
    /// Room vnum argument
    RoomVnum,
    /// Item vnum argument
    ItemVnum,
    /// Mobile vnum argument
    MobileVnum,
    /// Area prefix argument
    AreaPrefix,
    /// Direction (north, south, etc.)
    Direction,
    /// Player name
    PlayerName,
    /// Skill name (cooking, crafting, etc.)
    SkillName,
    /// Recipe vnum argument
    RecipeVnum,
    /// Transport vnum argument
    TransportVnum,
}

/// Get the argument context for a command
pub fn get_argument_context(command: &str) -> ArgumentContext {
    match command.to_lowercase().as_str() {
        // Room vnum commands
        "rgoto" | "redit" | "rdelete" | "link" | "unlink" | "rcopy" => ArgumentContext::RoomVnum,

        // Item vnum commands
        "oedit" | "ospawn" | "idelete" => ArgumentContext::ItemVnum,

        // Mobile vnum commands
        "medit" | "mspawn" | "mdelete" | "mrefresh" => ArgumentContext::MobileVnum,

        // Area prefix commands
        "aedit" | "adelete" | "spedit" | "areset" | "acreate" => ArgumentContext::AreaPrefix,

        // Direction commands
        "go" | "dig" => ArgumentContext::Direction,

        // Player name commands
        "tell" | "whisper" => ArgumentContext::PlayerName,

        // Skill name commands
        "recipes" => ArgumentContext::SkillName,

        // Recipe vnum commands
        "recedit" | "recdelete" => ArgumentContext::RecipeVnum,

        // Transport vnum commands
        "tedit" => ArgumentContext::TransportVnum,

        _ => ArgumentContext::None,
    }
}

/// Directions for movement
pub const DIRECTIONS: &[&str] = &[
    "north", "south", "east", "west", "up", "down",
    "northeast", "northwest", "southeast", "southwest",
];

/// Skill names for crafting/cooking
pub const SKILL_NAMES: &[&str] = &[
    "cooking", "crafting", "fishing", "foraging",
];

/// Medit subcommands
pub const MEDIT_SUBCOMMANDS: &[&str] = &[
    "name", "short", "long", "keywords", "level", "hp", "damage", "ac", "damtype",
    "stat", "flags", "flag", "prototype", "vnum", "dialogue", "dialogues",
    "rmdialogue", "spawn", "shop", "healer", "trigger", "transport",
];

/// Mobile transport route actions
pub const MOBILE_TRANSPORT_ACTIONS: &[&str] = &[
    "set", "fixed", "random", "permanent", "clear",
];

/// Trigger actions
pub const TRIGGER_ACTIONS: &[&str] = &[
    "list", "add", "remove", "enable", "disable", "chance", "interval", "test",
];

/// Trigger types
pub const TRIGGER_TYPES: &[&str] = &[
    "greet", "attack", "death", "say", "idle",
];

/// Template triggers
pub const TRIGGER_TEMPLATES: &[&str] = &[
    "@say_greeting", "@say_random", "@emote",
];

/// Oedit subcommands
pub const OEDIT_SUBCOMMANDS: &[&str] = &[
    "name", "short", "long", "keywords", "type", "wear", "ac", "protects", "weight", "value",
    "flags", "flag", "spawn", "damage", "damtype", "twohanded", "wskill",
    "capacity", "closed", "locked", "key",
    "liquid", "fill", "empty", "liqpoison", "liqeffect", "clearliqeffects",
    "nutrition", "spoil", "foodpoison", "foodeffect", "clearfoodeffects", "resetfresh",
    "level", "stat", "insulation", "category", "teaches", "transport",
    "prototype", "vnum", "trigger", "vending",
    "quality", "baituses", "weightreduction", "medical",
];

/// Item trigger actions
pub const ITEM_TRIGGER_ACTIONS: &[&str] = &[
    "list", "add", "remove", "enable", "disable", "chance", "test",
];

/// Item trigger types
pub const ITEM_TRIGGER_TYPES: &[&str] = &[
    "get", "drop", "use", "examine", "on_prompt",
];

/// Item types
pub const ITEM_TYPES: &[&str] = &[
    "armor", "weapon", "container", "liquid_container", "food", "key", "misc",
];

/// Redit subcommands
pub const REDIT_SUBCOMMANDS: &[&str] = &[
    "show", "title", "desc", "flags", "flag", "zone", "extra", "vnum", "area", "trigger",
    "door", "seasonal", "dynamic", "water", "catch", "create",
];

/// Room trigger actions
pub const ROOM_TRIGGER_ACTIONS: &[&str] = &[
    "list", "add", "remove", "enable", "disable", "interval", "chance", "test",
];

/// Room trigger types
pub const ROOM_TRIGGER_TYPES: &[&str] = &[
    "enter", "exit", "look", "periodic",
    "on_time_change", "on_weather_change", "on_season_change", "on_month_change",
];

/// Room flags
pub const ROOM_FLAGS: &[&str] = &[
    "dark", "no_mob", "indoors", "underwater", "city", "no_windows", "difficult_terrain", "dirt_floor",
];

/// Extra description actions
pub const EXTRA_DESC_ACTIONS: &[&str] = &[
    "list", "add", "edit", "remove",
];

/// Aedit subcommands
pub const AEDIT_SUBCOMMANDS: &[&str] = &[
    "show", "name", "desc", "prefix", "theme", "levels",
    "owner", "permission", "trust", "untrust", "trustees",
];

/// Permission levels
pub const PERMISSION_LEVELS: &[&str] = &[
    "owner_only", "trusted", "all_builders",
];

/// Spedit subcommands
pub const SPEDIT_SUBCOMMANDS: &[&str] = &[
    "list", "create", "delete", "enable", "disable", "max", "interval",
];

/// Spawn entity types
pub const SPAWN_ENTITY_TYPES: &[&str] = &[
    "mobile", "item",
];

/// Set command subcommands (available to all users)
pub const SET_SUBCOMMANDS_BASE: &[&str] = &["mxp", "color", "afk", "helpline"];

/// Set command subcommands (builder-only)
pub const SET_SUBCOMMANDS_BUILDER: &[&str] = &["roomflags", "builderdebug"];

/// Set command toggle values
pub const SET_TOGGLE_VALUES: &[&str] = &["on", "off"];

/// Rcopy categories
pub const RCOPY_CATEGORIES: &[&str] = &[
    "all", "flags", "desc", "seasonal", "triggers", "water", "catch", "doors", "extra",
];

/// Recedit subcommands
pub const RECEDIT_SUBCOMMANDS: &[&str] = &[
    "name", "vnum", "skill", "level", "autolearn", "difficulty", "xp", "output",
    "ingredient", "tool",
];

/// Recipe ingredient actions
pub const INGREDIENT_ACTIONS: &[&str] = &["list", "add", "remove"];

/// Recipe tool actions
pub const TOOL_ACTIONS: &[&str] = &["list", "add", "remove"];

/// Admin subcommands
pub const ADMIN_SUBCOMMANDS: &[&str] = &[
    "kick", "summon", "heal", "settime", "broadcast", "shutdown", "cancel", "god", "help",
];

/// Recipe tool locations
pub const TOOL_LOCATIONS: &[&str] = &["inv", "inventory", "room", "either"];

/// Recipe skills
pub const RECIPE_SKILLS: &[&str] = &["cooking", "crafting"];

/// Tedit subcommands
pub const TEDIT_SUBCOMMANDS: &[&str] = &[
    "name", "vnum", "type", "interior", "traveltime", "schedule", "stop", "connect", "disconnect", "delete", "show",
];

/// Transport types
pub const TRANSPORT_TYPES: &[&str] = &[
    "elevator", "bus", "train", "ferry", "airship",
];

/// Transport schedule types
pub const SCHEDULE_TYPES: &[&str] = &["ondemand", "gametime"];

/// Transport stop actions
pub const STOP_ACTIONS: &[&str] = &["list", "add", "remove"];

/// Press targets (at stop)
pub const PRESS_TARGETS: &[&str] = &["button"];

/// Body parts for treat command (primary names)
pub const BODY_PARTS: &[&str] = &[
    "head", "neck", "torso",
    "leftarm", "rightarm", "leftleg", "rightleg",
    "lefthand", "righthand", "leftfoot", "rightfoot",
];

/// Treatable conditions for treat command
pub const TREATABLE_CONDITIONS: &[&str] = &[
    "illness", "hypothermia", "heat_exhaustion", "heat_stroke",
];

/// Combined body parts and conditions for treat command second argument
pub const TREAT_TARGETS: &[&str] = &[
    // Body parts
    "head", "neck", "torso",
    "leftarm", "rightarm", "leftleg", "rightleg",
    "lefthand", "righthand", "leftfoot", "rightfoot",
    // Conditions
    "illness", "hypothermia", "heat_exhaustion", "heat_stroke",
];

/// Complete a partial input line
pub fn complete(
    input: &str,
    cursor_pos: usize,
    available_commands: &[String],
    room_vnums: &[String],
    item_vnums: &[String],
    mobile_vnums: &[String],
    area_prefixes: &[String],
    recipe_vnums: &[String],
    transport_vnums: &[String],
    online_players: &[String],
    is_builder: bool,
) -> CompletionResult {
    // Get the portion of input up to cursor
    let input_to_cursor = if cursor_pos <= input.len() {
        &input[..cursor_pos]
    } else {
        input
    };

    // Split into words
    let words: Vec<&str> = input_to_cursor.split_whitespace().collect();

    // Check if we're completing a word or starting a new one
    let completing_word = !input_to_cursor.is_empty() && !input_to_cursor.ends_with(' ');

    match words.len() {
        0 => {
            // Empty input - return all commands
            CompletionResult::new(available_commands.to_vec(), "", CompletionType::Command)
        }
        1 if completing_word => {
            // Completing first word (command name)
            let partial = words[0].to_lowercase();
            let matches: Vec<String> = available_commands
                .iter()
                .filter(|cmd| cmd.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::Command)
        }
        _ => {
            // Completing an argument
            let command = words[0];
            let context = get_argument_context(command);
            let partial = if completing_word {
                words.last().unwrap_or(&"").to_lowercase()
            } else {
                String::new()
            };

            match context {
                ArgumentContext::RoomVnum => {
                    // For redit, provide context-aware completion (edits current room)
                    if command.to_lowercase() == "redit" {
                        return complete_redit(&words, completing_word);
                    }
                    // For rcopy, provide vnum + category completion
                    if command.to_lowercase() == "rcopy" {
                        return complete_rcopy(&words, completing_word, room_vnums);
                    }
                    // Default room vnum completion for rgoto, rdelete, link, unlink
                    let matches: Vec<String> = room_vnums
                        .iter()
                        .filter(|v| v.to_lowercase().starts_with(&partial))
                        .cloned()
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::RoomVnum)
                }
                ArgumentContext::ItemVnum => {
                    // For oedit, provide context-aware completion based on position
                    if command.to_lowercase() == "oedit" {
                        return complete_oedit(&words, completing_word, item_vnums, transport_vnums);
                    }
                    // Default item vnum completion for ospawn, idelete
                    let matches: Vec<String> = item_vnums
                        .iter()
                        .filter(|v| v.to_lowercase().starts_with(&partial))
                        .cloned()
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::ItemVnum)
                }
                ArgumentContext::MobileVnum => {
                    // For medit, provide context-aware completion based on position
                    if command.to_lowercase() == "medit" {
                        return complete_medit(&words, completing_word, mobile_vnums, transport_vnums);
                    }
                    // Default mobile vnum completion for mspawn, mdelete
                    let matches: Vec<String> = mobile_vnums
                        .iter()
                        .filter(|v| v.to_lowercase().starts_with(&partial))
                        .cloned()
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::MobileVnum)
                }
                ArgumentContext::AreaPrefix => {
                    // For aedit, provide context-aware completion based on position
                    if command.to_lowercase() == "aedit" {
                        return complete_aedit(&words, completing_word, area_prefixes);
                    }
                    // For spedit, provide context-aware completion based on position
                    if command.to_lowercase() == "spedit" {
                        return complete_spedit(&words, completing_word, area_prefixes, room_vnums, mobile_vnums, item_vnums);
                    }
                    // Default area prefix completion for adelete, areset, acreate
                    let matches: Vec<String> = area_prefixes
                        .iter()
                        .filter(|v| v.to_lowercase().starts_with(&partial))
                        .cloned()
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::AreaPrefix)
                }
                ArgumentContext::Direction => {
                    let matches: Vec<String> = DIRECTIONS
                        .iter()
                        .filter(|d| d.starts_with(&partial))
                        .map(|s| s.to_string())
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::Direction)
                }
                ArgumentContext::PlayerName => {
                    let matches: Vec<String> = online_players
                        .iter()
                        .filter(|p| p.to_lowercase().starts_with(&partial))
                        .cloned()
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::PlayerName)
                }
                ArgumentContext::SkillName => {
                    let matches: Vec<String> = SKILL_NAMES
                        .iter()
                        .filter(|s| s.starts_with(&partial))
                        .map(|s| s.to_string())
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::SkillName)
                }
                ArgumentContext::RecipeVnum => {
                    // For recedit, provide context-aware completion based on position
                    if command.to_lowercase() == "recedit" {
                        return complete_recedit(&words, completing_word, recipe_vnums, item_vnums);
                    }
                    // Default recipe vnum completion for recdelete
                    let matches: Vec<String> = recipe_vnums
                        .iter()
                        .filter(|v| v.to_lowercase().starts_with(&partial))
                        .cloned()
                        .collect();
                    CompletionResult::new(matches, &partial, CompletionType::RecipeVnum)
                }
                ArgumentContext::TransportVnum => {
                    // For tedit, provide context-aware completion based on position
                    return complete_tedit(&words, completing_word, transport_vnums, room_vnums);
                }
                ArgumentContext::None => {
                    // Handle "set" command specially
                    if command.to_lowercase() == "set" {
                        return complete_set(&words, completing_word, is_builder);
                    }
                    // Handle reclist command
                    if command.to_lowercase() == "reclist" {
                        return complete_reclist(&words, completing_word);
                    }
                    // Handle admin command
                    if command.to_lowercase() == "admin" {
                        return complete_admin(&words, completing_word, online_players);
                    }
                    // Handle treat command
                    if command.to_lowercase() == "treat" {
                        return complete_treat(&words, completing_word, online_players);
                    }
                    // Handle press command
                    if command.to_lowercase() == "press" {
                        return complete_press(&words, completing_word);
                    }
                    CompletionResult::empty()
                }
            }
        }
    }
}

/// Context-aware completion for medit command
fn complete_medit(words: &[&str], completing_word: bool, mobile_vnums: &[String], transport_vnums: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // medit <partial_vnum> - complete vnum
        2 if completing_word => {
            let matches: Vec<String> = mobile_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::MobileVnum)
        }
        // medit <vnum> - show all subcommands
        2 if !completing_word => {
            CompletionResult::new(
                MEDIT_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::MeditSubcommand,
            )
        }
        // medit <vnum> <partial_subcmd> - complete subcommand
        3 if completing_word => {
            let matches: Vec<String> = MEDIT_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::MeditSubcommand)
        }
        // medit <vnum> trigger - show all trigger actions
        3 if !completing_word && words[2].to_lowercase() == "trigger" => {
            CompletionResult::new(
                TRIGGER_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::TriggerAction,
            )
        }
        // medit <vnum> trigger <partial_action> - complete trigger action
        4 if completing_word && words[2].to_lowercase() == "trigger" => {
            let matches: Vec<String> = TRIGGER_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::TriggerAction)
        }
        // medit <vnum> trigger add - show all trigger types
        4 if !completing_word && words[2].to_lowercase() == "trigger" && words[3].to_lowercase() == "add" => {
            CompletionResult::new(
                TRIGGER_TYPES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::TriggerType,
            )
        }
        // medit <vnum> trigger add <partial_type> - complete trigger type
        5 if completing_word && words[2].to_lowercase() == "trigger" && words[3].to_lowercase() == "add" => {
            let matches: Vec<String> = TRIGGER_TYPES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::TriggerType)
        }
        // medit <vnum> trigger add <type> - show all templates
        5 if !completing_word && words[2].to_lowercase() == "trigger" && words[3].to_lowercase() == "add" => {
            CompletionResult::new(
                TRIGGER_TEMPLATES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::TriggerScript,
            )
        }
        // medit <vnum> trigger add <type> <partial_script> - complete template/script
        6 if completing_word && words[2].to_lowercase() == "trigger" && words[3].to_lowercase() == "add" => {
            let matches: Vec<String> = TRIGGER_TEMPLATES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::TriggerScript)
        }
        // medit <vnum> transport - show all transport actions
        3 if !completing_word && words[2].to_lowercase() == "transport" => {
            CompletionResult::new(
                MOBILE_TRANSPORT_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::MobileTransportAction,
            )
        }
        // medit <vnum> transport <partial_action> - complete transport action
        4 if completing_word && words[2].to_lowercase() == "transport" => {
            let matches: Vec<String> = MOBILE_TRANSPORT_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::MobileTransportAction)
        }
        // medit <vnum> transport set - show all transport vnums
        4 if !completing_word && words[2].to_lowercase() == "transport" && words[3].to_lowercase() == "set" => {
            CompletionResult::new(
                transport_vnums.to_vec(),
                "",
                CompletionType::TransportVnum,
            )
        }
        // medit <vnum> transport set <partial_vnum> - complete transport vnum
        5 if completing_word && words[2].to_lowercase() == "transport" && words[3].to_lowercase() == "set" => {
            let matches: Vec<String> = transport_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::TransportVnum)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for oedit command
fn complete_oedit(words: &[&str], completing_word: bool, item_vnums: &[String], transport_vnums: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // oedit <partial_vnum> - complete vnum
        2 if completing_word => {
            let matches: Vec<String> = item_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ItemVnum)
        }
        // oedit <vnum> - show all subcommands
        2 if !completing_word => {
            CompletionResult::new(
                OEDIT_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::OeditSubcommand,
            )
        }
        // oedit <vnum> <partial_subcmd> - complete subcommand
        3 if completing_word => {
            let matches: Vec<String> = OEDIT_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::OeditSubcommand)
        }
        // oedit <vnum> type - show all item types
        3 if !completing_word && words[2].to_lowercase() == "type" => {
            CompletionResult::new(
                ITEM_TYPES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ItemType,
            )
        }
        // oedit <vnum> type <partial_type> - complete item type
        4 if completing_word && words[2].to_lowercase() == "type" => {
            let matches: Vec<String> = ITEM_TYPES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ItemType)
        }
        // oedit <vnum> trigger - show all trigger actions
        3 if !completing_word && words[2].to_lowercase() == "trigger" => {
            CompletionResult::new(
                ITEM_TRIGGER_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ItemTriggerAction,
            )
        }
        // oedit <vnum> trigger <partial_action> - complete trigger action
        4 if completing_word && words[2].to_lowercase() == "trigger" => {
            let matches: Vec<String> = ITEM_TRIGGER_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ItemTriggerAction)
        }
        // oedit <vnum> trigger add - show all trigger types
        4 if !completing_word && words[2].to_lowercase() == "trigger" && words[3].to_lowercase() == "add" => {
            CompletionResult::new(
                ITEM_TRIGGER_TYPES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ItemTriggerType,
            )
        }
        // oedit <vnum> trigger add <partial_type> - complete trigger type
        5 if completing_word && words[2].to_lowercase() == "trigger" && words[3].to_lowercase() == "add" => {
            let matches: Vec<String> = ITEM_TRIGGER_TYPES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ItemTriggerType)
        }
        // oedit <vnum> transport - show all transport vnums
        3 if !completing_word && words[2].to_lowercase() == "transport" => {
            let mut matches: Vec<String> = transport_vnums.to_vec();
            matches.push("clear".to_string());
            CompletionResult::new(matches, "", CompletionType::TransportVnum)
        }
        // oedit <vnum> transport <partial> - complete transport vnum
        4 if completing_word && words[2].to_lowercase() == "transport" => {
            let mut matches: Vec<String> = transport_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            if "clear".starts_with(&partial) {
                matches.push("clear".to_string());
            }
            CompletionResult::new(matches, &partial, CompletionType::TransportVnum)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for redit command (edits current room)
fn complete_redit(words: &[&str], completing_word: bool) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // redit - show all subcommands
        1 if !completing_word => {
            CompletionResult::new(
                REDIT_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ReditSubcommand,
            )
        }
        // redit <partial_subcmd> - complete subcommand
        2 if completing_word => {
            let matches: Vec<String> = REDIT_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ReditSubcommand)
        }
        // redit flag - show all flags
        2 if !completing_word && words[1].to_lowercase() == "flag" => {
            CompletionResult::new(
                ROOM_FLAGS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::RoomFlag,
            )
        }
        // redit flag <partial_flag> - complete flag name
        3 if completing_word && words[1].to_lowercase() == "flag" => {
            let matches: Vec<String> = ROOM_FLAGS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RoomFlag)
        }
        // redit extra - show extra actions
        2 if !completing_word && words[1].to_lowercase() == "extra" => {
            CompletionResult::new(
                EXTRA_DESC_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ExtraDescAction,
            )
        }
        // redit extra <partial_action> - complete extra action
        3 if completing_word && words[1].to_lowercase() == "extra" => {
            let matches: Vec<String> = EXTRA_DESC_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ExtraDescAction)
        }
        // redit trigger - show trigger actions
        2 if !completing_word && words[1].to_lowercase() == "trigger" => {
            CompletionResult::new(
                ROOM_TRIGGER_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::RoomTriggerAction,
            )
        }
        // redit trigger <partial_action> - complete trigger action
        3 if completing_word && words[1].to_lowercase() == "trigger" => {
            let matches: Vec<String> = ROOM_TRIGGER_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RoomTriggerAction)
        }
        // redit trigger add - show trigger types
        3 if !completing_word && words[1].to_lowercase() == "trigger" && words[2].to_lowercase() == "add" => {
            CompletionResult::new(
                ROOM_TRIGGER_TYPES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::RoomTriggerType,
            )
        }
        // redit trigger add <partial_type> - complete trigger type
        4 if completing_word && words[1].to_lowercase() == "trigger" && words[2].to_lowercase() == "add" => {
            let matches: Vec<String> = ROOM_TRIGGER_TYPES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RoomTriggerType)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for rcopy command
fn complete_rcopy(words: &[&str], completing_word: bool, room_vnums: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // rcopy <partial_vnum> - complete room vnum
        2 if completing_word => {
            let matches: Vec<String> = room_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RoomVnum)
        }
        // rcopy <vnum> - show categories
        2 if !completing_word => {
            CompletionResult::new(
                RCOPY_CATEGORIES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::RcopyCategory,
            )
        }
        // rcopy <vnum> <partial_category> - complete category
        3 if completing_word => {
            let matches: Vec<String> = RCOPY_CATEGORIES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RcopyCategory)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for aedit command
fn complete_aedit(words: &[&str], completing_word: bool, area_prefixes: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // aedit <partial_area> - complete area prefix
        2 if completing_word => {
            let matches: Vec<String> = area_prefixes
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::AreaPrefix)
        }
        // aedit <area> - show all subcommands
        2 if !completing_word => {
            CompletionResult::new(
                AEDIT_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::AeditSubcommand,
            )
        }
        // aedit <area> <partial_subcmd> - complete subcommand
        3 if completing_word => {
            let matches: Vec<String> = AEDIT_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::AeditSubcommand)
        }
        // aedit <area> permission - show all permission levels
        3 if !completing_word && words[2].to_lowercase() == "permission" => {
            CompletionResult::new(
                PERMISSION_LEVELS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::PermissionLevel,
            )
        }
        // aedit <area> permission <partial_level> - complete permission level
        4 if completing_word && words[2].to_lowercase() == "permission" => {
            let matches: Vec<String> = PERMISSION_LEVELS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::PermissionLevel)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for spedit command
/// Syntax: spedit <area> create <room> <type> <vnum> <max> <interval>
fn complete_spedit(
    words: &[&str],
    completing_word: bool,
    area_prefixes: &[String],
    room_vnums: &[String],
    mobile_vnums: &[String],
    item_vnums: &[String],
) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // spedit <partial_area> - complete area prefix
        2 if completing_word => {
            let matches: Vec<String> = area_prefixes
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::AreaPrefix)
        }
        // spedit <area> - show all subcommands
        2 if !completing_word => {
            CompletionResult::new(
                SPEDIT_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::SpeditSubcommand,
            )
        }
        // spedit <area> <partial_subcmd> - complete subcommand
        3 if completing_word => {
            let matches: Vec<String> = SPEDIT_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::SpeditSubcommand)
        }
        // spedit <area> create - show room vnums (including "." for current room)
        3 if !completing_word && words[2].to_lowercase() == "create" => {
            let mut matches: Vec<String> = vec![".".to_string()];
            matches.extend(room_vnums.iter().cloned());
            CompletionResult::new(matches, "", CompletionType::RoomVnum)
        }
        // spedit <area> create <partial_room> - complete room vnum
        4 if completing_word && words[2].to_lowercase() == "create" => {
            let mut matches: Vec<String> = if ".".starts_with(&partial) {
                vec![".".to_string()]
            } else {
                vec![]
            };
            matches.extend(
                room_vnums
                    .iter()
                    .filter(|v| v.to_lowercase().starts_with(&partial))
                    .cloned()
            );
            CompletionResult::new(matches, &partial, CompletionType::RoomVnum)
        }
        // spedit <area> create <room> - show entity types
        4 if !completing_word && words[2].to_lowercase() == "create" => {
            CompletionResult::new(
                SPAWN_ENTITY_TYPES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::SpawnEntityType,
            )
        }
        // spedit <area> create <room> <partial_type> - complete entity type
        5 if completing_word && words[2].to_lowercase() == "create" => {
            let matches: Vec<String> = SPAWN_ENTITY_TYPES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::SpawnEntityType)
        }
        // spedit <area> create <room> mobile - complete mobile vnums
        5 if !completing_word && words[2].to_lowercase() == "create" && words[4].to_lowercase() == "mobile" => {
            CompletionResult::new(mobile_vnums.to_vec(), "", CompletionType::MobileVnum)
        }
        // spedit <area> create <room> mobile <partial_vnum> - complete mobile vnum
        6 if completing_word && words[2].to_lowercase() == "create" && words[4].to_lowercase() == "mobile" => {
            let matches: Vec<String> = mobile_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::MobileVnum)
        }
        // spedit <area> create <room> item - complete item vnums
        5 if !completing_word && words[2].to_lowercase() == "create" && words[4].to_lowercase() == "item" => {
            CompletionResult::new(item_vnums.to_vec(), "", CompletionType::ItemVnum)
        }
        // spedit <area> create <room> item <partial_vnum> - complete item vnum
        6 if completing_word && words[2].to_lowercase() == "create" && words[4].to_lowercase() == "item" => {
            let matches: Vec<String> = item_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ItemVnum)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for set command
fn complete_set(words: &[&str], completing_word: bool, is_builder: bool) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    // Build available settings based on permissions
    let mut available: Vec<&str> = SET_SUBCOMMANDS_BASE.to_vec();
    if is_builder {
        available.extend(SET_SUBCOMMANDS_BUILDER);
    }

    match words.len() {
        // set - show all available settings
        1 if !completing_word => {
            CompletionResult::new(
                available.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::SetSubcommand,
            )
        }
        // set <partial_setting> - complete setting name
        2 if completing_word => {
            let matches: Vec<String> = available
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::SetSubcommand)
        }
        // set <setting> - show on/off options
        2 if !completing_word => {
            CompletionResult::new(
                SET_TOGGLE_VALUES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::SetSubcommand,
            )
        }
        // set <setting> <partial_value> - complete on/off
        3 if completing_word => {
            let matches: Vec<String> = SET_TOGGLE_VALUES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::SetSubcommand)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for recedit command
fn complete_recedit(words: &[&str], completing_word: bool, recipe_vnums: &[String], item_vnums: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // recedit <partial_vnum> - complete recipe vnum
        2 if completing_word => {
            let matches: Vec<String> = recipe_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RecipeVnum)
        }
        // recedit <vnum> - show all subcommands
        2 if !completing_word => {
            CompletionResult::new(
                RECEDIT_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ReceditSubcommand,
            )
        }
        // recedit <vnum> <partial_subcmd> - complete subcommand
        3 if completing_word => {
            let matches: Vec<String> = RECEDIT_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ReceditSubcommand)
        }
        // recedit <vnum> skill - show skill types
        3 if !completing_word && words[2].to_lowercase() == "skill" => {
            CompletionResult::new(
                RECIPE_SKILLS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::RecipeSkill,
            )
        }
        // recedit <vnum> output - show item vnums (hint)
        3 if !completing_word && words[2].to_lowercase() == "output" => {
            CompletionResult::new(
                item_vnums.to_vec(),
                "",
                CompletionType::ItemVnum,
            )
        }
        // recedit <vnum> skill <partial> - complete skill
        4 if completing_word && words[2].to_lowercase() == "skill" => {
            let matches: Vec<String> = RECIPE_SKILLS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RecipeSkill)
        }
        // recedit <vnum> output <partial_item_vnum> - complete item vnum
        4 if completing_word && words[2].to_lowercase() == "output" => {
            let matches: Vec<String> = item_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ItemVnum)
        }
        // recedit <vnum> ingredient - show actions
        3 if !completing_word && words[2].to_lowercase() == "ingredient" => {
            CompletionResult::new(
                INGREDIENT_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::IngredientAction,
            )
        }
        // recedit <vnum> ingredient <partial> - complete action
        4 if completing_word && words[2].to_lowercase() == "ingredient" => {
            let matches: Vec<String> = INGREDIENT_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::IngredientAction)
        }
        // recedit <vnum> ingredient add - show hint about @liquid: syntax
        4 if !completing_word && words[2].to_lowercase() == "ingredient" && words[3].to_lowercase() == "add" => {
            // Can't complete vnums/categories, but show hint
            CompletionResult::new(
                vec!["<vnum>".to_string(), "@<category>".to_string(), "@liquid:<type>".to_string()],
                "",
                CompletionType::IngredientAction,
            )
        }
        // recedit <vnum> tool - show actions
        3 if !completing_word && words[2].to_lowercase() == "tool" => {
            CompletionResult::new(
                TOOL_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ToolAction,
            )
        }
        // recedit <vnum> tool <partial> - complete action
        4 if completing_word && words[2].to_lowercase() == "tool" => {
            let matches: Vec<String> = TOOL_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ToolAction)
        }
        // recedit <vnum> tool add <spec> - show locations
        5 if !completing_word && words[2].to_lowercase() == "tool" && words[3].to_lowercase() == "add" => {
            CompletionResult::new(
                TOOL_LOCATIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::ToolLocation,
            )
        }
        // recedit <vnum> tool add <spec> <partial_loc> - complete location
        6 if completing_word && words[2].to_lowercase() == "tool" && words[3].to_lowercase() == "add" => {
            let matches: Vec<String> = TOOL_LOCATIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::ToolLocation)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for reclist command
fn complete_reclist(words: &[&str], completing_word: bool) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // reclist - show skill filters
        1 if !completing_word => {
            CompletionResult::new(
                RECIPE_SKILLS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::RecipeSkill,
            )
        }
        // reclist <partial_skill> - complete skill filter
        2 if completing_word => {
            let matches: Vec<String> = RECIPE_SKILLS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RecipeSkill)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for admin command
fn complete_admin(words: &[&str], completing_word: bool, online_players: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // admin - show all subcommands
        1 if !completing_word => {
            CompletionResult::new(
                ADMIN_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::AdminSubcommand,
            )
        }
        // admin <partial_subcommand> - complete subcommand
        2 if completing_word => {
            let matches: Vec<String> = ADMIN_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::AdminSubcommand)
        }
        // admin <subcommand> - show player names for kick/summon/heal
        2 if !completing_word => {
            let subcommand = words[1].to_lowercase();
            if subcommand == "kick" || subcommand == "summon" || subcommand == "heal" {
                CompletionResult::new(
                    online_players.to_vec(),
                    "",
                    CompletionType::PlayerName,
                )
            } else {
                CompletionResult::empty()
            }
        }
        // admin <subcommand> <partial_player> - complete player name
        3 if completing_word => {
            let subcommand = words[1].to_lowercase();
            if subcommand == "kick" || subcommand == "summon" || subcommand == "heal" {
                let matches: Vec<String> = online_players
                    .iter()
                    .filter(|p| p.to_lowercase().starts_with(&partial))
                    .cloned()
                    .collect();
                CompletionResult::new(matches, &partial, CompletionType::PlayerName)
            } else {
                CompletionResult::empty()
            }
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for treat command
/// Syntax: treat <target> [body_part or condition]
fn complete_treat(words: &[&str], completing_word: bool, online_players: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // treat - show "self" and online players
        1 if !completing_word => {
            let mut matches = vec!["self".to_string()];
            matches.extend(online_players.iter().cloned());
            CompletionResult::new(matches, "", CompletionType::TreatTarget)
        }
        // treat <partial_target> - complete "self" or player name
        2 if completing_word => {
            let mut matches: Vec<String> = Vec::new();
            if "self".starts_with(&partial) {
                matches.push("self".to_string());
            }
            matches.extend(
                online_players
                    .iter()
                    .filter(|p| p.to_lowercase().starts_with(&partial))
                    .cloned()
            );
            CompletionResult::new(matches, &partial, CompletionType::TreatTarget)
        }
        // treat <target> - show body parts and conditions
        2 if !completing_word => {
            CompletionResult::new(
                TREAT_TARGETS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::BodyPart,
            )
        }
        // treat <target> <partial_part_or_condition> - complete body part or condition
        3 if completing_word => {
            let matches: Vec<String> = TREAT_TARGETS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            // Determine appropriate completion type based on what's matching
            let completion_type = if matches.iter().all(|m| TREATABLE_CONDITIONS.contains(&m.as_str())) {
                CompletionType::TreatableCondition
            } else if matches.iter().all(|m| BODY_PARTS.contains(&m.as_str())) {
                CompletionType::BodyPart
            } else {
                CompletionType::BodyPart // Mixed results default to BodyPart
            };
            CompletionResult::new(matches, &partial, completion_type)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for tedit command
/// Syntax: tedit <vnum> <subcommand> [args...]
/// Or: tedit create <vnum>
fn complete_tedit(words: &[&str], completing_word: bool, transport_vnums: &[String], room_vnums: &[String]) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // tedit <partial_vnum_or_create> - complete vnum or "create"
        2 if completing_word => {
            let mut matches: Vec<String> = Vec::new();
            // Include "create" as an option
            if "create".starts_with(&partial) {
                matches.push("create".to_string());
            }
            // Include transport vnums
            matches.extend(
                transport_vnums
                    .iter()
                    .filter(|v| v.to_lowercase().starts_with(&partial))
                    .cloned()
            );
            CompletionResult::new(matches, &partial, CompletionType::TransportVnum)
        }
        // tedit - show "create" and all vnums
        1 if !completing_word => {
            let mut matches = vec!["create".to_string()];
            matches.extend(transport_vnums.iter().cloned());
            CompletionResult::new(matches, "", CompletionType::TransportVnum)
        }
        // tedit <vnum> - show all subcommands (if not "create")
        2 if !completing_word => {
            if words[1].to_lowercase() == "create" {
                // tedit create - need a vnum for the new transport
                CompletionResult::empty()
            } else {
                CompletionResult::new(
                    TEDIT_SUBCOMMANDS.iter().map(|s| s.to_string()).collect(),
                    "",
                    CompletionType::TeditSubcommand,
                )
            }
        }
        // tedit <vnum> <partial_subcmd> - complete subcommand
        3 if completing_word => {
            let matches: Vec<String> = TEDIT_SUBCOMMANDS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::TeditSubcommand)
        }
        // tedit <vnum> type - show transport types
        3 if !completing_word && words[2].to_lowercase() == "type" => {
            CompletionResult::new(
                TRANSPORT_TYPES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::TransportType,
            )
        }
        // tedit <vnum> type <partial_type> - complete transport type
        4 if completing_word && words[2].to_lowercase() == "type" => {
            let matches: Vec<String> = TRANSPORT_TYPES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::TransportType)
        }
        // tedit <vnum> schedule - show schedule types
        3 if !completing_word && words[2].to_lowercase() == "schedule" => {
            CompletionResult::new(
                SCHEDULE_TYPES.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::TeditSubcommand,
            )
        }
        // tedit <vnum> schedule <partial_type> - complete schedule type
        4 if completing_word && words[2].to_lowercase() == "schedule" => {
            let matches: Vec<String> = SCHEDULE_TYPES
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::TeditSubcommand)
        }
        // tedit <vnum> stop - show stop actions
        3 if !completing_word && words[2].to_lowercase() == "stop" => {
            CompletionResult::new(
                STOP_ACTIONS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::StopAction,
            )
        }
        // tedit <vnum> stop <partial_action> - complete stop action
        4 if completing_word && words[2].to_lowercase() == "stop" => {
            let matches: Vec<String> = STOP_ACTIONS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::StopAction)
        }
        // tedit <vnum> stop add - show room vnums
        4 if !completing_word && words[2].to_lowercase() == "stop" && words[3].to_lowercase() == "add" => {
            CompletionResult::new(room_vnums.to_vec(), "", CompletionType::RoomVnum)
        }
        // tedit <vnum> stop add <partial_room> - complete room vnum
        5 if completing_word && words[2].to_lowercase() == "stop" && words[3].to_lowercase() == "add" => {
            let matches: Vec<String> = room_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RoomVnum)
        }
        // tedit <vnum> interior - show room vnums
        3 if !completing_word && words[2].to_lowercase() == "interior" => {
            CompletionResult::new(room_vnums.to_vec(), "", CompletionType::RoomVnum)
        }
        // tedit <vnum> interior <partial_room> - complete room vnum
        4 if completing_word && words[2].to_lowercase() == "interior" => {
            let matches: Vec<String> = room_vnums
                .iter()
                .filter(|v| v.to_lowercase().starts_with(&partial))
                .cloned()
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::RoomVnum)
        }
        _ => CompletionResult::empty(),
    }
}

/// Context-aware completion for press command
/// At a transport stop: press button
/// Inside a transport: press <number> or press <stop_name>
fn complete_press(words: &[&str], completing_word: bool) -> CompletionResult {
    let partial = if completing_word {
        words.last().unwrap_or(&"").to_lowercase()
    } else {
        String::new()
    };

    match words.len() {
        // press - show "button" (stop names would need runtime data)
        1 if !completing_word => {
            CompletionResult::new(
                PRESS_TARGETS.iter().map(|s| s.to_string()).collect(),
                "",
                CompletionType::PressTarget,
            )
        }
        // press <partial> - complete "button"
        2 if completing_word => {
            let matches: Vec<String> = PRESS_TARGETS
                .iter()
                .filter(|s| s.starts_with(&partial))
                .map(|s| s.to_string())
                .collect();
            CompletionResult::new(matches, &partial, CompletionType::PressTarget)
        }
        _ => CompletionResult::empty(),
    }
}

/// Find the longest common prefix among a list of strings
fn find_common_prefix(strings: &[String]) -> String {
    if strings.is_empty() {
        return String::new();
    }
    if strings.len() == 1 {
        return strings[0].clone();
    }

    let first = &strings[0];
    let mut prefix_len = first.len();

    for s in &strings[1..] {
        let common_len = first
            .chars()
            .zip(s.chars())
            .take_while(|(a, b)| a.eq_ignore_ascii_case(b))
            .count();
        prefix_len = prefix_len.min(common_len);
    }

    first[..prefix_len].to_string()
}

/// Format completion result for display
pub fn format_completions(result: &CompletionResult, max_width: u16) -> String {
    if result.is_empty() {
        return String::new();
    }

    if result.is_unique() {
        // Single match - no need to display list
        return String::new();
    }

    // Calculate column width using display width for proper emoji/CJK handling
    let max_item_width = result.completions.iter().map(|s| s.width()).max().unwrap_or(0);
    let col_width = max_item_width + 2; // Add padding
    let cols = ((max_width as usize) / col_width).max(1);

    // Format as columns with proper padding for display width
    let mut lines = Vec::new();
    for chunk in result.completions.chunks(cols) {
        let line: Vec<String> = chunk
            .iter()
            .map(|s| {
                // Pad to col_width based on display width, not byte length
                let display_len = s.width();
                let padding = col_width.saturating_sub(display_len);
                format!("{}{}", s, " ".repeat(padding))
            })
            .collect();
        lines.push(line.join(""));
    }

    lines.join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_complete_command() {
        let commands = vec![
            "look".to_string(),
            "login".to_string(),
            "logout".to_string(),
            "help".to_string(),
        ];

        let result = complete("lo", 2, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert_eq!(result.completions.len(), 3);
        assert!(result.completions.contains(&"look".to_string()));
        assert!(result.completions.contains(&"login".to_string()));
        assert!(result.completions.contains(&"logout".to_string()));
        assert_eq!(result.completion_type, CompletionType::Command);
    }

    #[test]
    fn test_complete_room_vnum() {
        let commands = vec!["rgoto".to_string()];
        let room_vnums = vec![
            "town:square".to_string(),
            "town:tavern".to_string(),
            "forest:entrance".to_string(),
        ];

        let result = complete("rgoto town:", 11, &commands, &room_vnums, &[], &[], &[], &[], &[], &[], false);
        assert_eq!(result.completions.len(), 2);
        assert!(result.completions.contains(&"town:square".to_string()));
        assert!(result.completions.contains(&"town:tavern".to_string()));
        assert_eq!(result.completion_type, CompletionType::RoomVnum);
    }

    #[test]
    fn test_common_prefix() {
        let strings = vec![
            "town:square".to_string(),
            "town:tavern".to_string(),
            "town:market".to_string(),
        ];
        assert_eq!(find_common_prefix(&strings), "town:");
    }

    #[test]
    fn test_empty_input() {
        let commands = vec!["look".to_string(), "help".to_string()];
        let result = complete("", 0, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert_eq!(result.completions.len(), 2);
    }

    #[test]
    fn test_direction_completion() {
        let commands = vec!["go".to_string()];
        let result = complete("go nor", 6, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert_eq!(result.completions.len(), 3); // north, northeast, northwest
        assert!(result.completions.contains(&"north".to_string()));
        assert!(result.completions.contains(&"northeast".to_string()));
        assert!(result.completions.contains(&"northwest".to_string()));
    }

    #[test]
    fn test_medit_subcommand_completion() {
        let commands = vec!["medit".to_string()];
        let mobile_vnums = vec!["town:guard".to_string()];

        // Complete subcommand after vnum
        let result = complete("medit town:guard tr", 19, &commands, &[], &[], &mobile_vnums, &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"trigger".to_string()));
        assert_eq!(result.completion_type, CompletionType::MeditSubcommand);
    }

    #[test]
    fn test_medit_trigger_action_completion() {
        let commands = vec!["medit".to_string()];
        let mobile_vnums = vec!["town:guard".to_string()];

        // Complete trigger action after "trigger"
        let result = complete("medit town:guard trigger a", 26, &commands, &[], &[], &mobile_vnums, &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"add".to_string()));
        assert_eq!(result.completion_type, CompletionType::TriggerAction);
    }

    #[test]
    fn test_medit_trigger_type_completion() {
        let commands = vec!["medit".to_string()];
        let mobile_vnums = vec!["town:guard".to_string()];

        // Complete trigger type after "add"
        let result = complete("medit town:guard trigger add gr", 31, &commands, &[], &[], &mobile_vnums, &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"greet".to_string()));
        assert_eq!(result.completion_type, CompletionType::TriggerType);
    }

    #[test]
    fn test_medit_trigger_template_completion() {
        let commands = vec!["medit".to_string()];
        let mobile_vnums = vec!["town:guard".to_string()];

        // Complete template after trigger type
        let result = complete("medit town:guard trigger add greet @say", 39, &commands, &[], &[], &mobile_vnums, &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"@say_greeting".to_string()));
        assert!(result.completions.contains(&"@say_random".to_string()));
        assert_eq!(result.completion_type, CompletionType::TriggerScript);
    }

    #[test]
    fn test_oedit_subcommand_completion() {
        let commands = vec!["oedit".to_string()];
        let item_vnums = vec!["town:sword".to_string()];

        // Complete subcommand after vnum
        let result = complete("oedit town:sword ty", 19, &commands, &[], &item_vnums, &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"type".to_string()));
        assert_eq!(result.completion_type, CompletionType::OeditSubcommand);
    }

    #[test]
    fn test_oedit_type_completion() {
        let commands = vec!["oedit".to_string()];
        let item_vnums = vec!["town:sword".to_string()];

        // Complete item type after "type"
        let result = complete("oedit town:sword type ar", 24, &commands, &[], &item_vnums, &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"armor".to_string()));
        assert_eq!(result.completion_type, CompletionType::ItemType);
    }

    #[test]
    fn test_oedit_trigger_action_completion() {
        let commands = vec!["oedit".to_string()];
        let item_vnums = vec!["town:sword".to_string()];

        // Complete trigger action after "trigger"
        let result = complete("oedit town:sword trigger a", 26, &commands, &[], &item_vnums, &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"add".to_string()));
        assert_eq!(result.completion_type, CompletionType::ItemTriggerAction);
    }

    #[test]
    fn test_oedit_trigger_type_completion() {
        let commands = vec!["oedit".to_string()];
        let item_vnums = vec!["town:sword".to_string()];

        // Complete trigger type after "add"
        let result = complete("oedit town:sword trigger add ge", 31, &commands, &[], &item_vnums, &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"get".to_string()));
        assert_eq!(result.completion_type, CompletionType::ItemTriggerType);
    }

    #[test]
    fn test_redit_subcommand_completion() {
        let commands = vec!["redit".to_string()];

        // Complete subcommand
        let result = complete("redit tr", 8, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"trigger".to_string()));
        assert_eq!(result.completion_type, CompletionType::ReditSubcommand);
    }

    #[test]
    fn test_redit_flag_completion() {
        let commands = vec!["redit".to_string()];

        // Complete flag name after "flag"
        let result = complete("redit flag da", 13, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"dark".to_string()));
        assert_eq!(result.completion_type, CompletionType::RoomFlag);
    }

    #[test]
    fn test_redit_extra_action_completion() {
        let commands = vec!["redit".to_string()];

        // Complete extra action
        let result = complete("redit extra li", 14, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"list".to_string()));
        assert_eq!(result.completion_type, CompletionType::ExtraDescAction);
    }

    #[test]
    fn test_redit_trigger_action_completion() {
        let commands = vec!["redit".to_string()];

        // Complete trigger action
        let result = complete("redit trigger a", 15, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"add".to_string()));
        assert_eq!(result.completion_type, CompletionType::RoomTriggerAction);
    }

    #[test]
    fn test_redit_trigger_type_completion() {
        let commands = vec!["redit".to_string()];

        // Complete trigger type after "add"
        let result = complete("redit trigger add en", 20, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"enter".to_string()));
        assert_eq!(result.completion_type, CompletionType::RoomTriggerType);
    }

    #[test]
    fn test_aedit_subcommand_completion() {
        let commands = vec!["aedit".to_string()];
        let area_prefixes = vec!["town".to_string()];

        // Complete subcommand after area
        let result = complete("aedit town pe", 13, &commands, &[], &[], &[], &area_prefixes, &[], &[], &[], false);
        assert!(result.completions.contains(&"permission".to_string()));
        assert_eq!(result.completion_type, CompletionType::AeditSubcommand);
    }

    #[test]
    fn test_aedit_permission_completion() {
        let commands = vec!["aedit".to_string()];
        let area_prefixes = vec!["town".to_string()];

        // Complete permission level
        let result = complete("aedit town permission ow", 24, &commands, &[], &[], &[], &area_prefixes, &[], &[], &[], false);
        assert!(result.completions.contains(&"owner_only".to_string()));
        assert_eq!(result.completion_type, CompletionType::PermissionLevel);
    }

    #[test]
    fn test_spedit_subcommand_completion() {
        let commands = vec!["spedit".to_string()];
        let area_prefixes = vec!["town".to_string()];

        // Complete subcommand after area
        let result = complete("spedit town cr", 14, &commands, &[], &[], &[], &area_prefixes, &[], &[], &[], false);
        assert!(result.completions.contains(&"create".to_string()));
        assert_eq!(result.completion_type, CompletionType::SpeditSubcommand);
    }

    #[test]
    fn test_spedit_room_vnum_completion() {
        let commands = vec!["spedit".to_string()];
        let area_prefixes = vec!["town".to_string()];
        let room_vnums = vec!["town:plaza".to_string(), "town:market".to_string()];

        // Complete room vnum after "create"
        let result = complete("spedit town create town:p", 25, &commands, &room_vnums, &[], &[], &area_prefixes, &[], &[], &[], false);
        assert!(result.completions.contains(&"town:plaza".to_string()));
        assert_eq!(result.completion_type, CompletionType::RoomVnum);
    }

    #[test]
    fn test_spedit_entity_type_completion() {
        let commands = vec!["spedit".to_string()];
        let area_prefixes = vec!["town".to_string()];
        let room_vnums = vec!["town:plaza".to_string()];

        // Complete entity type after "create <room>"
        let result = complete("spedit town create town:plaza mo", 32, &commands, &room_vnums, &[], &[], &area_prefixes, &[], &[], &[], false);
        assert!(result.completions.contains(&"mobile".to_string()));
        assert_eq!(result.completion_type, CompletionType::SpawnEntityType);
    }

    #[test]
    fn test_spedit_mobile_vnum_completion() {
        let commands = vec!["spedit".to_string()];
        let area_prefixes = vec!["town".to_string()];
        let room_vnums = vec!["town:plaza".to_string()];
        let mobile_vnums = vec!["town:guard".to_string(), "town:merchant".to_string()];

        // Complete mobile vnum after "create <room> mobile"
        let result = complete("spedit town create town:plaza mobile town:g", 43, &commands, &room_vnums, &[], &mobile_vnums, &area_prefixes, &[], &[], &[], false);
        assert!(result.completions.contains(&"town:guard".to_string()));
        assert_eq!(result.completion_type, CompletionType::MobileVnum);
    }

    #[test]
    fn test_spedit_item_vnum_completion() {
        let commands = vec!["spedit".to_string()];
        let area_prefixes = vec!["town".to_string()];
        let room_vnums = vec!["town:plaza".to_string()];
        let item_vnums = vec!["town:sword".to_string(), "town:shield".to_string()];

        // Complete item vnum after "create <room> item"
        let result = complete("spedit town create town:plaza item town:sw", 42, &commands, &room_vnums, &item_vnums, &[], &area_prefixes, &[], &[], &[], false);
        assert!(result.completions.contains(&"town:sword".to_string()));
        assert_eq!(result.completion_type, CompletionType::ItemVnum);
    }

    #[test]
    fn test_set_subcommand_completion_non_builder() {
        let commands = vec!["set".to_string()];

        // Non-builder should see mxp, color, and afk but NOT roomflags
        let result = complete("set ", 4, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"mxp".to_string()));
        assert!(result.completions.contains(&"color".to_string()));
        assert!(result.completions.contains(&"afk".to_string()));
        assert!(!result.completions.contains(&"roomflags".to_string()));
        assert_eq!(result.completion_type, CompletionType::SetSubcommand);
    }

    #[test]
    fn test_set_subcommand_completion_builder() {
        let commands = vec!["set".to_string()];

        // Builder should see all settings including roomflags
        let result = complete("set ", 4, &commands, &[], &[], &[], &[], &[], &[], &[], true);
        assert!(result.completions.contains(&"mxp".to_string()));
        assert!(result.completions.contains(&"color".to_string()));
        assert!(result.completions.contains(&"afk".to_string()));
        assert!(result.completions.contains(&"roomflags".to_string()));
        assert_eq!(result.completion_type, CompletionType::SetSubcommand);
    }

    #[test]
    fn test_set_partial_completion() {
        let commands = vec!["set".to_string()];

        // Complete partial setting name
        let result = complete("set m", 5, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"mxp".to_string()));
        assert!(!result.completions.contains(&"color".to_string()));
        assert_eq!(result.completion_type, CompletionType::SetSubcommand);
    }

    #[test]
    fn test_set_toggle_value_completion() {
        let commands = vec!["set".to_string()];

        // After setting name, show on/off
        let result = complete("set mxp ", 8, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"on".to_string()));
        assert!(result.completions.contains(&"off".to_string()));
        assert_eq!(result.completion_type, CompletionType::SetSubcommand);
    }

    #[test]
    fn test_set_toggle_partial_completion() {
        let commands = vec!["set".to_string()];

        // Complete partial toggle value
        let result = complete("set mxp o", 9, &commands, &[], &[], &[], &[], &[], &[], &[], false);
        assert!(result.completions.contains(&"on".to_string()));
        assert!(result.completions.contains(&"off".to_string()));
        assert_eq!(result.completion_type, CompletionType::SetSubcommand);
    }

    #[test]
    fn test_treat_target_completion() {
        let commands = vec!["treat".to_string()];
        let online_players = vec!["Alice".to_string(), "Bob".to_string()];

        // After "treat" show self and online players
        let result = complete("treat ", 6, &commands, &[], &[], &[], &[], &[], &[], &online_players, false);
        assert!(result.completions.contains(&"self".to_string()));
        assert!(result.completions.contains(&"Alice".to_string()));
        assert!(result.completions.contains(&"Bob".to_string()));
        assert_eq!(result.completion_type, CompletionType::TreatTarget);
    }

    #[test]
    fn test_treat_target_partial_completion() {
        let commands = vec!["treat".to_string()];
        let online_players = vec!["Alice".to_string(), "Bob".to_string()];

        // Complete partial target
        let result = complete("treat se", 8, &commands, &[], &[], &[], &[], &[], &[], &online_players, false);
        assert!(result.completions.contains(&"self".to_string()));
        assert!(!result.completions.contains(&"Alice".to_string()));
        assert_eq!(result.completion_type, CompletionType::TreatTarget);
    }

    #[test]
    fn test_treat_body_part_completion() {
        let commands = vec!["treat".to_string()];
        let online_players = vec!["Alice".to_string()];

        // After target, show body parts and conditions
        let result = complete("treat self ", 11, &commands, &[], &[], &[], &[], &[], &[], &online_players, false);
        assert!(result.completions.contains(&"head".to_string()));
        assert!(result.completions.contains(&"torso".to_string()));
        assert!(result.completions.contains(&"hypothermia".to_string()));
        assert!(result.completions.contains(&"illness".to_string()));
        assert_eq!(result.completion_type, CompletionType::BodyPart);
    }

    #[test]
    fn test_treat_body_part_partial_completion() {
        let commands = vec!["treat".to_string()];
        let online_players = vec!["Alice".to_string()];

        // Complete partial body part
        let result = complete("treat self le", 13, &commands, &[], &[], &[], &[], &[], &[], &online_players, false);
        assert!(result.completions.contains(&"leftarm".to_string()));
        assert!(result.completions.contains(&"leftleg".to_string()));
        assert!(result.completions.contains(&"lefthand".to_string()));
        assert!(result.completions.contains(&"leftfoot".to_string()));
        assert!(!result.completions.contains(&"head".to_string()));
        assert_eq!(result.completion_type, CompletionType::BodyPart);
    }

    #[test]
    fn test_treat_condition_partial_completion() {
        let commands = vec!["treat".to_string()];
        let online_players = vec!["Alice".to_string()];

        // Complete partial condition - should get only conditions
        let result = complete("treat self heat", 15, &commands, &[], &[], &[], &[], &[], &[], &online_players, false);
        assert!(result.completions.contains(&"heat_exhaustion".to_string()));
        assert!(result.completions.contains(&"heat_stroke".to_string()));
        assert!(!result.completions.contains(&"head".to_string()));
        assert_eq!(result.completion_type, CompletionType::TreatableCondition);
    }
}
