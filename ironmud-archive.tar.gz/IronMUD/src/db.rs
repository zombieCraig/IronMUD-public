use anyhow::Result;
use sled::{Db as SledDb, Tree};
use std::path::Path;
use serde_json;
use std::sync::Arc; // Import Arc

use crate::{AreaData, CharacterData, ExtraDesc, ItemData, ItemLocation, ItemType, MobileData, Recipe, RoomData, RoomExits, RoomFlags, SpawnEntityType, SpawnPointData, TransportData, WaterType, STARTING_ROOM_ID};
use uuid::Uuid;

#[derive(Clone)] // Derive Clone
pub struct Db {
    db: Arc<SledDb>, // Use Arc
    characters: Arc<Tree>, // Use Arc
    rooms: Arc<Tree>,
    vnum_index: Arc<Tree>,
    areas: Arc<Tree>,
    items: Arc<Tree>,
    mobiles: Arc<Tree>,
    spawn_points: Arc<Tree>,
    settings: Arc<Tree>,
    recipes: Arc<Tree>,
    transports: Arc<Tree>,
}

impl Db {
    pub fn open<P: AsRef<Path>>(path: P) -> Result<Self> {
        let db = SledDb::open(path)?;
        let characters = db.open_tree("characters")?;
        let rooms = db.open_tree("rooms")?;
        let vnum_index = db.open_tree("vnum_index")?;
        let areas = db.open_tree("areas")?;
        let items = db.open_tree("items")?;
        let mobiles = db.open_tree("mobiles")?;
        let spawn_points = db.open_tree("spawn_points")?;
        let settings = db.open_tree("settings")?;
        let recipes = db.open_tree("recipes")?;
        let transports = db.open_tree("transports")?;
        Ok(Self {
            db: Arc::new(db), // Wrap in Arc
            characters: Arc::new(characters), // Wrap in Arc
            rooms: Arc::new(rooms),
            vnum_index: Arc::new(vnum_index),
            areas: Arc::new(areas),
            items: Arc::new(items),
            mobiles: Arc::new(mobiles),
            spawn_points: Arc::new(spawn_points),
            settings: Arc::new(settings),
            recipes: Arc::new(recipes),
            transports: Arc::new(transports),
        })
    }

    /// Flush all pending writes to disk. Call before shutdown.
    pub fn flush(&self) -> Result<()> {
        self.db.flush()?;
        Ok(())
    }

    pub fn get_character_data(&self, name: &str) -> Result<Option<CharacterData>> {
        // Use lowercase key for case-insensitive lookup
        let key = name.to_lowercase();
        match self.characters.get(key.as_bytes())? {
            Some(ivec) => {
                let character: CharacterData = serde_json::from_slice(&ivec)?;
                Ok(Some(character))
            }
            None => Ok(None),
        }
    }

    pub fn save_character_data(&self, character: CharacterData) -> Result<()> {
        // Use lowercase key for case-insensitive lookup, but preserve original case in data
        let key = character.name.to_lowercase();
        let value = serde_json::to_vec(&character)?;
        self.characters.insert(key.as_bytes(), value)?;
        Ok(())
    }

    pub fn delete_character_data(&self, name: &str) -> Result<()> {
        let key = name.to_lowercase();
        self.characters.remove(key.as_bytes())?;
        Ok(())
    }

    // Hashing function
    pub fn hash_password(&self, password: &str) -> Result<String> {
        use argon2::{
            password_hash::{rand_core::OsRng, PasswordHasher, SaltString},
            Argon2,
        };

        let salt = SaltString::generate(&mut OsRng);
        let password_hash = Argon2::default()
            .hash_password(password.as_bytes(), &salt)
            .map_err(|e| anyhow::anyhow!("Argon2 hashing error: {}", e))?
            .to_string();
        Ok(password_hash)
    }

    // Verification function
    pub fn verify_password(&self, password: &str, hash: &str) -> Result<bool> {
        use argon2::password_hash::PasswordVerifier;
        use argon2::Argon2;

        let parsed_hash = argon2::password_hash::PasswordHash::new(hash)
            .map_err(|e| anyhow::anyhow!("Argon2 parsing hash error: {}", e))?;
        Ok(Argon2::default()
            .verify_password(password.as_bytes(), &parsed_hash)
            .is_ok())
    }

    // Room methods
    pub fn get_room_data(&self, room_id: &Uuid) -> Result<Option<RoomData>> {
        let key = room_id.as_bytes();
        match self.rooms.get(key)? {
            Some(ivec) => {
                let room: RoomData = serde_json::from_slice(&ivec)?;
                Ok(Some(room))
            }
            None => Ok(None),
        }
    }

    pub fn save_room_data(&self, room: RoomData) -> Result<()> {
        let key = room.id.as_bytes();
        let value = serde_json::to_vec(&room)?;
        self.rooms.insert(key, value)?;
        Ok(())
    }

    pub fn room_exists(&self, room_id: &Uuid) -> Result<bool> {
        Ok(self.rooms.get(room_id.as_bytes())?.is_some())
    }

    /// Delete a room from the database
    pub fn delete_room(&self, room_id: &Uuid) -> Result<bool> {
        let key = room_id.as_bytes();
        Ok(self.rooms.remove(key)?.is_some())
    }

    /// List all rooms in the database
    pub fn list_all_rooms(&self) -> Result<Vec<RoomData>> {
        let mut rooms = Vec::new();
        for entry in self.rooms.iter() {
            let (_key, value) = entry?;
            let room: RoomData = serde_json::from_slice(&value)?;
            rooms.push(room);
        }
        Ok(rooms)
    }

    /// Search rooms by keyword (case-insensitive search in title and description)
    pub fn search_rooms(&self, keyword: &str) -> Result<Vec<RoomData>> {
        let keyword_lower = keyword.to_lowercase();
        let mut results = Vec::new();
        for entry in self.rooms.iter() {
            let (_key, value) = entry?;
            let room: RoomData = serde_json::from_slice(&value)?;
            let title_match = room.title.to_lowercase().contains(&keyword_lower);
            let desc_match = room.description.to_lowercase().contains(&keyword_lower);
            if title_match || desc_match {
                results.push(room);
            }
        }
        Ok(results)
    }

    /// Set an exit on a room (used by transport system)
    /// Supports the 6 cardinal directions: north, south, east, west, up, down
    pub fn set_room_exit(&self, room_id: &Uuid, direction: &str, target_room_id: &Uuid) -> Result<()> {
        let mut room = self.get_room_data(room_id)?
            .ok_or_else(|| anyhow::anyhow!("Room not found: {}", room_id))?;

        let dir_lower = direction.to_lowercase();
        match dir_lower.as_str() {
            "north" | "n" => room.exits.north = Some(*target_room_id),
            "south" | "s" => room.exits.south = Some(*target_room_id),
            "east" | "e" => room.exits.east = Some(*target_room_id),
            "west" | "w" => room.exits.west = Some(*target_room_id),
            "up" | "u" => room.exits.up = Some(*target_room_id),
            "down" | "d" => room.exits.down = Some(*target_room_id),
            "out" => room.exits.out = Some(*target_room_id),
            _ => {
                // Custom exit (e.g., "elevator", "train", "portal")
                room.exits.custom.insert(dir_lower, *target_room_id);
            }
        }

        self.save_room_data(room)?;
        Ok(())
    }

    /// Clear an exit from a room (used by transport system)
    /// Supports cardinal directions, "out", and custom exits
    pub fn clear_room_exit(&self, room_id: &Uuid, direction: &str) -> Result<()> {
        let mut room = self.get_room_data(room_id)?
            .ok_or_else(|| anyhow::anyhow!("Room not found: {}", room_id))?;

        let dir_lower = direction.to_lowercase();
        match dir_lower.as_str() {
            "north" | "n" => room.exits.north = None,
            "south" | "s" => room.exits.south = None,
            "east" | "e" => room.exits.east = None,
            "west" | "w" => room.exits.west = None,
            "up" | "u" => room.exits.up = None,
            "down" | "d" => room.exits.down = None,
            "out" => room.exits.out = None,
            _ => {
                // Custom exit
                room.exits.custom.remove(&dir_lower);
            }
        }

        self.save_room_data(room)?;
        Ok(())
    }

    // ========== Area Functions ==========

    /// Get area data by ID
    pub fn get_area_data(&self, area_id: &Uuid) -> Result<Option<AreaData>> {
        let key = area_id.as_bytes();
        match self.areas.get(key)? {
            Some(ivec) => {
                let area: AreaData = serde_json::from_slice(&ivec)?;
                Ok(Some(area))
            }
            None => Ok(None),
        }
    }

    /// Save area data
    pub fn save_area_data(&self, area: AreaData) -> Result<()> {
        let key = area.id.as_bytes();
        let value = serde_json::to_vec(&area)?;
        self.areas.insert(key, value)?;
        Ok(())
    }

    /// Delete an area (does not delete rooms, just unassigns them)
    pub fn delete_area(&self, area_id: &Uuid) -> Result<bool> {
        // First unassign all rooms from this area
        for entry in self.rooms.iter() {
            let (key, value) = entry?;
            let mut room: RoomData = serde_json::from_slice(&value)?;
            if room.area_id == Some(*area_id) {
                room.area_id = None;
                let new_value = serde_json::to_vec(&room)?;
                self.rooms.insert(key, new_value)?;
            }
        }
        // Delete the area
        let key = area_id.as_bytes();
        Ok(self.areas.remove(key)?.is_some())
    }

    /// List all areas
    pub fn list_all_areas(&self) -> Result<Vec<AreaData>> {
        let mut areas = Vec::new();
        for entry in self.areas.iter() {
            let (_key, value) = entry?;
            let area: AreaData = serde_json::from_slice(&value)?;
            areas.push(area);
        }
        Ok(areas)
    }

    /// Get all rooms in an area
    pub fn get_rooms_in_area(&self, area_id: &Uuid) -> Result<Vec<RoomData>> {
        let mut rooms = Vec::new();
        for entry in self.rooms.iter() {
            let (_key, value) = entry?;
            let room: RoomData = serde_json::from_slice(&value)?;
            if room.area_id == Some(*area_id) {
                rooms.push(room);
            }
        }
        Ok(rooms)
    }

    /// Set the area for a room
    pub fn set_room_area(&self, room_id: &Uuid, area_id: &Uuid) -> Result<bool> {
        if let Some(mut room) = self.get_room_data(room_id)? {
            room.area_id = Some(*area_id);
            self.save_room_data(room)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Clear the area from a room
    pub fn clear_room_area(&self, room_id: &Uuid) -> Result<bool> {
        if let Some(mut room) = self.get_room_data(room_id)? {
            if room.area_id.is_some() {
                room.area_id = None;
                self.save_room_data(room)?;
                return Ok(true);
            }
        }
        Ok(false)
    }

    // ========== Vnum Functions ==========

    /// Get room by vnum
    pub fn get_room_by_vnum(&self, vnum: &str) -> Result<Option<RoomData>> {
        let key = vnum.to_lowercase();
        if let Some(uuid_bytes) = self.vnum_index.get(key.as_bytes())? {
            let uuid_str = std::str::from_utf8(&uuid_bytes)?;
            let uuid = Uuid::parse_str(uuid_str)?;
            return self.get_room_data(&uuid);
        }
        Ok(None)
    }

    /// Set vnum for a room (updates room and index)
    pub fn set_room_vnum(&self, room_id: &Uuid, vnum: &str) -> Result<bool> {
        let vnum_lower = vnum.to_lowercase();

        // Check if vnum is already in use
        if self.vnum_index.contains_key(vnum_lower.as_bytes())? {
            return Ok(false); // Vnum already exists
        }

        // Get and update room
        if let Some(mut room) = self.get_room_data(room_id)? {
            // Clear old vnum from index if exists
            if let Some(ref old_vnum) = room.vnum {
                self.vnum_index.remove(old_vnum.to_lowercase().as_bytes())?;
            }

            // Set new vnum
            room.vnum = Some(vnum_lower.clone());
            self.save_room_data(room)?;

            // Add to index
            self.vnum_index.insert(vnum_lower.as_bytes(), room_id.to_string().as_bytes())?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Clear vnum from a room
    pub fn clear_room_vnum(&self, room_id: &Uuid) -> Result<bool> {
        if let Some(mut room) = self.get_room_data(room_id)? {
            if let Some(ref vnum) = room.vnum {
                self.vnum_index.remove(vnum.to_lowercase().as_bytes())?;
                room.vnum = None;
                self.save_room_data(room)?;
                return Ok(true);
            }
        }
        Ok(false)
    }

    /// Rebuild vnum index from room data (called on startup)
    pub fn rebuild_vnum_index(&self) -> Result<()> {
        // Clear existing index
        self.vnum_index.clear()?;

        // Rebuild from rooms
        for room in self.list_all_rooms()? {
            if let Some(ref vnum) = room.vnum {
                self.vnum_index.insert(
                    vnum.to_lowercase().as_bytes(),
                    room.id.to_string().as_bytes()
                )?;
            }
        }
        Ok(())
    }

    pub fn seed_default_rooms(&self) -> Result<()> {
        let starting_room_uuid = Uuid::parse_str(STARTING_ROOM_ID)?;
        let tavern_uuid = Uuid::parse_str("00000000-0000-0000-0000-000000000002")?;
        let market_uuid = Uuid::parse_str("00000000-0000-0000-0000-000000000003")?;

        // Only seed if starting room doesn't exist
        if self.room_exists(&starting_room_uuid)? {
            return Ok(());
        }

        // The Town Square - starting room
        let town_square = RoomData {
            id: starting_room_uuid,
            title: "The Town Square".to_string(),
            description: "You stand in a bustling town square. Cobblestones stretch beneath your feet, worn smooth by countless travelers. A weathered fountain burbles in the center, and merchant stalls line the edges.".to_string(),
            exits: RoomExits {
                north: Some(tavern_uuid),
                east: Some(market_uuid),
                ..Default::default()
            },
            flags: RoomFlags::default(),
            extra_descs: vec![
                ExtraDesc {
                    keywords: vec!["fountain".to_string(), "water".to_string()],
                    description: "The fountain is carved from gray stone, depicting a mermaid pouring water from a shell. The water is cool and clear, coins glinting at the bottom from wishes made long ago.".to_string(),
                },
            ],
            vnum: Some("town:square".to_string()),
            area_id: None,
            triggers: Vec::new(),
            doors: std::collections::HashMap::new(),
            spring_desc: None,
            summer_desc: None,
            autumn_desc: None,
            winter_desc: None,
            dynamic_desc: None,
            water_type: WaterType::None,
            catch_table: Vec::new(),
        };

        // The Rusty Tankard - tavern (indoors)
        let tavern = RoomData {
            id: tavern_uuid,
            title: "The Rusty Tankard".to_string(),
            description: "A cozy tavern with a roaring fireplace. The smell of ale and roasted meat fills the air. Wooden tables are scattered about, and a long bar runs along the back wall.".to_string(),
            exits: RoomExits {
                south: Some(starting_room_uuid),
                ..Default::default()
            },
            flags: RoomFlags {
                indoors: true,
                ..Default::default()
            },
            extra_descs: vec![
                ExtraDesc {
                    keywords: vec!["fireplace".to_string(), "fire".to_string()],
                    description: "The fireplace crackles with warm flames, casting dancing shadows across the room. Above the mantle hangs a rusty tankard - the tavern's namesake.".to_string(),
                },
            ],
            vnum: Some("town:tavern".to_string()),
            area_id: None,
            triggers: Vec::new(),
            doors: std::collections::HashMap::new(),
            spring_desc: None,
            summer_desc: None,
            autumn_desc: None,
            winter_desc: None,
            dynamic_desc: None,
            water_type: WaterType::None,
            catch_table: Vec::new(),
        };

        // Market Street
        let market = RoomData {
            id: market_uuid,
            title: "Market Street".to_string(),
            description: "A busy market street lined with merchant stalls. Vendors hawk their wares, from fresh produce to exotic trinkets. The cobblestones here are stained with years of commerce.".to_string(),
            exits: RoomExits {
                west: Some(starting_room_uuid),
                ..Default::default()
            },
            flags: RoomFlags::default(),
            extra_descs: Vec::new(),
            vnum: Some("town:market".to_string()),
            area_id: None,
            triggers: Vec::new(),
            doors: std::collections::HashMap::new(),
            spring_desc: None,
            summer_desc: None,
            autumn_desc: None,
            winter_desc: None,
            dynamic_desc: None,
            water_type: WaterType::None,
            catch_table: Vec::new(),
        };

        self.save_room_data(town_square)?;
        self.save_room_data(tavern)?;
        self.save_room_data(market)?;

        tracing::info!("Seeded default rooms: Town Square, Rusty Tankard, Market Street");
        Ok(())
    }

    /// Migrate character keys to lowercase for case-insensitive lookup.
    /// This handles characters created before the case-insensitive change.
    pub fn migrate_character_keys_to_lowercase(&self) -> Result<()> {
        let mut migrated_count = 0;

        // Collect entries to migrate (we can't modify while iterating)
        let mut to_migrate: Vec<(Vec<u8>, CharacterData)> = Vec::new();

        for entry in self.characters.iter() {
            let (key, value) = entry?;
            let character: CharacterData = serde_json::from_slice(&value)?;
            let lowercase_key = character.name.to_lowercase();

            // Check if key is not already lowercase
            if key.as_ref() != lowercase_key.as_bytes() {
                to_migrate.push((key.to_vec(), character));
            }
        }

        // Perform migrations
        for (old_key, character) in to_migrate {
            let lowercase_key = character.name.to_lowercase();
            let value = serde_json::to_vec(&character)?;

            // Remove old mixed-case key
            self.characters.remove(&old_key)?;
            // Insert with lowercase key
            self.characters.insert(lowercase_key.as_bytes(), value)?;

            tracing::info!(
                "Migrated character '{}' key from mixed-case to lowercase",
                character.name
            );
            migrated_count += 1;
        }

        if migrated_count > 0 {
            tracing::info!(
                "Migrated {} character key(s) to lowercase",
                migrated_count
            );
        }
        Ok(())
    }

    pub fn migrate_characters_to_valid_rooms(&self) -> Result<()> {
        let starting_room = Uuid::parse_str(STARTING_ROOM_ID)?;
        let nil_uuid = Uuid::nil();
        let mut migrated_count = 0;

        for entry in self.characters.iter() {
            let (_key, value) = entry?;
            let mut character: CharacterData = serde_json::from_slice(&value)?;

            // Check if room is nil or doesn't exist
            let needs_migration = character.current_room_id == nil_uuid
                || !self.room_exists(&character.current_room_id)?;

            if needs_migration {
                tracing::info!("Migrating character '{}' from invalid room to starting room", character.name);
                character.current_room_id = starting_room;
                self.save_character_data(character)?;
                migrated_count += 1;
            }
        }

        if migrated_count > 0 {
            tracing::info!("Migrated {} character(s) to starting room", migrated_count);
        }
        Ok(())
    }

    // ========== Item Functions ==========

    /// Get item data by ID
    pub fn get_item_data(&self, item_id: &Uuid) -> Result<Option<ItemData>> {
        let key = item_id.as_bytes();
        match self.items.get(key)? {
            Some(ivec) => {
                let item: ItemData = serde_json::from_slice(&ivec)?;
                Ok(Some(item))
            }
            None => Ok(None),
        }
    }

    /// Save item data
    pub fn save_item_data(&self, item: ItemData) -> Result<()> {
        let key = item.id.as_bytes();
        let value = serde_json::to_vec(&item)?;
        self.items.insert(key, value)?;
        Ok(())
    }

    /// Delete an item
    pub fn delete_item(&self, item_id: &Uuid) -> Result<bool> {
        let key = item_id.as_bytes();
        Ok(self.items.remove(key)?.is_some())
    }

    /// List all items in the database
    pub fn list_all_items(&self) -> Result<Vec<ItemData>> {
        let mut items = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            items.push(item);
        }
        Ok(items)
    }

    /// Count non-prototype items with a given vnum (for unique item enforcement)
    pub fn count_non_prototype_items_by_vnum(&self, vnum: &str) -> Result<usize> {
        let items = self.list_all_items()?;
        let count = items
            .iter()
            .filter(|i| !i.is_prototype && i.vnum.as_deref() == Some(vnum))
            .count();
        Ok(count)
    }

    /// Get all items in a room
    pub fn get_items_in_room(&self, room_id: &Uuid) -> Result<Vec<ItemData>> {
        let mut items = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if let ItemLocation::Room(rid) = &item.location {
                if rid == room_id {
                    items.push(item);
                }
            }
        }
        Ok(items)
    }

    /// Get all items in a character's inventory
    pub fn get_items_in_inventory(&self, char_name: &str) -> Result<Vec<ItemData>> {
        let name_lower = char_name.to_lowercase();
        let mut items = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if let ItemLocation::Inventory(owner) = &item.location {
                if owner.to_lowercase() == name_lower {
                    items.push(item);
                }
            }
        }
        Ok(items)
    }

    /// Get all items equipped by a character
    pub fn get_equipped_items(&self, char_name: &str) -> Result<Vec<ItemData>> {
        let name_lower = char_name.to_lowercase();
        let mut items = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if let ItemLocation::Equipped(owner) = &item.location {
                if owner.to_lowercase() == name_lower {
                    items.push(item);
                }
            }
        }
        Ok(items)
    }

    /// Move item to a room (gold items auto-merge with existing gold in the room)
    pub fn move_item_to_room(&self, item_id: &Uuid, room_id: &Uuid) -> Result<bool> {
        let item = match self.get_item_data(item_id)? {
            Some(i) => i,
            None => return Ok(false),
        };

        // Handle gold auto-merge
        if item.item_type == ItemType::Gold {
            if let Some(mut existing) = self.find_gold_in_room(room_id)? {
                if existing.id != *item_id {
                    // Merge into existing pile
                    existing.value += item.value;
                    crate::update_gold_descriptions(&mut existing);
                    self.save_item_data(existing)?;
                    self.delete_item(item_id)?;
                    return Ok(true);
                }
            }
        }

        // Normal item movement
        let mut item = item;
        item.location = ItemLocation::Room(*room_id);
        self.save_item_data(item)?;
        Ok(true)
    }

    /// Move item to a character's inventory
    pub fn move_item_to_inventory(&self, item_id: &Uuid, char_name: &str) -> Result<bool> {
        if let Some(mut item) = self.get_item_data(item_id)? {
            item.location = ItemLocation::Inventory(char_name.to_lowercase());
            self.save_item_data(item)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Move item to equipped status
    pub fn move_item_to_equipped(&self, item_id: &Uuid, char_name: &str) -> Result<bool> {
        if let Some(mut item) = self.get_item_data(item_id)? {
            item.location = ItemLocation::Equipped(char_name.to_lowercase());
            self.save_item_data(item)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Move item to nowhere (removes from any inventory/location)
    pub fn move_item_to_nowhere(&self, item_id: &Uuid) -> Result<bool> {
        if let Some(mut item) = self.get_item_data(item_id)? {
            item.location = ItemLocation::Nowhere;
            self.save_item_data(item)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Get all items inside a container
    pub fn get_items_in_container(&self, container_id: &Uuid) -> Result<Vec<ItemData>> {
        let mut items = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if let ItemLocation::Container(cid) = &item.location {
                if cid == container_id {
                    items.push(item);
                }
            }
        }
        Ok(items)
    }

    /// Move item into a container (updates both container's contents list and item's location)
    pub fn move_item_to_container(&self, item_id: &Uuid, container_id: &Uuid) -> Result<bool> {
        // Get the container
        let mut container = match self.get_item_data(container_id)? {
            Some(c) if c.item_type == ItemType::Container => c,
            _ => return Ok(false),
        };

        // Get the item
        let mut item = match self.get_item_data(item_id)? {
            Some(i) => i,
            None => return Ok(false),
        };

        // Remove from old container if applicable
        if let ItemLocation::Container(old_container_id) = &item.location {
            if let Some(mut old_container) = self.get_item_data(old_container_id)? {
                old_container.container_contents.retain(|id| id != item_id);
                self.save_item_data(old_container)?;
            }
        }

        // Add to new container
        if !container.container_contents.contains(item_id) {
            container.container_contents.push(*item_id);
        }
        item.location = ItemLocation::Container(*container_id);

        self.save_item_data(container)?;
        self.save_item_data(item)?;
        Ok(true)
    }

    /// Remove item from container (updates both container's contents and item's location)
    pub fn remove_item_from_container(&self, item_id: &Uuid) -> Result<bool> {
        let mut item = match self.get_item_data(item_id)? {
            Some(i) => i,
            None => return Ok(false),
        };

        if let ItemLocation::Container(container_id) = &item.location {
            if let Some(mut container) = self.get_item_data(container_id)? {
                container.container_contents.retain(|id| id != item_id);
                self.save_item_data(container)?;
            }
            item.location = ItemLocation::Nowhere;
            self.save_item_data(item)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    // ========== Mobile Inventory/Equipment Functions ==========

    /// Move item to a mobile's inventory (uses mobile UUID as owner string)
    pub fn move_item_to_mobile_inventory(&self, item_id: &Uuid, mobile_id: &Uuid) -> Result<bool> {
        if let Some(mut item) = self.get_item_data(item_id)? {
            // Use mobile UUID as the owner identifier
            item.location = ItemLocation::Inventory(mobile_id.to_string());
            self.save_item_data(item)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Move item to equipped on a mobile (uses mobile UUID as owner string)
    pub fn move_item_to_mobile_equipped(&self, item_id: &Uuid, mobile_id: &Uuid) -> Result<bool> {
        if let Some(mut item) = self.get_item_data(item_id)? {
            // Use mobile UUID as the owner identifier
            item.location = ItemLocation::Equipped(mobile_id.to_string());
            self.save_item_data(item)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Get all items in a mobile's inventory
    pub fn get_items_in_mobile_inventory(&self, mobile_id: &Uuid) -> Result<Vec<ItemData>> {
        let mobile_id_str = mobile_id.to_string();
        let mut items = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if let ItemLocation::Inventory(owner) = &item.location {
                if owner == &mobile_id_str {
                    items.push(item);
                }
            }
        }
        Ok(items)
    }

    /// Get all items equipped on a mobile
    pub fn get_items_equipped_on_mobile(&self, mobile_id: &Uuid) -> Result<Vec<ItemData>> {
        let mobile_id_str = mobile_id.to_string();
        let mut items = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if let ItemLocation::Equipped(owner) = &item.location {
                if owner == &mobile_id_str {
                    items.push(item);
                }
            }
        }
        Ok(items)
    }

    /// Search items by keyword (case-insensitive search in name and keywords)
    pub fn search_items(&self, keyword: &str) -> Result<Vec<ItemData>> {
        let keyword_lower = keyword.to_lowercase();
        let mut results = Vec::new();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            let name_match = item.name.to_lowercase().contains(&keyword_lower);
            let keyword_match = item.keywords.iter()
                .any(|k| k.to_lowercase().contains(&keyword_lower));
            if name_match || keyword_match {
                results.push(item);
            }
        }
        Ok(results)
    }

    // ========== Gold Functions ==========

    /// Find existing gold pile in a room
    pub fn find_gold_in_room(&self, room_id: &Uuid) -> Result<Option<ItemData>> {
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if item.item_type == ItemType::Gold {
                if let ItemLocation::Room(rid) = &item.location {
                    if rid == room_id {
                        return Ok(Some(item));
                    }
                }
            }
        }
        Ok(None)
    }

    /// Find existing gold pile in a container
    pub fn find_gold_in_container(&self, container_id: &Uuid) -> Result<Option<ItemData>> {
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if item.item_type == ItemType::Gold {
                if let ItemLocation::Container(cid) = &item.location {
                    if cid == container_id {
                        return Ok(Some(item));
                    }
                }
            }
        }
        Ok(None)
    }

    /// Spawn gold in a room with auto-merge
    pub fn spawn_gold_in_room(&self, amount: i32, room_id: &Uuid) -> Result<ItemData> {
        // Check for existing gold pile to merge with
        if let Some(mut existing) = self.find_gold_in_room(room_id)? {
            existing.value += amount;
            crate::update_gold_descriptions(&mut existing);
            self.save_item_data(existing.clone())?;
            return Ok(existing);
        }

        // Create new gold pile
        let mut gold = crate::create_gold_item(amount);
        gold.location = ItemLocation::Room(*room_id);
        self.save_item_data(gold.clone())?;
        Ok(gold)
    }

    /// Spawn gold in a container with auto-merge
    pub fn spawn_gold_in_container(&self, amount: i32, container_id: &Uuid) -> Result<Option<ItemData>> {
        // Verify container exists and is a container
        let container = match self.get_item_data(container_id)? {
            Some(c) if c.item_type == ItemType::Container => c,
            _ => return Ok(None),
        };

        // Check for existing gold pile to merge with
        if let Some(mut existing) = self.find_gold_in_container(container_id)? {
            existing.value += amount;
            crate::update_gold_descriptions(&mut existing);
            self.save_item_data(existing.clone())?;
            return Ok(Some(existing));
        }

        // Create new gold pile
        let mut gold = crate::create_gold_item(amount);
        gold.location = ItemLocation::Container(*container_id);
        self.save_item_data(gold.clone())?;

        // Add to container contents
        let mut container = container;
        container.container_contents.push(gold.id);
        self.save_item_data(container)?;

        Ok(Some(gold))
    }

    // ========== Mobile/NPC Functions ==========

    /// Get mobile data by ID
    pub fn get_mobile_data(&self, mobile_id: &Uuid) -> Result<Option<MobileData>> {
        let key = mobile_id.as_bytes();
        match self.mobiles.get(key)? {
            Some(ivec) => {
                let mobile: MobileData = serde_json::from_slice(&ivec)?;
                Ok(Some(mobile))
            }
            None => Ok(None),
        }
    }

    /// Save mobile data
    pub fn save_mobile_data(&self, mobile: MobileData) -> Result<()> {
        let key = mobile.id.as_bytes();
        let value = serde_json::to_vec(&mobile)?;
        self.mobiles.insert(key, value)?;
        Ok(())
    }

    /// Delete a mobile
    pub fn delete_mobile(&self, mobile_id: &Uuid) -> Result<bool> {
        let key = mobile_id.as_bytes();
        Ok(self.mobiles.remove(key)?.is_some())
    }

    /// List all mobiles in the database
    pub fn list_all_mobiles(&self) -> Result<Vec<MobileData>> {
        let mut mobiles = Vec::new();
        for entry in self.mobiles.iter() {
            let (_key, value) = match entry {
                Ok(e) => e,
                Err(e) => {
                    tracing::warn!("Error reading mobile entry: {}", e);
                    continue;
                }
            };
            let mobile: MobileData = match serde_json::from_slice(&value) {
                Ok(m) => m,
                Err(e) => {
                    tracing::warn!("Error deserializing mobile: {}", e);
                    continue;
                }
            };
            mobiles.push(mobile);
        }
        Ok(mobiles)
    }

    /// Get all mobiles in a room
    pub fn get_mobiles_in_room(&self, room_id: &Uuid) -> Result<Vec<MobileData>> {
        let mut mobiles = Vec::new();
        for entry in self.mobiles.iter() {
            let (_key, value) = match entry {
                Ok(e) => e,
                Err(e) => {
                    tracing::warn!("Error reading mobile entry: {}", e);
                    continue;
                }
            };
            let mobile: MobileData = match serde_json::from_slice(&value) {
                Ok(m) => m,
                Err(e) => {
                    tracing::warn!("Error deserializing mobile: {}", e);
                    continue;
                }
            };
            if let Some(rid) = mobile.current_room_id {
                if rid == *room_id && !mobile.is_prototype {
                    mobiles.push(mobile);
                }
            }
        }
        Ok(mobiles)
    }

    /// Get mobile by vnum
    pub fn get_mobile_by_vnum(&self, vnum: &str) -> Result<Option<MobileData>> {
        let vnum_lower = vnum.to_lowercase();
        for entry in self.mobiles.iter() {
            let (_key, value) = entry?;
            let mobile: MobileData = serde_json::from_slice(&value)?;
            if mobile.vnum.to_lowercase() == vnum_lower {
                return Ok(Some(mobile));
            }
        }
        Ok(None)
    }

    /// Search mobiles by keyword (case-insensitive search in name and keywords)
    pub fn search_mobiles(&self, keyword: &str) -> Result<Vec<MobileData>> {
        let keyword_lower = keyword.to_lowercase();
        let mut results = Vec::new();
        for entry in self.mobiles.iter() {
            let (_key, value) = entry?;
            let mobile: MobileData = serde_json::from_slice(&value)?;
            let name_match = mobile.name.to_lowercase().contains(&keyword_lower);
            let keyword_match = mobile.keywords.iter()
                .any(|k| k.to_lowercase().contains(&keyword_lower));
            let vnum_match = mobile.vnum.to_lowercase().contains(&keyword_lower);
            if name_match || keyword_match || vnum_match {
                results.push(mobile);
            }
        }
        Ok(results)
    }

    /// Move mobile to a room
    pub fn move_mobile_to_room(&self, mobile_id: &Uuid, room_id: &Uuid) -> Result<bool> {
        if let Some(mut mobile) = self.get_mobile_data(mobile_id)? {
            mobile.current_room_id = Some(*room_id);
            self.save_mobile_data(mobile)?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    /// Spawn a mobile from a prototype (creates a copy with is_prototype=false)
    pub fn spawn_mobile_from_prototype(&self, vnum: &str) -> Result<Option<MobileData>> {
        if let Some(prototype) = self.get_mobile_by_vnum(vnum)? {
            if !prototype.is_prototype {
                return Ok(None); // Not a prototype
            }
            let mut spawned = prototype.clone();
            spawned.id = Uuid::new_v4();
            spawned.is_prototype = false;
            spawned.current_hp = spawned.max_hp; // Spawn with full health
            self.save_mobile_data(spawned.clone())?;
            Ok(Some(spawned))
        } else {
            Ok(None)
        }
    }

    /// Refresh a mobile instance from its prototype
    /// Preserves: id, current_room_id, current_hp, shop_inventory
    pub fn refresh_mobile_from_prototype(&self, mobile_id: &Uuid) -> Result<Option<MobileData>> {
        let instance = match self.get_mobile_data(mobile_id)? {
            Some(m) => m,
            None => return Ok(None),
        };

        if instance.is_prototype {
            return Ok(None);
        }

        let prototype = match self.get_mobile_by_vnum(&instance.vnum)? {
            Some(p) if p.is_prototype => p,
            _ => return Ok(None),
        };

        let mut refreshed = prototype.clone();
        refreshed.id = instance.id;
        refreshed.is_prototype = false;
        refreshed.current_room_id = instance.current_room_id;
        refreshed.current_hp = instance.current_hp;
        refreshed.shop_inventory = instance.shop_inventory;

        self.save_mobile_data(refreshed.clone())?;
        Ok(Some(refreshed))
    }

    /// Get all mobile instances with a specific vnum
    pub fn get_mobile_instances_by_vnum(&self, vnum: &str) -> Result<Vec<MobileData>> {
        let vnum_lower = vnum.to_lowercase();
        let mut results = Vec::new();
        for entry in self.mobiles.iter() {
            let (_key, value) = entry?;
            let mobile: MobileData = serde_json::from_slice(&value)?;
            if !mobile.is_prototype && mobile.vnum.to_lowercase() == vnum_lower {
                results.push(mobile);
            }
        }
        Ok(results)
    }

    /// Get item by vnum
    pub fn get_item_by_vnum(&self, vnum: &str) -> Result<Option<ItemData>> {
        let vnum_lower = vnum.to_lowercase();
        for entry in self.items.iter() {
            let (_key, value) = entry?;
            let item: ItemData = serde_json::from_slice(&value)?;
            if let Some(ref item_vnum) = item.vnum {
                if item_vnum.to_lowercase() == vnum_lower {
                    return Ok(Some(item));
                }
            }
        }
        Ok(None)
    }

    /// Spawn an item from a prototype (creates a copy with is_prototype=false)
    pub fn spawn_item_from_prototype(&self, vnum: &str) -> Result<Option<ItemData>> {
        if let Some(prototype) = self.get_item_by_vnum(vnum)? {
            if !prototype.is_prototype {
                return Ok(None); // Not a prototype
            }
            let mut spawned = prototype.clone();
            spawned.id = Uuid::new_v4();
            spawned.is_prototype = false;
            spawned.location = ItemLocation::Nowhere;
            spawned.container_contents = Vec::new();
            self.save_item_data(spawned.clone())?;
            Ok(Some(spawned))
        } else {
            Ok(None)
        }
    }

    // ========== Spawn Point Functions ==========

    /// Get spawn point by ID
    pub fn get_spawn_point(&self, spawn_point_id: &Uuid) -> Result<Option<SpawnPointData>> {
        let key = spawn_point_id.as_bytes();
        match self.spawn_points.get(key)? {
            Some(ivec) => {
                let spawn_point: SpawnPointData = serde_json::from_slice(&ivec)?;
                Ok(Some(spawn_point))
            }
            None => Ok(None),
        }
    }

    /// Save spawn point
    pub fn save_spawn_point(&self, spawn_point: SpawnPointData) -> Result<()> {
        let key = spawn_point.id.as_bytes();
        let value = serde_json::to_vec(&spawn_point)?;
        self.spawn_points.insert(key, value)?;
        Ok(())
    }

    /// Delete a spawn point
    pub fn delete_spawn_point(&self, spawn_point_id: &Uuid) -> Result<bool> {
        let key = spawn_point_id.as_bytes();
        Ok(self.spawn_points.remove(key)?.is_some())
    }

    /// List all spawn points
    pub fn list_all_spawn_points(&self) -> Result<Vec<SpawnPointData>> {
        let mut spawn_points = Vec::new();
        for entry in self.spawn_points.iter() {
            let (_key, value) = entry?;
            let sp: SpawnPointData = serde_json::from_slice(&value)?;
            spawn_points.push(sp);
        }
        Ok(spawn_points)
    }

    /// Get all spawn points for an area
    pub fn get_spawn_points_for_area(&self, area_id: &Uuid) -> Result<Vec<SpawnPointData>> {
        let mut spawn_points = Vec::new();
        for entry in self.spawn_points.iter() {
            let (_key, value) = entry?;
            let sp: SpawnPointData = serde_json::from_slice(&value)?;
            if sp.area_id == *area_id {
                spawn_points.push(sp);
            }
        }
        Ok(spawn_points)
    }

    /// Get spawn points for a specific room
    pub fn get_spawn_points_for_room(&self, room_id: &Uuid) -> Result<Vec<SpawnPointData>> {
        let mut spawn_points = Vec::new();
        for entry in self.spawn_points.iter() {
            let (_key, value) = entry?;
            let sp: SpawnPointData = serde_json::from_slice(&value)?;
            if sp.room_id == *room_id {
                spawn_points.push(sp);
            }
        }
        Ok(spawn_points)
    }

    /// Count active spawned entities for a spawn point (validates they still exist)
    pub fn count_active_spawns(&self, spawn_point: &SpawnPointData) -> Result<i32> {
        let mut count = 0;
        for entity_id in &spawn_point.spawned_entities {
            let exists = match spawn_point.entity_type {
                SpawnEntityType::Mobile => self.get_mobile_data(entity_id)?.is_some(),
                SpawnEntityType::Item => self.get_item_data(entity_id)?.is_some(),
            };
            if exists {
                count += 1;
            }
        }
        Ok(count)
    }

    /// Clean up references to deleted entities from spawn point
    pub fn cleanup_spawn_point_refs(&self, spawn_point_id: &Uuid) -> Result<()> {
        if let Some(mut sp) = self.get_spawn_point(spawn_point_id)? {
            let mut valid_entities = Vec::new();
            for entity_id in &sp.spawned_entities {
                let exists = match sp.entity_type {
                    SpawnEntityType::Mobile => self.get_mobile_data(entity_id)?.is_some(),
                    SpawnEntityType::Item => self.get_item_data(entity_id)?.is_some(),
                };
                if exists {
                    valid_entities.push(*entity_id);
                }
            }
            sp.spawned_entities = valid_entities;
            self.save_spawn_point(sp)?;
        }
        Ok(())
    }

    // ========== Settings Functions ==========

    /// Get a setting value by key
    pub fn get_setting(&self, key: &str) -> Result<Option<String>> {
        Ok(self.settings.get(key.as_bytes())?.map(|ivec| {
            String::from_utf8_lossy(&ivec).to_string()
        }))
    }

    /// Set a setting value
    pub fn set_setting(&self, key: &str, value: &str) -> Result<()> {
        self.settings.insert(key.as_bytes(), value.as_bytes())?;
        Ok(())
    }

    /// Delete a setting
    pub fn delete_setting(&self, key: &str) -> Result<bool> {
        Ok(self.settings.remove(key.as_bytes())?.is_some())
    }

    /// List all settings as (key, value) pairs
    pub fn list_all_settings(&self) -> Result<Vec<(String, String)>> {
        let mut settings = Vec::new();
        for entry in self.settings.iter() {
            let (key, value) = entry?;
            settings.push((
                String::from_utf8_lossy(&key).to_string(),
                String::from_utf8_lossy(&value).to_string(),
            ));
        }
        Ok(settings)
    }

    /// Get setting with default value if not set
    pub fn get_setting_or_default(&self, key: &str, default: &str) -> Result<String> {
        Ok(self.get_setting(key)?.unwrap_or_else(|| default.to_string()))
    }

    // ========== Game Time Functions ==========

    /// Get the current game time, or create a default if not set
    pub fn get_game_time(&self) -> Result<crate::GameTime> {
        match self.get_setting("game_time")? {
            Some(json) => {
                let game_time: crate::GameTime = serde_json::from_str(&json)?;
                Ok(game_time)
            }
            None => {
                let game_time = crate::GameTime::default();
                self.save_game_time(&game_time)?;
                Ok(game_time)
            }
        }
    }

    /// Save the current game time to the database
    pub fn save_game_time(&self, game_time: &crate::GameTime) -> Result<()> {
        let json = serde_json::to_string(game_time)?;
        self.set_setting("game_time", &json)
    }

    // ========== Character Listing Functions ==========

    /// Count total number of characters in database
    pub fn count_characters(&self) -> Result<usize> {
        Ok(self.characters.len())
    }

    /// List all characters (for admin utility)
    pub fn list_all_characters(&self) -> Result<Vec<CharacterData>> {
        let mut characters = Vec::new();
        for entry in self.characters.iter() {
            let (_key, value) = entry?;
            let char: CharacterData = serde_json::from_slice(&value)?;
            characters.push(char);
        }
        Ok(characters)
    }

    /// Get names of all characters currently in combat
    pub fn get_all_characters_in_combat(&self) -> Result<Vec<String>> {
        let mut names = Vec::new();
        for entry in self.characters.iter() {
            let (_key, value) = entry?;
            let char: CharacterData = serde_json::from_slice(&value)?;
            if char.combat.in_combat {
                names.push(char.name);
            }
        }
        Ok(names)
    }

    /// Get IDs of all mobiles currently in combat
    pub fn get_all_mobiles_in_combat(&self) -> Result<Vec<Uuid>> {
        tracing::debug!("get_all_mobiles_in_combat: starting iteration");
        let mut ids = Vec::new();
        let mut count = 0;
        for entry in self.mobiles.iter() {
            count += 1;
            let (_key, value) = match entry {
                Ok(e) => e,
                Err(e) => {
                    tracing::warn!("Error reading mobile entry: {}", e);
                    continue;
                }
            };
            let mobile: MobileData = match serde_json::from_slice(&value) {
                Ok(m) => m,
                Err(e) => {
                    tracing::warn!("Error deserializing mobile: {}", e);
                    continue;
                }
            };
            // Log non-prototype mobiles and their combat state
            if !mobile.is_prototype {
                tracing::debug!("get_all_mobiles_in_combat: checking {} ({}) - in_combat={}, targets={}",
                               mobile.name, mobile.id, mobile.combat.in_combat, mobile.combat.targets.len());
            }
            if mobile.combat.in_combat {
                ids.push(mobile.id);
            }
        }
        tracing::debug!("get_all_mobiles_in_combat: iterated {} entries, {} in combat", count, ids.len());
        Ok(ids)
    }

    // ========== Recipe Functions ==========

    /// Get recipe by vnum (id)
    pub fn get_recipe(&self, vnum: &str) -> Result<Option<Recipe>> {
        let key = vnum.to_lowercase();
        match self.recipes.get(key.as_bytes())? {
            Some(ivec) => {
                let recipe: Recipe = serde_json::from_slice(&ivec)?;
                Ok(Some(recipe))
            }
            None => Ok(None),
        }
    }

    /// Save recipe data
    pub fn save_recipe(&self, recipe: Recipe) -> Result<()> {
        let key = recipe.id.to_lowercase();
        let value = serde_json::to_vec(&recipe)?;
        self.recipes.insert(key.as_bytes(), value)?;
        Ok(())
    }

    /// Delete a recipe by vnum
    pub fn delete_recipe(&self, vnum: &str) -> Result<bool> {
        let key = vnum.to_lowercase();
        Ok(self.recipes.remove(key.as_bytes())?.is_some())
    }

    /// List all recipes in the database
    pub fn list_all_recipes(&self) -> Result<Vec<Recipe>> {
        let mut recipes = Vec::new();
        for entry in self.recipes.iter() {
            let (_key, value) = entry?;
            let recipe: Recipe = serde_json::from_slice(&value)?;
            recipes.push(recipe);
        }
        Ok(recipes)
    }

    /// Search recipes by keyword (case-insensitive search in name, id, and output_vnum)
    pub fn search_recipes(&self, keyword: &str) -> Result<Vec<Recipe>> {
        let keyword_lower = keyword.to_lowercase();
        let mut results = Vec::new();
        for entry in self.recipes.iter() {
            let (_key, value) = entry?;
            let recipe: Recipe = serde_json::from_slice(&value)?;
            let id_match = recipe.id.to_lowercase().contains(&keyword_lower);
            let name_match = recipe.name.to_lowercase().contains(&keyword_lower);
            let output_match = recipe.output_vnum.to_lowercase().contains(&keyword_lower);
            if id_match || name_match || output_match {
                results.push(recipe);
            }
        }
        Ok(results)
    }

    /// Get all recipes for a specific skill
    pub fn get_recipes_by_skill(&self, skill: &str) -> Result<Vec<Recipe>> {
        let skill_lower = skill.to_lowercase();
        let mut recipes = Vec::new();
        for entry in self.recipes.iter() {
            let (_key, value) = entry?;
            let recipe: Recipe = serde_json::from_slice(&value)?;
            if recipe.skill.to_lowercase() == skill_lower {
                recipes.push(recipe);
            }
        }
        Ok(recipes)
    }

    /// Check if recipes tree is empty (for seeding)
    pub fn recipes_empty(&self) -> Result<bool> {
        Ok(self.recipes.is_empty())
    }

    /// Seed recipes from a list (used when loading from JSON on first run)
    pub fn seed_recipes(&self, recipes: Vec<Recipe>) -> Result<()> {
        for recipe in recipes {
            self.save_recipe(recipe)?;
        }
        Ok(())
    }

    // ========== Transport Functions ==========

    /// Get transport by UUID
    pub fn get_transport(&self, id: Uuid) -> Result<Option<TransportData>> {
        match self.transports.get(id.as_bytes())? {
            Some(ivec) => {
                let transport: TransportData = serde_json::from_slice(&ivec)?;
                Ok(Some(transport))
            }
            None => Ok(None),
        }
    }

    /// Get transport by vnum
    pub fn get_transport_by_vnum(&self, vnum: &str) -> Result<Option<TransportData>> {
        let vnum_lower = vnum.to_lowercase();
        for entry in self.transports.iter() {
            let (_key, value) = entry?;
            let transport: TransportData = serde_json::from_slice(&value)?;
            if let Some(ref t_vnum) = transport.vnum {
                if t_vnum.to_lowercase() == vnum_lower {
                    return Ok(Some(transport));
                }
            }
        }
        Ok(None)
    }

    /// Save transport data
    pub fn save_transport(&self, transport: &TransportData) -> Result<()> {
        let value = serde_json::to_vec(transport)?;
        self.transports.insert(transport.id.as_bytes(), value)?;
        Ok(())
    }

    /// Delete a transport by UUID
    pub fn delete_transport(&self, id: Uuid) -> Result<bool> {
        Ok(self.transports.remove(id.as_bytes())?.is_some())
    }

    /// List all transports in the database
    pub fn list_all_transports(&self) -> Result<Vec<TransportData>> {
        let mut transports = Vec::new();
        for entry in self.transports.iter() {
            let (_key, value) = entry?;
            let transport: TransportData = serde_json::from_slice(&value)?;
            transports.push(transport);
        }
        Ok(transports)
    }

    /// Search transports by keyword (case-insensitive search in name and vnum)
    pub fn search_transports(&self, keyword: &str) -> Result<Vec<TransportData>> {
        let keyword_lower = keyword.to_lowercase();
        let mut results = Vec::new();
        for entry in self.transports.iter() {
            let (_key, value) = entry?;
            let transport: TransportData = serde_json::from_slice(&value)?;
            let name_match = transport.name.to_lowercase().contains(&keyword_lower);
            let vnum_match = transport.vnum
                .as_ref()
                .map(|v| v.to_lowercase().contains(&keyword_lower))
                .unwrap_or(false);
            if name_match || vnum_match {
                results.push(transport);
            }
        }
        Ok(results)
    }

    /// Get transport by interior room ID (to find what transport a room belongs to)
    pub fn get_transport_by_interior_room(&self, room_id: Uuid) -> Result<Option<TransportData>> {
        for entry in self.transports.iter() {
            let (_key, value) = entry?;
            let transport: TransportData = serde_json::from_slice(&value)?;
            if transport.interior_room_id == room_id {
                return Ok(Some(transport));
            }
        }
        Ok(None)
    }

    /// Get transports that have a stop at a specific room
    pub fn get_transports_with_stop_at(&self, room_id: Uuid) -> Result<Vec<TransportData>> {
        let mut results = Vec::new();
        for entry in self.transports.iter() {
            let (_key, value) = entry?;
            let transport: TransportData = serde_json::from_slice(&value)?;
            if transport.stops.iter().any(|s| s.room_id == room_id) {
                results.push(transport);
            }
        }
        Ok(results)
    }

    /// Check if transports tree is empty
    pub fn transports_empty(&self) -> Result<bool> {
        Ok(self.transports.is_empty())
    }
}
