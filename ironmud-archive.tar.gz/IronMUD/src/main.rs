use anyhow::Result;
use clap::Parser;
use rhai::Engine;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use tokio::net::TcpListener;
use tokio::time::{interval, Duration};
use tracing::{info, debug, error};

use ironmud::{
    db, game::Entity, load_command_metadata, load_game_data, load_scripts, run_server, watch_scripts, World,
    SpawnEntityType, SpawnDestination, SpawnPointData, ItemType, TriggerType, SharedConnections, save_all_players,
    broadcast_to_all_players, broadcast_to_outdoor_players, broadcast_to_builders, ShutdownCommand,
    matrix::{MatrixConfig, MatrixMessage, run_matrix_bot},
    claude::{ClaudeConfig, ClaudeRequest, run_claude_task},
    gemini::{GeminiConfig, GeminiRequest, run_gemini_task},
};
use ironmud::script;

#[derive(Parser, Debug)]
#[command(name = "ironmud")]
#[command(about = "IronMUD Game Server")]
struct Args {
    /// Port to listen on
    #[arg(short, long, default_value = "4000")]
    port: u16,

    /// Database path
    #[arg(short, long, default_value = "ironmud.db")]
    database: String,
}

/// Spawn tick interval in seconds
const SPAWN_TICK_INTERVAL_SECS: u64 = 30;

/// Time tick interval in seconds (2 real minutes = 1 game hour)
const TIME_TICK_INTERVAL_SECS: u64 = 120;

/// Thirst tick interval in seconds (check thirst every minute)
const THIRST_TICK_INTERVAL_SECS: u64 = 60;

/// Stamina/HP regeneration tick interval in seconds
const REGEN_TICK_INTERVAL_SECS: u64 = 10;

/// Mobile wandering tick interval in seconds
const WANDER_TICK_INTERVAL_SECS: u64 = 60;

/// Chance for a mobile to wander each tick (percentage 0-100)
const WANDER_CHANCE_PERCENT: u32 = 33;

/// Combat round tick interval in seconds (5 second rounds per design doc)
const COMBAT_TICK_INTERVAL_SECS: u64 = 5;
/// Interval for weather exposure tick (wet, cold, heat effects)
const EXPOSURE_TICK_INTERVAL_SECS: u64 = 30;

#[tokio::main]
async fn main() -> Result<()> {
    let args = Args::parse();

    tracing_subscriber::fmt::init();
    info!("Starting IronMUD server...");

    let mut engine = Engine::new(); // Make engine mutable for registrations
    let db = crate::db::Db::open(&args.database)?;

    // Seed default rooms if they don't exist
    db.seed_default_rooms()?;

    // Migrate character keys to lowercase for case-insensitive lookup
    db.migrate_character_keys_to_lowercase()?;

    // Migrate characters with invalid room IDs to starting room
    db.migrate_characters_to_valid_rooms()?;

    // Rebuild vnum index from existing room data
    db.rebuild_vnum_index()?;

    let cloned_db_for_rhai = db.clone(); // Clone db for Rhai registration
    let tick_db = db.clone(); // Clone db for spawn tick
    let tick_db2 = db.clone(); // Clone db for periodic triggers
    let tick_db3 = db.clone(); // Clone db for time tick
    let tick_db4 = db.clone(); // Clone db for thirst tick
    let tick_db5 = db.clone(); // Clone db for regen tick
    let tick_db6 = db.clone(); // Clone db for wander tick
    let tick_db7 = db.clone(); // Clone db for combat tick
    let tick_db8 = db.clone(); // Clone db for corpse decay tick
    let tick_db9 = db.clone(); // Clone db for exposure tick
    let tick_db10 = db.clone(); // Clone db for transport tick

    let connections = Arc::new(Mutex::new(HashMap::new()));
    let command_metadata = load_command_metadata()?;

    let state = Arc::new(Mutex::new(World {
        engine,
        db,
        connections: connections.clone(),
        scripts: HashMap::new(),
        command_metadata,
        class_definitions: HashMap::new(),
        trait_definitions: HashMap::new(),
        race_suggestions: Vec::new(),
        recipes: HashMap::new(),
        transports: HashMap::new(),
        matrix_sender: None,           // Set after Matrix channel is created
        shutdown_sender: None,         // Set after shutdown channel is created
        shutdown_cancel_sender: None,  // Set after shutdown channel is created
    }));

    // Register types and functions
    {
        let mut world = state.lock().unwrap();
        world
            .engine
            .register_type_with_name::<Entity>("Entity")
            .register_get("id", |entity: &mut Entity| entity.id.to_string())
            .register_get("name", |entity: &mut Entity| entity.name.clone())
            .register_get("description", |entity: &mut Entity| {
                entity.description.clone()
            });

        // Register Rhai functions - pass SharedConnections and SharedState
        script::register_rhai_functions(&mut world.engine, Arc::new(cloned_db_for_rhai), connections.clone(), state.clone());
    }

    // Load and watch scripts
    load_scripts(state.clone())?;
    load_game_data(state.clone())?;
    watch_scripts(state.clone());

    // Start background spawn tick
    let spawn_connections = connections.clone();
    tokio::spawn(async move {
        run_spawn_tick(tick_db, spawn_connections).await;
    });

    // Start background periodic trigger tick
    let tick_connections = connections.clone();
    tokio::spawn(async move {
        run_periodic_trigger_tick(tick_db2, tick_connections).await;
    });

    // Start background time tick (game time advancement)
    let time_connections = connections.clone();
    tokio::spawn(async move {
        run_time_tick(tick_db3, time_connections).await;
    });

    // Start background thirst tick (player thirst updates)
    let thirst_connections = connections.clone();
    tokio::spawn(async move {
        run_thirst_tick(tick_db4, thirst_connections).await;
    });

    // Start background regen tick (stamina and HP regeneration)
    let regen_connections = connections.clone();
    tokio::spawn(async move {
        run_regen_tick(tick_db5, regen_connections).await;
    });

    // Start background wander tick (mobile wandering)
    let wander_connections = connections.clone();
    tokio::spawn(async move {
        run_wander_tick(tick_db6, wander_connections).await;
    });

    // Start background combat tick (combat round processing)
    let combat_connections = connections.clone();
    tokio::spawn(async move {
        run_combat_tick(tick_db7, combat_connections).await;
    });

    // Start background corpse decay tick (corpse cleanup)
    let corpse_connections = connections.clone();
    tokio::spawn(async move {
        run_corpse_decay_tick(tick_db8, corpse_connections).await;
    });

    // Start background exposure tick (weather/temperature effects)
    let exposure_connections = connections.clone();
    tokio::spawn(async move {
        run_exposure_tick(tick_db9, exposure_connections).await;
    });

    // Start background transport tick (elevator/bus/train movement)
    let transport_connections = connections.clone();
    tokio::spawn(async move {
        run_transport_tick(tick_db10, transport_connections).await;
    });

    // Create a dummy entity for the look command
    // This section will need to be refactored or removed as part of character system integration
    /*
    let entity_id = Uuid::new_v4();
    let entity = Entity {
        id: entity_id,
        name: "The Void".to_string(),
        description: "A vast, empty void.".to_string(),
    };
    {
        let world = state.lock().unwrap();
        let serialized_entity = serde_json::to_vec(&entity)?;
        world.db.insert(entity_id.as_bytes(), serialized_entity)?;
    }
    */

    let (shutdown_tx, shutdown_rx) = tokio::sync::oneshot::channel();

    let state2 = state.clone();
    let addr = format!("0.0.0.0:{}", args.port);
    let telnet_server = tokio::spawn(async move {
        let listener = TcpListener::bind(&addr).await.unwrap();
        info!("IronMUD Gateway listening on {}", addr);
        run_server(state2, listener, shutdown_rx).await;
    });

    // Create Matrix message channel
    let (matrix_tx, matrix_rx) = tokio::sync::mpsc::unbounded_channel::<MatrixMessage>();

    // Spawn Matrix bot if configured via environment variables
    if let Some(matrix_config) = MatrixConfig::from_env() {
        let matrix_connections = connections.clone();
        tokio::spawn(async move {
            run_matrix_bot(matrix_config, matrix_connections, matrix_rx).await;
        });
        info!("Matrix bot started");
    } else {
        info!("Matrix integration disabled (MATRIX_HOMESERVER, MATRIX_USER, MATRIX_PASSWORD, MATRIX_ROOM not all set)");
        // Drop the receiver since Matrix is disabled
        drop(matrix_rx);
    }

    // Keep a clone for shutdown notification
    let shutdown_matrix_tx = matrix_tx.clone();

    // Store matrix sender in World for disconnect notifications, and register with Rhai
    {
        let mut world = state.lock().unwrap();
        world.matrix_sender = Some(matrix_tx.clone());
        script::set_matrix_sender(&mut world.engine, matrix_tx);
    }

    // Create shutdown command channel for admin shutdown
    let (admin_shutdown_tx, mut admin_shutdown_rx) = tokio::sync::mpsc::unbounded_channel::<ShutdownCommand>();
    // Create shutdown cancellation channel (false = not cancelled, true = cancelled)
    let (shutdown_cancel_tx, shutdown_cancel_rx) = tokio::sync::watch::channel(false);
    {
        let mut world = state.lock().unwrap();
        world.shutdown_sender = Some(admin_shutdown_tx);
        world.shutdown_cancel_sender = Some(shutdown_cancel_tx);
    }

    // AI Provider selection (Claude or Gemini, but not both)
    let claude_configured = std::env::var("CLAUDE_API_KEY").is_ok();
    let gemini_configured = std::env::var("GEMINI_API_KEY").is_ok();

    if claude_configured && gemini_configured {
        // Both configured - error and disable both
        error!("Both CLAUDE_API_KEY and GEMINI_API_KEY are set. Only one AI provider can be used at a time. Disabling AI integration.");
        // Register a dummy Claude sender that will never receive anything
        let (claude_tx, _) = tokio::sync::mpsc::unbounded_channel::<ClaudeRequest>();
        let mut world = state.lock().unwrap();
        script::set_claude_sender(&mut world.engine, claude_tx, connections.clone());
    } else if let Some(claude_config) = ClaudeConfig::from_env() {
        // Claude enabled
        let (claude_tx, claude_rx) = tokio::sync::mpsc::unbounded_channel::<ClaudeRequest>();
        let claude_connections = connections.clone();
        tokio::spawn(async move {
            run_claude_task(claude_config, claude_connections, claude_rx).await;
        });
        info!("AI integration enabled (Claude)");
        let mut world = state.lock().unwrap();
        script::set_claude_sender(&mut world.engine, claude_tx, connections.clone());
    } else if let Some(gemini_config) = GeminiConfig::from_env() {
        // Gemini enabled
        let (gemini_tx, gemini_rx) = tokio::sync::mpsc::unbounded_channel::<GeminiRequest>();
        let gemini_connections = connections.clone();
        tokio::spawn(async move {
            run_gemini_task(gemini_config, gemini_connections, gemini_rx).await;
        });
        info!("AI integration enabled (Gemini)");
        let mut world = state.lock().unwrap();
        script::set_gemini_sender(&mut world.engine, gemini_tx, connections.clone());
    } else {
        // No AI configured - register dummy sender
        info!("AI integration disabled (no API key set)");
        let (claude_tx, _) = tokio::sync::mpsc::unbounded_channel::<ClaudeRequest>();
        let mut world = state.lock().unwrap();
        script::set_claude_sender(&mut world.engine, claude_tx, connections.clone());
    }

    // Wait for shutdown signal (SIGINT, SIGTERM, or admin command)
    // Loop to handle cancelled shutdowns (allows re-waiting for signals)
    let shutdown_connections = connections.clone();
    #[cfg(unix)]
    {
        use tokio::signal::unix::{signal, SignalKind};
        let mut sigterm = signal(SignalKind::terminate())
            .expect("Failed to set up SIGTERM handler");
        let mut sigint = signal(SignalKind::interrupt())
            .expect("Failed to set up SIGINT handler");

        loop {
            tokio::select! {
                _ = sigint.recv() => {
                    info!("SIGINT received, shutting down...");
                    break;
                }
                _ = sigterm.recv() => {
                    info!("SIGTERM received, shutting down...");
                    break;
                }
                Some(cmd) = admin_shutdown_rx.recv() => {
                    info!("Admin shutdown initiated by {}: {}", cmd.admin_name, cmd.reason);
                    let was_cancelled = run_shutdown_countdown(
                        &shutdown_connections,
                        &shutdown_matrix_tx,
                        cmd,
                        shutdown_cancel_rx.clone(),
                    ).await;
                    if !was_cancelled {
                        break; // Proceed with shutdown
                    }
                    // Reset the cancel flag for next shutdown attempt
                    if let Ok(mut world) = state.lock() {
                        if let Some(ref sender) = world.shutdown_cancel_sender {
                            let _ = sender.send(false);
                        }
                    }
                    info!("Shutdown cancelled, resuming normal operation");
                    // Continue loop to wait for next signal
                }
            }
        }
    }

    #[cfg(not(unix))]
    {
        loop {
            tokio::select! {
                _ = tokio::signal::ctrl_c() => {
                    info!("Ctrl-C received, shutting down...");
                    break;
                }
                Some(cmd) = admin_shutdown_rx.recv() => {
                    info!("Admin shutdown initiated by {}: {}", cmd.admin_name, cmd.reason);
                    let was_cancelled = run_shutdown_countdown(
                        &shutdown_connections,
                        &shutdown_matrix_tx,
                        cmd,
                        shutdown_cancel_rx.clone(),
                    ).await;
                    if !was_cancelled {
                        break; // Proceed with shutdown
                    }
                    // Reset the cancel flag for next shutdown attempt
                    if let Ok(mut world) = state.lock() {
                        if let Some(ref sender) = world.shutdown_cancel_sender {
                            let _ = sender.send(false);
                        }
                    }
                    info!("Shutdown cancelled, resuming normal operation");
                    // Continue loop to wait for next signal
                }
            }
        }
    }

    // Notify all connected players about shutdown
    broadcast_to_all_players(&connections, "\n*** SERVER NOTICE: The server is shutting down. Your progress will be saved. ***\n");

    // Notify Matrix about shutdown
    let _ = shutdown_matrix_tx.send(MatrixMessage::Broadcast("IronMUD server is shutting down.".to_string()));

    // Give Matrix a moment to send the message
    tokio::time::sleep(std::time::Duration::from_millis(500)).await;

    // Signal the server to stop accepting new connections
    let _ = shutdown_tx.send(());

    // Wait for server to finish current connections
    telnet_server.await?;

    // Graceful shutdown: save all active players
    info!("Saving all active players...");
    let saved = {
        let world = state.lock().unwrap();
        save_all_players(&connections, &world.db)
    };
    info!("Saved {} player(s)", saved);

    // Flush database to disk
    info!("Flushing database to disk...");
    {
        let world = state.lock().unwrap();
        if let Err(e) = world.db.flush() {
            error!("Failed to flush database: {}", e);
        }
    }

    info!("Shutdown complete");
    Ok(())
}

/// Run shutdown countdown, broadcasting warnings to all players
/// Returns true if the shutdown was cancelled, false if it should proceed
async fn run_shutdown_countdown(
    connections: &SharedConnections,
    matrix_tx: &tokio::sync::mpsc::UnboundedSender<MatrixMessage>,
    cmd: ShutdownCommand,
    mut cancel_rx: tokio::sync::watch::Receiver<bool>,
) -> bool {
    let mut remaining = cmd.delay_seconds;

    // Initial announcement
    let initial_msg = format!(
        "\n*** SERVER SHUTDOWN INITIATED ***\nReason: {}\nInitiated by: {}\nServer will shut down in {} seconds.\nType 'admin cancel' to abort.\n",
        cmd.reason, cmd.admin_name, remaining
    );
    broadcast_to_all_players(connections, &initial_msg);
    let _ = matrix_tx.send(MatrixMessage::Broadcast(format!(
        "Server shutdown initiated by {} ({}). Shutting down in {} seconds.",
        cmd.admin_name, cmd.reason, remaining
    )));

    // Countdown milestones to announce
    let milestones = [300, 180, 120, 60, 30, 15, 10, 5, 4, 3, 2, 1];

    while remaining > 0 {
        // Check if cancelled
        if *cancel_rx.borrow() {
            broadcast_to_all_players(connections, "\n*** SERVER SHUTDOWN CANCELLED ***\n");
            let _ = matrix_tx.send(MatrixMessage::Broadcast("Server shutdown has been cancelled.".to_string()));
            return true;
        }

        // Find the next milestone
        let next_milestone = milestones.iter()
            .filter(|&&m| m < remaining)
            .max()
            .copied()
            .unwrap_or(0);

        // Sleep until the next milestone (or until done), but check for cancellation
        let sleep_time = remaining - next_milestone;
        if sleep_time > 0 {
            // Sleep in 1-second intervals to check for cancellation more frequently
            for _ in 0..sleep_time {
                tokio::select! {
                    _ = tokio::time::sleep(Duration::from_secs(1)) => {}
                    _ = cancel_rx.changed() => {
                        if *cancel_rx.borrow() {
                            broadcast_to_all_players(connections, "\n*** SERVER SHUTDOWN CANCELLED ***\n");
                            let _ = matrix_tx.send(MatrixMessage::Broadcast("Server shutdown has been cancelled.".to_string()));
                            return true;
                        }
                    }
                }
            }
            remaining = next_milestone;
        }

        // Announce if we hit a milestone
        if remaining > 0 && milestones.contains(&remaining) {
            let unit = if remaining == 1 { "second" } else { "seconds" };
            let msg = format!("\n*** SERVER SHUTDOWN in {} {} ***\n", remaining, unit);
            broadcast_to_all_players(connections, &msg);
        }

        // If we're at 0 or below a milestone, break to continue shutdown
        if remaining == 0 || !milestones.contains(&remaining) {
            break;
        }
    }

    // Final countdown completed
    broadcast_to_all_players(connections, "\n*** SERVER SHUTDOWN NOW ***\n");
    false // Not cancelled, proceed with shutdown
}

/// Background task that processes spawn points periodically
async fn run_spawn_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(SPAWN_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_spawn_points(&db, &connections) {
            error!("Spawn tick error: {}", e);
        }
    }
}

/// Refill container dependencies for existing spawned containers
fn refill_container_dependencies(
    db: &db::Db,
    connections: &SharedConnections,
    sp: &SpawnPointData,
) -> Result<()> {
    // Only process dependencies with Container destination
    let container_deps: Vec<_> = sp
        .dependencies
        .iter()
        .filter(|d| matches!(d.destination, SpawnDestination::Container))
        .collect();

    if container_deps.is_empty() {
        return Ok(());
    }

    // Check each spawned container
    for container_id in &sp.spawned_entities {
        // Verify container still exists and is actually a container
        let _container = match db.get_item_data(container_id)? {
            Some(c) if c.item_type == ItemType::Container => c,
            _ => continue, // Container gone or not a container
        };

        // Get current contents
        let contents = db.get_items_in_container(container_id)?;

        // For each container dependency, check if refill needed
        for dep in &container_deps {
            // Count items with matching vnum already in container
            let current_count = contents
                .iter()
                .filter(|item| item.vnum.as_ref() == Some(&dep.item_vnum))
                .count() as i32;

            // Spawn items to reach the target count
            let needed = dep.count - current_count;
            for _ in 0..needed {
                match db.spawn_item_from_prototype(&dep.item_vnum) {
                    Ok(Some(item)) => {
                        if let Err(e) = db.move_item_to_container(&item.id, container_id) {
                            broadcast_to_builders(
                                connections,
                                &format!("Container refill error: {}", e),
                            );
                            let _ = db.delete_item(&item.id);
                        }
                    }
                    Ok(None) => {
                        // Prototype not found - already warned during initial spawn
                    }
                    Err(e) => {
                        broadcast_to_builders(
                            connections,
                            &format!("Container refill spawn error: {}", e),
                        );
                    }
                }
            }
        }
    }

    Ok(())
}

/// Process all spawn points, respawning entities as needed
fn process_spawn_points(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    let spawn_points = db.list_all_spawn_points()?;

    for sp in spawn_points {
        if !sp.enabled {
            continue;
        }

        // Check if enough time has passed
        if now < sp.last_spawn_time + sp.respawn_interval_secs {
            continue;
        }

        // Clean up dead entity references first
        db.cleanup_spawn_point_refs(&sp.id)?;

        // Reload spawn point after cleanup
        let mut sp = match db.get_spawn_point(&sp.id)? {
            Some(s) => s,
            None => continue,
        };

        // Check current count - only spawn new entity if below max
        let current_count = sp.spawned_entities.len() as i32;
        let needs_new_spawn = current_count < sp.max_count;

        // Spawn new entity if needed
        let spawned_id = if needs_new_spawn {
            match sp.entity_type {
            SpawnEntityType::Mobile => {
                db.spawn_mobile_from_prototype(&sp.vnum)?
                    .and_then(|mobile| {
                        db.move_mobile_to_room(&mobile.id, &sp.room_id).ok();
                        Some(mobile.id)
                    })
            }
            SpawnEntityType::Item => {
                db.spawn_item_from_prototype(&sp.vnum)?
                    .and_then(|item| {
                        db.move_item_to_room(&item.id, &sp.room_id).ok();
                        Some(item.id)
                    })
            }
            }
        } else {
            None
        };

        if let Some(entity_id) = spawned_id {
            // Process spawn dependencies
            let mut dep_success_count = 0;
            for dep in &sp.dependencies {
                for _ in 0..dep.count {
                    // Spawn the dependency item from prototype
                    match db.spawn_item_from_prototype(&dep.item_vnum) {
                        Ok(Some(item)) => {
                            let item_id = item.id;
                            let result = match &dep.destination {
                                SpawnDestination::Inventory => {
                                    db.move_item_to_mobile_inventory(&item_id, &entity_id)
                                }
                                SpawnDestination::Equipped(wear_loc) => {
                                    // Validate the item can be worn at this location
                                    if !item.wear_locations.contains(wear_loc) {
                                        broadcast_to_builders(
                                            connections,
                                            &format!(
                                                "Spawn warning: Item '{}' cannot be equipped at {:?} (not in wear_locations)",
                                                dep.item_vnum, wear_loc
                                            ),
                                        );
                                        // Delete the spawned item since we can't use it
                                        let _ = db.delete_item(&item_id);
                                        continue;
                                    }
                                    db.move_item_to_mobile_equipped(&item_id, &entity_id)
                                }
                                SpawnDestination::Container => {
                                    // For container destination, entity_id should be an item (container)
                                    match db.move_item_to_container(&item_id, &entity_id) {
                                        Ok(_) => Ok(true),
                                        Err(e) => {
                                            broadcast_to_builders(
                                                connections,
                                                &format!(
                                                    "Spawn warning: Cannot put item '{}' in container: {}",
                                                    dep.item_vnum, e
                                                ),
                                            );
                                            // Delete the spawned item since we can't use it
                                            let _ = db.delete_item(&item_id);
                                            continue;
                                        }
                                    }
                                }
                            };

                            match result {
                                Ok(true) => dep_success_count += 1,
                                Ok(false) => {
                                    broadcast_to_builders(
                                        connections,
                                        &format!(
                                            "Spawn warning: Failed to place item '{}' for spawn point {}",
                                            dep.item_vnum, sp.id
                                        ),
                                    );
                                    let _ = db.delete_item(&item_id);
                                }
                                Err(e) => {
                                    broadcast_to_builders(
                                        connections,
                                        &format!(
                                            "Spawn error: Failed to place item '{}': {}",
                                            dep.item_vnum, e
                                        ),
                                    );
                                    let _ = db.delete_item(&item_id);
                                }
                            }
                        }
                        Ok(None) => {
                            broadcast_to_builders(
                                connections,
                                &format!(
                                    "Spawn warning: Item prototype '{}' not found for spawn point {}",
                                    dep.item_vnum, sp.id
                                ),
                            );
                        }
                        Err(e) => {
                            broadcast_to_builders(
                                connections,
                                &format!(
                                    "Spawn error: Failed to spawn item '{}': {}",
                                    dep.item_vnum, e
                                ),
                            );
                        }
                    }
                }
            }

            sp.spawned_entities.push(entity_id);

            if dep_success_count > 0 {
                debug!("Spawned {} with {} dependency items at spawn point {}", sp.vnum, dep_success_count, sp.id);
            } else {
                debug!("Spawned {} at spawn point {}", sp.vnum, sp.id);
            }
        }

        // Refill container dependencies for existing Item spawn points
        if sp.entity_type == SpawnEntityType::Item {
            refill_container_dependencies(db, connections, &sp)?;
        }

        // Update last_spawn_time for this spawn point (whether we spawned or just refilled)
        sp.last_spawn_time = now;
        db.save_spawn_point(sp)?;
    }

    Ok(())
}

/// Periodic trigger tick interval in seconds (more frequent than spawn tick)
const PERIODIC_TRIGGER_INTERVAL_SECS: u64 = 10;

/// Background task that processes periodic room triggers
async fn run_periodic_trigger_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(PERIODIC_TRIGGER_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_periodic_triggers(&db, &connections) {
            error!("Periodic trigger tick error: {}", e);
        }
    }
}

/// Process all periodic room triggers
fn process_periodic_triggers(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use rand::Rng;

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    let rooms = db.list_all_rooms()?;

    for mut room in rooms {
        let mut room_modified = false;

        for (idx, trigger) in room.triggers.iter_mut().enumerate() {
            // Only process periodic triggers
            if trigger.trigger_type != TriggerType::Periodic {
                continue;
            }
            if !trigger.enabled {
                continue;
            }

            // Check if enough time has passed
            if now < trigger.last_fired + trigger.interval_secs {
                continue;
            }

            // Check chance
            if trigger.chance < 100 {
                let roll: i32 = rand::thread_rng().gen_range(1..=100);
                if roll > trigger.chance {
                    // Update timestamp even on failed roll to avoid rapid re-rolls
                    trigger.last_fired = now;
                    room_modified = true;
                    continue;
                }
            }

            // Find all awake players in this room (sleeping players don't see periodic triggers)
            let players_in_room: Vec<_> = {
                let conns = connections.lock().unwrap();
                conns.iter()
                    .filter_map(|(conn_id, session)| {
                        if let Some(ref char) = session.character {
                            if char.current_room_id == room.id
                                && char.position != ironmud::CharacterPosition::Sleeping
                            {
                                return Some((*conn_id, session.sender.clone()));
                            }
                        }
                        None
                    })
                    .collect()
            };

            if players_in_room.is_empty() {
                // No awake players in room, skip trigger execution but don't update timestamp
                continue;
            }

            // Execute trigger for each player in the room
            let script_path = format!("scripts/triggers/{}.rhai", trigger.script_name);
            let script_content = match std::fs::read_to_string(&script_path) {
                Ok(content) => content,
                Err(e) => {
                    debug!("Periodic trigger script not found: {} - {}", script_path, e);
                    continue;
                }
            };

            // Create a minimal Rhai engine for trigger execution
            let mut trigger_engine = rhai::Engine::new();

            // Register basic send function for periodic triggers
            for (conn_id, sender) in &players_in_room {
                let conn_id_str = conn_id.to_string();
                let sender_clone = sender.clone();

                // Register send_client_message for this player
                trigger_engine.register_fn("send_client_message", move |cid: String, message: String| {
                    if cid == conn_id_str {
                        let _ = sender_clone.send(message);
                    }
                });
            }

            // Register broadcast_to_room
            let conns_clone = connections.clone();
            let room_id = room.id;
            trigger_engine.register_fn("broadcast_to_room", move |_rid: String, message: String, _exclude: String| {
                // Broadcast to all in room
                let conns = conns_clone.lock().unwrap();
                for (_, session) in conns.iter() {
                    if let Some(ref char) = session.character {
                        if char.current_room_id == room_id {
                            let _ = session.sender.send(message.clone());
                        }
                    }
                }
            });

            // Register random_int
            trigger_engine.register_fn("random_int", |min: i64, max: i64| {
                if min >= max {
                    return min;
                }
                rand::thread_rng().gen_range(min..=max)
            });

            // Compile and run trigger
            match trigger_engine.compile(&script_content) {
                Ok(ast) => {
                    for (conn_id, _) in &players_in_room {
                        let mut scope = rhai::Scope::new();
                        let room_id_str = room.id.to_string();
                        let conn_id_str = conn_id.to_string();

                        // Build context map
                        let mut context = rhai::Map::new();
                        context.insert("trigger_type".into(), "periodic".into());

                        match trigger_engine.call_fn::<rhai::Dynamic>(
                            &mut scope,
                            &ast,
                            "run_trigger",
                            (room_id_str.clone(), conn_id_str.clone(), context.clone()),
                        ) {
                            Ok(_) => {
                                debug!("Periodic trigger {} executed for player in room {}", trigger.script_name, room.id);
                            }
                            Err(e) => {
                                error!("Periodic trigger script error in {}: {}", script_path, e);
                            }
                        }
                    }
                }
                Err(e) => {
                    error!("Failed to compile periodic trigger script {}: {}", script_path, e);
                }
            }

            // Update last_fired timestamp
            trigger.last_fired = now;
            room_modified = true;
        }

        // Save room if any trigger timestamps were updated
        if room_modified {
            let _ = db.save_room_data(room);
        }
    }

    // Process mobile idle triggers
    process_mobile_idle_triggers(db, connections, now)?;

    // Process fishing bite notifications
    process_fishing_bites(connections, now);

    Ok(())
}

/// Process idle triggers for mobiles in rooms with players
fn process_mobile_idle_triggers(
    db: &db::Db,
    connections: &SharedConnections,
    now: i64,
) -> Result<()> {
    use rand::Rng;
    use ironmud::MobileTriggerType;

    // Build a map of room_id -> list of awake players for rooms with logged-in characters
    // Sleeping players don't see mobile idle actions (emotes, says, etc.)
    let rooms_with_players: std::collections::HashMap<uuid::Uuid, Vec<(uuid::Uuid, tokio::sync::mpsc::UnboundedSender<String>)>> = {
        let conns = connections.lock().unwrap();
        let mut map: std::collections::HashMap<uuid::Uuid, Vec<_>> = std::collections::HashMap::new();
        for (conn_id, session) in conns.iter() {
            if let Some(ref char) = session.character {
                // Skip sleeping players - they don't notice mobile idle actions
                if char.position == ironmud::CharacterPosition::Sleeping {
                    continue;
                }
                map.entry(char.current_room_id)
                    .or_default()
                    .push((*conn_id, session.sender.clone()));
            }
        }
        map
    };

    if rooms_with_players.is_empty() {
        return Ok(());
    }

    // For each room with players, check mobiles for idle triggers
    for (room_id, players) in &rooms_with_players {
        let mobiles = db.get_mobiles_in_room(room_id)?;

        for mut mobile in mobiles {
            let mut mobile_modified = false;

            // Extract mobile info needed for trigger execution before iterating
            let mobile_name = mobile.name.clone();
            let mobile_id = mobile.id;
            let mobile_room_id = mobile.current_room_id;

            for trigger in mobile.triggers.iter_mut() {
                // Only process OnIdle triggers
                if trigger.trigger_type != MobileTriggerType::OnIdle {
                    continue;
                }
                if !trigger.enabled {
                    continue;
                }

                // Check if enough time has passed
                if now < trigger.last_fired + trigger.interval_secs {
                    continue;
                }

                // Check chance
                if trigger.chance < 100 {
                    let roll: i32 = rand::thread_rng().gen_range(1..=100);
                    if roll > trigger.chance {
                        // Update timestamp even on failed roll to avoid rapid re-rolls
                        trigger.last_fired = now;
                        mobile_modified = true;
                        continue;
                    }
                }

                // Execute the trigger with extracted mobile info
                execute_mobile_idle_trigger(
                    &mobile_name,
                    mobile_id,
                    mobile_room_id,
                    trigger,
                    players,
                );

                trigger.last_fired = now;
                mobile_modified = true;
            }

            if mobile_modified {
                let _ = db.save_mobile_data(mobile);
            }
        }
    }

    Ok(())
}

/// Execute a mobile idle trigger (template or custom script)
fn execute_mobile_idle_trigger(
    mobile_name: &str,
    mobile_id: uuid::Uuid,
    mobile_room_id: Option<uuid::Uuid>,
    trigger: &ironmud::MobileTrigger,
    players: &[(uuid::Uuid, tokio::sync::mpsc::UnboundedSender<String>)],
) {
    use rand::Rng;

    // Handle built-in templates (script_name starts with @)
    if trigger.script_name.starts_with('@') {
        let template_name = &trigger.script_name[1..];
        execute_mobile_idle_template(template_name, &trigger.args, mobile_name, players);
        return;
    }

    // Load and execute custom trigger script
    let script_path = format!("scripts/triggers/{}.rhai", trigger.script_name);
    let script_content = match std::fs::read_to_string(&script_path) {
        Ok(c) => c,
        Err(e) => {
            tracing::warn!("Failed to load mobile idle trigger script {}: {}", script_path, e);
            return;
        }
    };

    // Create engine and execute
    let mut trigger_engine = rhai::Engine::new();

    // Register broadcast function for idle triggers
    let players_clone: Vec<_> = players.iter().map(|(_, s)| s.clone()).collect();
    trigger_engine.register_fn("broadcast_to_room", move |_rid: String, message: String, _exclude: String| {
        for sender in &players_clone {
            let _ = sender.send(format!("{}\n", message));
        }
    });

    // Register random_int
    trigger_engine.register_fn("random_int", |min: i64, max: i64| {
        if min >= max {
            return min;
        }
        rand::thread_rng().gen_range(min..=max)
    });

    // Register get_mobile_data to return the mobile info
    let mobile_name_clone = mobile_name.to_string();
    trigger_engine.register_fn("get_mobile_data", move |_id: String| {
        let mut map = rhai::Map::new();
        map.insert("name".into(), mobile_name_clone.clone().into());
        map
    });

    // Compile and run trigger
    match trigger_engine.compile(&script_content) {
        Ok(ast) => {
            let mut scope = rhai::Scope::new();
            let mobile_id_str = mobile_id.to_string();
            let room_id_str = mobile_room_id.map(|r| r.to_string()).unwrap_or_default();

            // Build context map
            let mut context = rhai::Map::new();
            context.insert("trigger_type".into(), "idle".into());
            context.insert("mobile_name".into(), mobile_name.to_string().into());

            match trigger_engine.call_fn::<rhai::Dynamic>(
                &mut scope,
                &ast,
                "run_trigger",
                (mobile_id_str, room_id_str, context),
            ) {
                Ok(_) => {
                    debug!("Mobile idle trigger {} executed for {}", trigger.script_name, mobile_name);
                }
                Err(e) => {
                    error!("Mobile idle trigger script error in {}: {}", script_path, e);
                }
            }
        }
        Err(e) => {
            error!("Failed to compile mobile idle trigger script {}: {}", script_path, e);
        }
    }
}

/// Execute a built-in mobile idle template
fn execute_mobile_idle_template(
    template_name: &str,
    args: &[String],
    mobile_name: &str,
    players: &[(uuid::Uuid, tokio::sync::mpsc::UnboundedSender<String>)],
) {
    use rand::Rng;

    let broadcast = |msg: &str| {
        for (_, sender) in players {
            let _ = sender.send(format!("{}\n", msg));
        }
    };

    match template_name {
        "say_greeting" | "say_idle" => {
            if let Some(message) = args.first() {
                broadcast(&format!("{} says: \"{}\"", mobile_name, message));
            }
        }
        "say_random" | "idle_random" => {
            if !args.is_empty() {
                let idx = rand::thread_rng().gen_range(0..args.len());
                broadcast(&format!("{} says: \"{}\"", mobile_name, args[idx]));
            }
        }
        "emote" | "emote_idle" => {
            if let Some(action) = args.first() {
                broadcast(&format!("{} {}", mobile_name, action));
            }
        }
        _ => {
            tracing::warn!("Unknown mobile idle template: @{}", template_name);
        }
    }
}

/// Process fishing bite notifications for players who are currently fishing
fn process_fishing_bites(connections: &SharedConnections, now: i64) {
    let mut conns = connections.lock().unwrap();

    for (_conn_id, session) in conns.iter_mut() {
        // Skip if not fishing
        let fishing_state = match &mut session.fishing_state {
            Some(state) => state,
            None => continue,
        };

        // Skip if bite hasn't happened yet
        if now < fishing_state.bite_time {
            continue;
        }

        // Check if player is still in the same room
        if let Some(ref char) = session.character {
            if char.current_room_id != fishing_state.room_id {
                // Player moved - cancel fishing
                session.fishing_state = None;
                let _ = session.sender.send("Your fishing line snaps as you moved away from the water!\n".to_string());
                continue;
            }
        }

        // Calculate how long the bite has been waiting (they might miss it if they wait too long)
        let wait_time = now - fishing_state.bite_time;

        // First notification: something tugged the line (send once)
        if !fishing_state.bite_notified {
            fishing_state.bite_notified = true;
            let _ = session.sender.send("\n*** Something tugs at your line! Type 'reel' to pull it in! ***\n".to_string());
        } else if wait_time >= 5 && !fishing_state.warning_notified {
            // Warning after 5 seconds (send once)
            fishing_state.warning_notified = true;
            let _ = session.sender.send("\n*** Your line is still taut... 'reel' before it gets away! ***\n".to_string());
        } else if wait_time >= 15 {
            // Fish got away after 15 seconds of not reeling
            session.fishing_state = None;
            let _ = session.sender.send("\nYou waited too long and the fish got away!\n".to_string());
        }
    }
}

/// Fire environmental triggers (time change or weather change) for all rooms
fn fire_environmental_triggers(
    db: &db::Db,
    connections: &SharedConnections,
    trigger_type: TriggerType,
    context: &std::collections::HashMap<String, String>,
) -> Result<()> {
    use rand::Rng;

    let rooms = db.list_all_rooms()?;

    for room in rooms {
        // For time, weather, and season triggers, skip indoor/climate_controlled rooms
        if trigger_type == TriggerType::OnTimeChange || trigger_type == TriggerType::OnWeatherChange || trigger_type == TriggerType::OnSeasonChange {
            // Check for climate_controlled (room or area inherited)
            let is_climate_controlled = room.flags.climate_controlled ||
                room.area_id.and_then(|aid| db.get_area_data(&aid).ok().flatten())
                    .map(|area| area.flags.climate_controlled)
                    .unwrap_or(false);
            if room.flags.indoors || is_climate_controlled {
                continue;
            }
        }

        // Find matching triggers
        for trigger in &room.triggers {
            if trigger.trigger_type != trigger_type || !trigger.enabled {
                continue;
            }

            // Check chance
            if trigger.chance < 100 {
                let roll: i32 = rand::thread_rng().gen_range(1..=100);
                if roll > trigger.chance {
                    continue;
                }
            }

            // Find all awake players in this room (sleeping players don't see environmental triggers)
            let players_in_room: Vec<(uuid::Uuid, tokio::sync::mpsc::UnboundedSender<String>)> = {
                let conns = connections.lock().unwrap();
                conns.iter()
                    .filter_map(|(conn_id, session)| {
                        if let Some(ref char) = session.character {
                            if char.current_room_id == room.id
                                && char.position != ironmud::CharacterPosition::Sleeping
                            {
                                return Some((*conn_id, session.sender.clone()));
                            }
                        }
                        None
                    })
                    .collect()
            };

            if players_in_room.is_empty() {
                continue;
            }

            // Handle built-in templates (script_name starts with @)
            if trigger.script_name.starts_with('@') {
                let template_name = &trigger.script_name[1..];
                execute_room_template_main(
                    template_name,
                    &trigger.args,
                    &room.id,
                    connections,
                    context,
                );
                continue;
            }

            // Execute trigger script
            let script_path = format!("scripts/triggers/{}.rhai", trigger.script_name);
            let script_content = match std::fs::read_to_string(&script_path) {
                Ok(content) => content,
                Err(e) => {
                    debug!("Environmental trigger script not found: {} - {}", script_path, e);
                    continue;
                }
            };

            // Create a minimal Rhai engine for trigger execution
            let mut trigger_engine = rhai::Engine::new();

            // Register send_client_message
            for (conn_id, sender) in &players_in_room {
                let conn_id_str = conn_id.to_string();
                let sender_clone = sender.clone();

                trigger_engine.register_fn("send_client_message", move |cid: String, message: String| {
                    if cid == conn_id_str {
                        let _ = sender_clone.send(message);
                    }
                });
            }

            // Register broadcast_to_room
            let conns_clone = connections.clone();
            let room_id = room.id;
            trigger_engine.register_fn("broadcast_to_room", move |_rid: String, message: String, _exclude: String| {
                let conns = conns_clone.lock().unwrap();
                for (_, session) in conns.iter() {
                    if let Some(ref char) = session.character {
                        if char.current_room_id == room_id {
                            let _ = session.sender.send(message.clone());
                        }
                    }
                }
            });

            // Register random_int
            trigger_engine.register_fn("random_int", |min: i64, max: i64| {
                if min >= max {
                    return min;
                }
                rand::thread_rng().gen_range(min..=max)
            });

            // Compile and run trigger
            match trigger_engine.compile(&script_content) {
                Ok(ast) => {
                    for (conn_id, _) in &players_in_room {
                        let mut scope = rhai::Scope::new();
                        let room_id_str = room.id.to_string();
                        let conn_id_str = conn_id.to_string();

                        // Build context map
                        let mut rhai_context = rhai::Map::new();
                        for (k, v) in context {
                            rhai_context.insert(k.clone().into(), v.clone().into());
                        }

                        match trigger_engine.call_fn::<rhai::Dynamic>(
                            &mut scope,
                            &ast,
                            "run_trigger",
                            (room_id_str.clone(), conn_id_str.clone(), rhai_context.clone()),
                        ) {
                            Ok(_) => {
                                debug!("Environmental trigger {} executed for room {}", trigger.script_name, room.id);
                            }
                            Err(e) => {
                                error!("Environmental trigger script error in {}: {}", script_path, e);
                            }
                        }
                    }
                }
                Err(e) => {
                    error!("Failed to compile environmental trigger script {}: {}", script_path, e);
                }
            }
        }
    }

    Ok(())
}

/// Execute a built-in room template for environmental triggers
fn execute_room_template_main(
    template_name: &str,
    args: &[String],
    room_id: &uuid::Uuid,
    connections: &SharedConnections,
    context: &std::collections::HashMap<String, String>,
) {
    // Helper to broadcast message to all players in the room
    let broadcast = |msg: &str| {
        if let Ok(conns) = connections.lock() {
            for (_, session) in conns.iter() {
                if let Some(ref char_data) = session.character {
                    if char_data.current_room_id == *room_id {
                        let _ = session.sender.send(format!("{}\n", msg));
                    }
                }
            }
        }
    };

    match template_name {
        "room_message" => {
            if let Some(message) = args.first() {
                broadcast(message);
            }
        }
        "time_message" => {
            if args.len() >= 2 {
                let target_time = &args[0].to_lowercase();
                let message = &args[1];

                if let Some(new_time) = context.get("new_time") {
                    if new_time.to_lowercase() == *target_time {
                        broadcast(message);
                    }
                }
            }
        }
        "weather_message" => {
            if args.len() >= 2 {
                let target_weather = args[0].to_lowercase();
                let message = &args[1];

                if let Some(new_weather) = context.get("new_weather") {
                    let weather_lower = new_weather.to_lowercase();
                    let matches = weather_lower == target_weather
                        || (target_weather == "raining" && (weather_lower.contains("rain") || weather_lower == "thunderstorm"))
                        || (target_weather == "snowing" && weather_lower.contains("snow"))
                        || (target_weather == "stormy" && weather_lower == "thunderstorm")
                        || (target_weather == "precipitation" && (weather_lower.contains("rain") || weather_lower.contains("snow")));

                    if matches {
                        broadcast(message);
                    }
                }
            }
        }
        "season_message" => {
            if args.len() >= 2 {
                let target_season = args[0].to_lowercase();
                let message = &args[1];

                if let Some(new_season) = context.get("new_season") {
                    if new_season.to_lowercase() == target_season {
                        broadcast(message);
                    }
                }
            }
        }
        _ => {
            debug!("Unknown room template: @{}", template_name);
        }
    }
}

// === Game Time Tick System ===

/// Background task that advances game time periodically
async fn run_time_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(TIME_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_time_tick(&db, &connections) {
            error!("Time tick error: {}", e);
        }
    }
}

/// Process game time advancement
fn process_time_tick(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use ironmud::{TimeOfDay, WeatherCondition, Season};

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    let mut game_time = db.get_game_time()?;
    let old_time_of_day = game_time.get_time_of_day();
    let old_weather = game_time.weather;
    let old_season = game_time.get_season();
    let old_month = game_time.month;

    // Advance time by 1 hour
    game_time.advance_hour();

    let new_time_of_day = game_time.get_time_of_day();
    let new_season = game_time.get_season();

    // Broadcast time-of-day transitions to players who can see outside
    if old_time_of_day != new_time_of_day {
        let message = get_time_transition_message(&new_time_of_day);
        broadcast_to_outdoor_players(db, connections, &format!("\n{}\n", message));

        // Fire OnTimeChange triggers
        let mut context = std::collections::HashMap::new();
        context.insert("old_time".to_string(), format!("{}", old_time_of_day));
        context.insert("new_time".to_string(), format!("{}", new_time_of_day));
        context.insert("is_dawn".to_string(), (new_time_of_day == TimeOfDay::Dawn).to_string());
        context.insert("is_dusk".to_string(), (new_time_of_day == TimeOfDay::Dusk).to_string());
        context.insert("is_night".to_string(), (new_time_of_day == TimeOfDay::Night).to_string());
        context.insert("is_day".to_string(), game_time.is_daytime().to_string());

        if let Err(e) = fire_environmental_triggers(db, connections, TriggerType::OnTimeChange, &context) {
            error!("Error firing time change triggers: {}", e);
        }
    }

    // Update weather periodically (every ~15 game hours = 30 real minutes)
    if now - game_time.last_weather_change >= 1800 {
        update_weather(&mut game_time);
        game_time.last_weather_change = now;

        // Fire OnWeatherChange triggers if weather actually changed
        if game_time.weather != old_weather {
            let mut context = std::collections::HashMap::new();
            context.insert("old_weather".to_string(), format!("{:?}", old_weather).to_lowercase());
            context.insert("new_weather".to_string(), format!("{:?}", game_time.weather).to_lowercase());

            // Helper flags for common weather categories
            let is_raining = matches!(game_time.weather,
                WeatherCondition::LightRain | WeatherCondition::Rain |
                WeatherCondition::HeavyRain | WeatherCondition::Thunderstorm);
            let is_snowing = matches!(game_time.weather,
                WeatherCondition::LightSnow | WeatherCondition::Snow | WeatherCondition::Blizzard);
            let is_clear = matches!(game_time.weather,
                WeatherCondition::Clear | WeatherCondition::PartlyCloudy);

            context.insert("is_raining".to_string(), is_raining.to_string());
            context.insert("is_snowing".to_string(), is_snowing.to_string());
            context.insert("is_clear".to_string(), is_clear.to_string());

            if let Err(e) = fire_environmental_triggers(db, connections, TriggerType::OnWeatherChange, &context) {
                error!("Error firing weather change triggers: {}", e);
            }
        }
    }

    // Fire OnSeasonChange triggers if season changed
    if old_season != new_season {
        let message = get_season_transition_message(&new_season);
        broadcast_to_all_players(connections, &format!("\n{}\n", message));

        let mut context = std::collections::HashMap::new();
        context.insert("old_season".to_string(), format!("{}", old_season).to_lowercase());
        context.insert("new_season".to_string(), format!("{}", new_season).to_lowercase());
        context.insert("is_spring".to_string(), (new_season == Season::Spring).to_string());
        context.insert("is_summer".to_string(), (new_season == Season::Summer).to_string());
        context.insert("is_autumn".to_string(), (new_season == Season::Autumn).to_string());
        context.insert("is_winter".to_string(), (new_season == Season::Winter).to_string());

        if let Err(e) = fire_environmental_triggers(db, connections, TriggerType::OnSeasonChange, &context) {
            error!("Error firing season change triggers: {}", e);
        }
    }

    // Fire OnMonthChange triggers if month changed
    if old_month != game_time.month {
        let mut context = std::collections::HashMap::new();
        context.insert("old_month".to_string(), old_month.to_string());
        context.insert("new_month".to_string(), game_time.month.to_string());
        context.insert("new_day".to_string(), game_time.day.to_string());
        context.insert("new_year".to_string(), game_time.year.to_string());

        // Festival flags for common events (every 4th month)
        let is_festival = game_time.month == 4 || game_time.month == 8 || game_time.month == 12;
        context.insert("is_festival".to_string(), is_festival.to_string());

        if let Err(e) = fire_environmental_triggers(db, connections, TriggerType::OnMonthChange, &context) {
            error!("Error firing month change triggers: {}", e);
        }
    }

    game_time.last_time_tick = now;
    db.save_game_time(&game_time)?;

    Ok(())
}

/// Get the message to broadcast when time of day changes
fn get_time_transition_message(tod: &ironmud::TimeOfDay) -> &'static str {
    use ironmud::TimeOfDay;
    match tod {
        TimeOfDay::Dawn => "The sun begins to rise on the horizon, painting the sky in shades of orange and pink.",
        TimeOfDay::Morning => "The morning sun casts long shadows across the land.",
        TimeOfDay::Noon => "The sun reaches its peak in the sky, bathing everything in bright light.",
        TimeOfDay::Afternoon => "The afternoon sun warms the land as the day continues.",
        TimeOfDay::Dusk => "The sun begins to set, painting the sky in orange and crimson hues.",
        TimeOfDay::Evening => "Twilight settles over the land as stars begin to appear.",
        TimeOfDay::Night => "Darkness falls as night takes hold. The stars shine brightly overhead.",
    }
}

/// Get the message to broadcast when season changes
fn get_season_transition_message(season: &ironmud::Season) -> &'static str {
    use ironmud::Season;
    match season {
        Season::Spring => "The air grows warmer as spring arrives. Flowers begin to bloom across the land.",
        Season::Summer => "Summer has arrived! The sun beats down warmly and the days grow long.",
        Season::Autumn => "The leaves begin to change color as autumn settles in. A cool breeze carries the scent of fallen leaves.",
        Season::Winter => "Winter descends upon the land. A chill fills the air as frost blankets the ground.",
    }
}

/// Update weather conditions based on season and randomness
fn update_weather(game_time: &mut ironmud::GameTime) {
    use rand::Rng;
    use ironmud::{WeatherCondition, Season};

    let mut rng = rand::thread_rng();

    // Weather transition probabilities based on season
    let (rain_chance, snow_chance, clear_chance) = match game_time.get_season() {
        Season::Spring => (30, 5, 40),
        Season::Summer => (20, 0, 60),
        Season::Autumn => (35, 10, 35),
        Season::Winter => (15, 40, 30),
    };

    let roll: i32 = rng.gen_range(1..=100);

    game_time.weather = if roll <= clear_chance {
        if rng.gen_bool(0.3) { WeatherCondition::PartlyCloudy } else { WeatherCondition::Clear }
    } else if roll <= clear_chance + rain_chance {
        // Check if it should be snow instead in cold conditions
        if game_time.get_season() == Season::Winter && game_time.calculate_effective_temperature() < 2 {
            match rng.gen_range(1..=3) {
                1 => WeatherCondition::LightSnow,
                2 => WeatherCondition::Snow,
                _ => WeatherCondition::Blizzard,
            }
        } else {
            match rng.gen_range(1..=4) {
                1 => WeatherCondition::LightRain,
                2 => WeatherCondition::Rain,
                3 => WeatherCondition::HeavyRain,
                _ => WeatherCondition::Thunderstorm,
            }
        }
    } else if roll <= clear_chance + rain_chance + snow_chance {
        match rng.gen_range(1..=3) {
            1 => WeatherCondition::LightSnow,
            2 => WeatherCondition::Snow,
            _ => WeatherCondition::Blizzard,
        }
    } else {
        match rng.gen_range(1..=3) {
            1 => WeatherCondition::Cloudy,
            2 => WeatherCondition::Overcast,
            _ => WeatherCondition::Fog,
        }
    };

    // Adjust base temperature with some randomness
    game_time.base_temperature = 18 + rng.gen_range(-5..=5);
}

// === Thirst Tick System ===

/// Background task that processes player thirst periodically
async fn run_thirst_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(THIRST_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_thirst_tick(&db, &connections) {
            error!("Thirst tick error: {}", e);
        }
    }
}

/// Process thirst for all logged-in players
fn process_thirst_tick(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use ironmud::TemperatureCategory;

    let game_time = db.get_game_time()?;
    let temp_category = game_time.get_temperature_category();

    let mut conns = connections.lock().unwrap();

    for (conn_id, session) in conns.iter_mut() {
        if let Some(ref mut char) = session.character {
            // Skip if character creation is not complete
            if !char.creation_complete {
                continue;
            }

            // Skip thirst for god mode players
            if char.god_mode {
                continue;
            }

            // Calculate base thirst decrease
            let mut decrease = 1;

            // Add temperature modifier (Hot: 1.5x, Sweltering: 2x thirst)
            // Since base is 1, we add 1 for each tier to achieve roughly the multiplier
            let temp_modifier = match temp_category {
                TemperatureCategory::Sweltering => 1, // 2x thirst depletion
                TemperatureCategory::Hot => 1,        // ~1.5x thirst depletion (rounded up)
                _ => 0,
            };

            // Check for traits that modify thirst
            let has_camel = char.traits.iter().any(|t| t == "camel");
            let has_desert_born = char.traits.iter().any(|t| t == "desert_born");
            let has_parched = char.traits.iter().any(|t| t == "parched");

            // Apply heat thirst modifier (unless desert_born)
            if !has_desert_born {
                decrease += temp_modifier;
            }

            // Calculate insulation from equipped items
            let insulation = calculate_character_insulation(char, db);
            if temp_modifier > 0 && insulation > 0 {
                // Reduce heat thirst by insulation percentage (but insulation might make you hotter...)
                // Actually, insulation keeps you warm in cold, but makes you hotter in heat
                // So we'll skip insulation reduction for heat-based thirst
            }

            // Apply trait modifiers
            if has_camel {
                // 50% reduction
                decrease = (decrease + 1) / 2;
            }
            if has_parched {
                // 50% increase
                decrease = decrease + decrease / 2;
            }

            // Position modifier - 50% reduction while sitting or sleeping
            if char.position == ironmud::CharacterPosition::Sitting || char.position == ironmud::CharacterPosition::Sleeping {
                decrease = (decrease + 1) / 2;
            }

            // Ensure minimum decrease of 1
            decrease = decrease.max(1);

            let old_thirst = char.thirst;
            char.thirst = (char.thirst - decrease).max(0);

            // Send thirst messages at thresholds
            if let Some(msg) = get_thirst_message(old_thirst, char.thirst, char.max_thirst) {
                let _ = session.sender.send(format!("\n{}\n", msg));
            }

            // Save character if thirst changed
            if old_thirst != char.thirst {
                let _ = db.save_character_data(char.clone());
            }
        }
    }

    Ok(())
}

/// Get thirst message when crossing a threshold
fn get_thirst_message(old: i32, new: i32, max: i32) -> Option<&'static str> {
    let old_pct = (old * 100) / max;
    let new_pct = (new * 100) / max;

    // Only send message when crossing a threshold downward
    if old_pct > 75 && new_pct <= 75 {
        Some("You're starting to feel a bit thirsty.")
    } else if old_pct > 50 && new_pct <= 50 {
        Some("You are thirsty. You should find something to drink.")
    } else if old_pct > 25 && new_pct <= 25 {
        Some("You are very thirsty! Your throat is parched.")
    } else if old_pct > 10 && new_pct <= 10 {
        Some("You are EXTREMELY thirsty! Find water immediately!")
    } else if new == 0 && old > 0 {
        Some("You are dying of thirst! You need water NOW or you will perish!")
    } else {
        None
    }
}

/// Calculate total insulation from equipped items
fn calculate_character_insulation(char: &ironmud::CharacterData, db: &db::Db) -> i32 {
    let mut total_insulation = 0;

    // Query database for equipped items (source of truth is ItemLocation::Equipped)
    if let Ok(equipped_items) = db.get_equipped_items(&char.name) {
        for item in equipped_items {
            total_insulation += item.insulation;
        }
    }

    total_insulation.min(100) // Cap at 100
}

// === Stamina/HP Regeneration Tick System ===

/// Background task that processes stamina and HP regeneration
async fn run_regen_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(REGEN_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_regen_tick(&db, &connections) {
            error!("Regen tick error: {}", e);
        }
    }
}

/// Process stamina and HP regeneration for all logged-in players
fn process_regen_tick(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use ironmud::CharacterPosition;

    let mut conns = connections.lock().unwrap();

    for (_conn_id, session) in conns.iter_mut() {
        if let Some(ref mut char) = session.character {
            // Skip if character creation is not complete
            if !char.creation_complete {
                continue;
            }

            let mut modified = false;
            let old_stamina = char.stamina;
            let old_position = char.position;

            // Stamina regeneration based on position
            let mut stamina_regen = match char.position {
                CharacterPosition::Standing => 1,
                CharacterPosition::Sitting => 3,
                CharacterPosition::Sleeping => 5,
            };

            // Check for stamina regen traits
            let has_quick_recovery = char.traits.iter().any(|t| t == "quick_recovery");
            let has_slow_recovery = char.traits.iter().any(|t| t == "slow_recovery");
            let has_marathoner = char.traits.iter().any(|t| t == "marathoner");

            // Apply trait modifiers
            if has_quick_recovery {
                // 50% increase
                stamina_regen = stamina_regen + stamina_regen / 2;
            }
            if has_marathoner {
                // 25% increase
                stamina_regen = stamina_regen + stamina_regen / 4;
            }
            if has_slow_recovery {
                // 50% reduction (minimum 1)
                stamina_regen = (stamina_regen / 2).max(1);
            }

            if char.stamina < char.max_stamina {
                char.stamina = (char.stamina + stamina_regen).min(char.max_stamina);
                modified = true;
            }

            // HP regeneration based on position
            let hp_regen = match char.position {
                CharacterPosition::Standing => 0,
                CharacterPosition::Sitting => 1,
                CharacterPosition::Sleeping => 2,
            };

            if char.hp < char.max_hp && hp_regen > 0 {
                char.hp = (char.hp + hp_regen).min(char.max_hp);
                modified = true;
            }

            // Wake notification when reaching 10% stamina (from forced sleep)
            if char.position == CharacterPosition::Sleeping && old_stamina == 0 {
                let wake_threshold = char.max_stamina / 10;
                if char.stamina >= wake_threshold {
                    let _ = session.sender.send(
                        "\nYou feel rested enough to wake up. Type 'wake' to get up.\n".to_string()
                    );
                }
            }

            // Stamina warning messages (decreasing)
            if let Some(msg) = get_stamina_message(old_stamina, char.stamina, char.max_stamina) {
                let _ = session.sender.send(format!("\n{}\n", msg));
            }

            // Force sleep at 0 stamina
            if char.stamina == 0 && old_position != CharacterPosition::Sleeping {
                char.position = CharacterPosition::Sleeping;
                modified = true;
                let _ = session.sender.send(
                    "\nYou collapse from exhaustion and fall into a deep sleep!\n".to_string()
                );
            }

            if modified {
                let _ = db.save_character_data(char.clone());
            }
        }
    }

    Ok(())
}

/// Get stamina message when crossing a threshold (decreasing only)
fn get_stamina_message(old: i32, new: i32, max: i32) -> Option<&'static str> {
    let old_pct = (old * 100) / max;
    let new_pct = (new * 100) / max;

    // Only send message when crossing a threshold downward
    if old_pct > 50 && new_pct <= 50 {
        Some("You're starting to feel tired.")
    } else if old_pct > 25 && new_pct <= 25 {
        Some("You are getting exhausted! Consider resting.")
    } else if old_pct > 10 && new_pct <= 10 {
        Some("You are EXTREMELY tired! You need to rest soon!")
    } else if old_pct > 5 && new_pct <= 5 {
        Some("You can barely keep your eyes open! Rest immediately or you will collapse!")
    } else {
        None
    }
}

// === Mobile Wandering Tick System ===

/// Background task that processes mobile wandering periodically
async fn run_wander_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(WANDER_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_wander_tick(&db, &connections) {
            error!("Wander tick error: {}", e);
        }
    }
}

/// Process wandering for all non-sentinel mobiles
fn process_wander_tick(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use rand::seq::SliceRandom;
    use rand::Rng;

    let mobiles = db.list_all_mobiles()?;
    let mut rng = rand::thread_rng();

    for mobile in mobiles {
        // Skip prototypes - only process spawned instances
        if mobile.is_prototype {
            continue;
        }

        // Skip sentinel mobiles (they never wander)
        if mobile.flags.sentinel {
            continue;
        }

        // Re-fetch the mobile from DB to get current combat state
        // (combat state may have changed since we loaded the list)
        let current_mobile = match db.get_mobile_data(&mobile.id)? {
            Some(m) => m,
            None => continue, // Mobile was deleted
        };

        // Skip mobiles in combat (using fresh data)
        if current_mobile.combat.in_combat {
            debug!("Wander: skipping {} - in combat (targets={})", current_mobile.name, current_mobile.combat.targets.len());
            continue;
        }

        // Skip dead mobiles (safety check, using fresh data)
        if current_mobile.current_hp <= 0 {
            debug!("Wander: skipping {} - dead (hp={})", current_mobile.name, current_mobile.current_hp);
            continue;
        }

        // Check for aggressive behavior BEFORE wandering
        // Aggressive mobiles attack players on sight
        if current_mobile.flags.aggressive {
            if let Some(room_id) = current_mobile.current_room_id {
                // Check if room allows combat (not a safe zone)
                if let Ok(Some(room)) = db.get_room_data(&room_id) {
                    let is_safe =
                        room.flags.combat_zone == Some(ironmud::CombatZoneType::Safe);

                    if !is_safe {
                        // Find a player in the room to attack
                        if let Some(player_name) = find_player_name_in_room(connections, &room_id) {
                            debug!(
                                "Aggressive: {} attacking player {} in room {}",
                                current_mobile.name, player_name, room_id
                            );

                            // Get the player's character data
                            if let Ok(Some(mut char)) = db.get_character_data(&player_name) {
                                // Check if player is sleeping - wake them up
                                let was_sleeping =
                                    char.position == ironmud::CharacterPosition::Sleeping;
                                if was_sleeping {
                                    char.position = ironmud::CharacterPosition::Standing;
                                    send_message_to_character(
                                        connections,
                                        &player_name,
                                        "You are jolted awake by an attack!",
                                    );
                                    broadcast_to_room_except_awake(
                                        connections,
                                        &room_id,
                                        &format!("{} is jolted awake!", char.name),
                                        &player_name,
                                    );
                                }

                                // Put the mobile in combat with the player
                                let mut mobile_to_save = current_mobile.clone();
                                mobile_to_save.combat.in_combat = true;
                                // For player targets, use nil UUID (found by room)
                                if !mobile_to_save
                                    .combat
                                    .targets
                                    .iter()
                                    .any(|t| t.target_type == ironmud::CombatTargetType::Player)
                                {
                                    mobile_to_save
                                        .combat
                                        .targets
                                        .push(ironmud::CombatTarget {
                                            target_type: ironmud::CombatTargetType::Player,
                                            target_id: uuid::Uuid::nil(),
                                        });
                                }
                                let _ = db.save_mobile_data(mobile_to_save);

                                // Put the player in combat with this mobile
                                char.combat.in_combat = true;
                                if !char.combat.targets.iter().any(|t| t.target_id == current_mobile.id) {
                                    char.combat.targets.push(ironmud::CombatTarget {
                                        target_type: ironmud::CombatTargetType::Mobile,
                                        target_id: current_mobile.id,
                                    });
                                }
                                let _ = db.save_character_data(char.clone());
                                sync_character_to_session(connections, &char);

                                // Notify the room (sleeping players don't see this)
                                broadcast_to_room_awake(
                                    connections,
                                    &room_id,
                                    &format!(
                                        "{} snarls and attacks {}!",
                                        current_mobile.name, player_name
                                    ),
                                );

                                // Skip wandering - mobile is now in combat
                                continue;
                            }
                        }
                    }
                }
            }
        }

        // Random chance to stay in place
        if rng.gen_range(0..100) >= WANDER_CHANCE_PERCENT {
            continue;
        }

        // Skip mobiles not in a room (use current_mobile for fresh room data)
        let mobile_room_id = match current_mobile.current_room_id {
            Some(id) => id,
            None => continue,
        };

        // Get current room data
        let current_room = match db.get_room_data(&mobile_room_id)? {
            Some(r) => r,
            None => continue,
        };

        // Build list of valid exits
        let valid_exits = get_valid_wander_exits(db, &current_room)?;

        if valid_exits.is_empty() {
            continue;
        }

        // Randomly select an exit
        let (direction, target_room_id) = match valid_exits.choose(&mut rng) {
            Some(exit) => exit.clone(),
            None => continue,
        };

        // Move the mobile
        debug!("Wander: moving {} ({}) from room {} to room {} ({})",
               current_mobile.name, current_mobile.id, mobile_room_id, target_room_id, direction);
        if db.move_mobile_to_room(&current_mobile.id, &target_room_id).is_ok() {
            // Broadcast departure message
            let departure_msg = format!("{} leaves heading {}.\n", current_mobile.name, direction);
            broadcast_to_room_mobiles(connections, &mobile_room_id, &departure_msg);

            // Broadcast arrival message
            let arrival_dir = get_opposite_direction_rust(&direction);
            let arrival_msg = format!("{} arrives from the {}.\n", current_mobile.name, arrival_dir);
            broadcast_to_room_mobiles(connections, &target_room_id, &arrival_msg);
            debug!("Wander: {} move complete", current_mobile.name);
        }
    }

    Ok(())
}

/// Get all valid exits for a mobile to wander through
fn get_valid_wander_exits(db: &db::Db, room: &ironmud::RoomData) -> Result<Vec<(String, uuid::Uuid)>> {
    let mut valid_exits = Vec::new();

    // Direction names and their corresponding exit Option<Uuid>
    let directions = [
        ("north", room.exits.north),
        ("south", room.exits.south),
        ("east", room.exits.east),
        ("west", room.exits.west),
        ("up", room.exits.up),
        ("down", room.exits.down),
    ];

    for (dir_name, exit_opt) in directions {
        if let Some(target_id) = exit_opt {
            // Check for closed door
            if let Some(door) = room.doors.get(dir_name) {
                if door.is_closed {
                    continue; // Cannot pass through closed door
                }
            }

            // Check target room's no_mob flag
            if let Ok(Some(target_room)) = db.get_room_data(&target_id) {
                if target_room.flags.no_mob {
                    continue; // Cannot enter no_mob rooms
                }

                valid_exits.push((dir_name.to_string(), target_id));
            }
        }
    }

    Ok(valid_exits)
}

/// Get the opposite direction for arrival messages
fn get_opposite_direction_rust(direction: &str) -> &'static str {
    match direction {
        "north" => "south",
        "south" => "north",
        "east" => "west",
        "west" => "east",
        "up" => "below",
        "down" => "above",
        _ => "somewhere",
    }
}

/// Broadcast a message to all awake players in a room (for mobile movement)
/// Sleeping players don't notice mobiles coming and going
fn broadcast_to_room_mobiles(
    connections: &SharedConnections,
    room_id: &uuid::Uuid,
    message: &str,
) {
    if let Ok(conns) = connections.lock() {
        for (_, session) in conns.iter() {
            if let Some(ref char) = session.character {
                if char.current_room_id == *room_id && char.position != ironmud::CharacterPosition::Sleeping {
                    let _ = session.sender.send(message.to_string());
                }
            }
        }
    }
}

// === Combat Round Tick System ===

/// Background task that processes combat rounds periodically (5 second rounds)
async fn run_combat_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(COMBAT_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_combat_round(&db, &connections) {
            error!("Combat tick error: {}", e);
        }
    }
}

/// Corpse decay tick interval - check every 60 seconds
const CORPSE_DECAY_INTERVAL_SECS: u64 = 60;

async fn run_corpse_decay_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(CORPSE_DECAY_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_corpse_decay(&db, &connections) {
            error!("Corpse decay tick error: {}", e);
        }
    }
}

/// Process corpse decay - remove old corpses
fn process_corpse_decay(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use std::time::{SystemTime, UNIX_EPOCH};

    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    // Get all items and check for decayed corpses
    if let Ok(items) = db.list_all_items() {
        for item in items {
            if !item.flags.is_corpse {
                continue;
            }

            let age = now - item.flags.corpse_created_at;

            // Player corpses decay after 1 hour (3600 seconds)
            // Mobile corpses decay after 10 minutes (600 seconds)
            let decay_time = if item.flags.corpse_is_player { 3600 } else { 600 };

            if age >= decay_time {
                // Get room for message
                if let ironmud::ItemLocation::Room(room_id) = item.location {
                    broadcast_to_room(connections, &room_id, &format!("The {} crumbles to dust.", item.name));
                }

                // Delete all items in the corpse
                for item_id in &item.container_contents {
                    let _ = db.delete_item(item_id);
                }

                // Delete the corpse itself
                let _ = db.delete_item(&item.id);

                debug!("Corpse {} decayed", item.name);
            }
        }
    }

    Ok(())
}

/// Process a combat round for all combatants
fn process_combat_round(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use std::time::Instant;
    let round_start = Instant::now();

    tracing::trace!("Combat tick: getting characters in combat");
    // Get all characters in combat
    let char_names = db.get_all_characters_in_combat()?;
    tracing::trace!("Combat tick: found {} characters", char_names.len());

    tracing::trace!("Combat tick: getting mobiles in combat");
    // Get all mobiles in combat
    let mobile_ids = db.get_all_mobiles_in_combat()?;
    tracing::trace!("Combat tick: found {} mobiles", mobile_ids.len());

    // Process character combat
    for char_name in &char_names {
        let start = Instant::now();
        tracing::trace!("Combat tick: processing character {}", char_name);
        if let Err(e) = process_character_combat_round(db, connections, char_name) {
            debug!("Error processing combat for {}: {}", char_name, e);
        }
        let elapsed = start.elapsed();
        if elapsed.as_millis() > 100 {
            tracing::warn!("Combat tick: character {} took {}ms", char_name, elapsed.as_millis());
        }
        tracing::trace!("Combat tick: done with character {}", char_name);
    }

    // Process mobile combat
    for mobile_id in &mobile_ids {
        let start = Instant::now();
        tracing::trace!("Combat tick: processing mobile {}", mobile_id);
        if let Err(e) = process_mobile_combat_round(db, connections, mobile_id) {
            debug!("Error processing combat for mobile {}: {}", mobile_id, e);
        }
        let elapsed = start.elapsed();
        if elapsed.as_millis() > 100 {
            tracing::warn!("Combat tick: mobile {} took {}ms", mobile_id, elapsed.as_millis());
        }
        tracing::trace!("Combat tick: done with mobile {}", mobile_id);
    }

    let round_elapsed = round_start.elapsed();
    if round_elapsed.as_millis() > 500 {
        tracing::warn!("Combat tick: total round took {}ms", round_elapsed.as_millis());
    }
    tracing::trace!("Combat tick: complete in {}ms", round_elapsed.as_millis());
    Ok(())
}

/// Process a combat round for a single character
fn process_character_combat_round(
    db: &db::Db,
    connections: &SharedConnections,
    char_name: &str,
) -> Result<()> {
    debug!("Processing combat for character {}", char_name);
    let mut char = match db.get_character_data(char_name)? {
        Some(c) => c,
        None => {
            debug!("Character {} not found", char_name);
            return Ok(());
        }
    };

    debug!("Character {} in_combat={}, targets={}", char_name, char.combat.in_combat, char.combat.targets.len());

    // Skip if not actually in combat
    if !char.combat.in_combat || char.combat.targets.is_empty() {
        debug!("Character {} skipping - not in combat or no targets", char_name);
        return Ok(());
    }

    // Get room ID for messaging
    let room_id = char.current_room_id;

    // Handle unconscious state - process bleedout timer
    if char.is_unconscious {
        char.bleedout_rounds_remaining -= 1;

        if char.bleedout_rounds_remaining <= 0 {
            // Bleedout timer expired - death!
            process_player_death(db, connections, &mut char, &room_id)?;
            return Ok(());
        }

        send_message_to_character(connections, char_name,
            &format!("You are unconscious and bleeding out! {} rounds remaining...", char.bleedout_rounds_remaining));
        db.save_character_data(char)?;
        return Ok(());
    }

    // Handle stun
    if char.combat.stun_rounds_remaining > 0 {
        char.combat.stun_rounds_remaining -= 1;
        db.save_character_data(char.clone())?;

        send_message_to_character(connections, char_name, "You are stunned and cannot act!");
        broadcast_to_room_except(connections, &room_id, &format!("{} is stunned!", char.name), char_name);
        return Ok(());
    }

    // Apply bleeding damage
    let bleeding: i32 = char.wounds.iter().map(|w| w.bleeding_severity).sum();
    if bleeding > 0 {
        char.hp -= bleeding;
        db.save_character_data(char.clone())?;

        send_message_to_character(connections, char_name, &format!("You lose {} HP from bleeding!", bleeding));

        if char.hp <= 0 {
            // First time reaching 0 HP - go unconscious
            char.is_unconscious = true;
            char.bleedout_rounds_remaining = 5; // 5 round bleedout timer
            db.save_character_data(char.clone())?;

            send_message_to_character(connections, char_name, "You collapse, unconscious from blood loss!");
            broadcast_to_room_except(connections, &room_id, &format!("{} collapses, unconscious!", char.name), char_name);
            return Ok(());
        }
    }

    // Check stamina for combat action
    const COMBAT_STAMINA_COST: i32 = 5;
    const MIN_STAMINA_RESTORE: i32 = 5;

    if char.stamina <= 0 {
        // Too exhausted - skip turn but restore minimum stamina
        char.stamina = MIN_STAMINA_RESTORE;
        db.save_character_data(char.clone())?;
        sync_character_to_session(connections, &char);
        send_message_to_character(connections, char_name,
            "You are too exhausted to attack! You catch your breath...");
        return Ok(());
    }

    // Consume stamina for attack
    char.stamina = (char.stamina - COMBAT_STAMINA_COST).max(0);

    // Get primary target
    let target = match char.combat.targets.first() {
        Some(t) => t.clone(),
        None => {
            // No target, exit combat
            char.combat.in_combat = false;
            char.combat.targets.clear();
            db.save_character_data(char)?;
            return Ok(());
        }
    };

    // Process attack based on target type
    match target.target_type {
        ironmud::CombatTargetType::Mobile => {
            process_character_attacks_mobile(db, connections, &mut char, &target.target_id)?;
        }
        ironmud::CombatTargetType::Player => {
            process_character_attacks_player(db, connections, &mut char, &target.target_id)?;
        }
    }

    db.save_character_data(char.clone())?;
    sync_character_to_session(connections, &char);
    Ok(())
}

/// Process a character attacking a mobile
fn process_character_attacks_mobile(
    db: &db::Db,
    connections: &SharedConnections,
    char: &mut ironmud::CharacterData,
    target_id: &uuid::Uuid,
) -> Result<()> {
    use rand::Rng;

    let mut mobile = match db.get_mobile_data(target_id)? {
        Some(m) => m,
        None => {
            // Target no longer exists, remove from combat
            char.combat.targets.retain(|t| t.target_id != *target_id);
            if char.combat.targets.is_empty() {
                char.combat.in_combat = false;
            }
            // Save changes to database and sync to session
            db.save_character_data(char.clone())?;
            sync_character_to_session(connections, char);
            return Ok(());
        }
    };

    let room_id = char.current_room_id;
    let mut rng = rand::thread_rng();

    // Get weapon skill from equipped weapon
    let (weapon_skill, dice_count, dice_sides, damage_bonus) = get_character_weapon_info(db, char);
    let skill = get_skill_level_for_character(char, &weapon_skill);

    // Calculate hit chance: 50 + skill*5 + attacker_dex - target_dex - target_ac
    let attacker_dex_mod = (char.stat_dex as i32 - 10) / 2;
    let target_dex_mod = (mobile.stat_dex as i32 - 10) / 2;
    let target_ac = mobile.armor_class;

    let hit_chance = (50 + skill * 5 + attacker_dex_mod - target_dex_mod - target_ac).clamp(5, 95);
    let roll = rng.gen_range(1..=100);

    if roll > hit_chance {
        // Miss - sleeping bystanders don't see combat
        send_message_to_character(connections, &char.name, &format!("You swing at {} but miss!", mobile.name));
        broadcast_to_room_except_awake(connections, &room_id, &format!("{} swings at {} but misses!", char.name, mobile.name), &char.name);
        return Ok(());
    }

    // Hit - calculate base damage
    let mut damage = roll_dice(dice_count, dice_sides) + damage_bonus;

    // Check for critical hit (5% + skill%)
    let crit_chance = 5 + skill;
    let crit_roll = rng.gen_range(1..=100);
    let is_crit = crit_roll <= crit_chance;

    // Track critical effect for messaging
    let mut crit_effect = String::new();

    if is_crit {
        // Scale damage: 2x at skill >= 5, 1.5x otherwise
        damage = if skill >= 5 { damage * 2 } else { (damage * 3) / 2 };

        // Roll for secondary crit effect (1-4)
        let effect_roll = rng.gen_range(1..=4);
        crit_effect = match effect_roll {
            1 => {
                // Bleeding: add severity based on skill
                let severity = std::cmp::min(2 + skill / 3, 5);
                // Add bleeding to a random wound
                let body_part = roll_random_body_part(&mut rng);
                add_mobile_wound_bleeding(db, &mobile.id, &body_part, severity)?;
                "Bleeding".to_string()
            }
            2 => {
                // Stun: 1 round at skill < 5, 2 rounds at skill >= 5
                let stun_rounds = if skill >= 5 { 2 } else { 1 };
                mobile.combat.stun_rounds_remaining += stun_rounds;
                "Stun".to_string()
            }
            3 => {
                // Limb disable: escalate wound to Severe
                let body_part = roll_random_body_part(&mut rng);
                escalate_mobile_wound_to_severe(db, &mobile.id, &body_part)?;
                format!("{} Disabled", body_part)
            }
            _ => String::new(), // Clean crit - just bonus damage
        };

        // Reload mobile from DB to get any wounds that were added
        // (add_mobile_wound_bleeding and escalate_mobile_wound_to_severe save directly to DB)
        if let Some(fresh_mobile) = db.get_mobile_data(&mobile.id)? {
            mobile = fresh_mobile;
        }
    }

    // Apply damage
    mobile.current_hp -= damage;
    db.save_mobile_data(mobile.clone())?;

    // Build message with crit text (yellow/bold)
    let crit_text = if is_crit {
        if crit_effect.is_empty() {
            " \x1b[1;33m[CRITICAL]\x1b[0m".to_string()
        } else {
            format!(" \x1b[1;33m[CRITICAL - {}!]\x1b[0m", crit_effect)
        }
    } else {
        String::new()
    };

    // Send messages - sleeping bystanders don't see combat
    send_message_to_character(connections, &char.name, &format!("You hit {} for {} damage!{}", mobile.name, damage, crit_text));
    broadcast_to_room_except_awake(connections, &room_id, &format!("{} hits {} for {} damage!", char.name, mobile.name, damage), &char.name);

    // Award XP for successful hit (10 XP to weapon skill)
    let leveled = add_skill_experience_to_character(char, &weapon_skill, 10);
    if leveled {
        send_message_to_character(connections, &char.name, &format!("\x1b[1;33mYour {} skill has improved!\x1b[0m", weapon_skill));
    }

    // Check if target died
    if mobile.current_hp <= 0 {
        // Create corpse and handle death
        process_mobile_death(db, connections, &mut mobile, &room_id)?;

        // Remove from character's targets
        char.combat.targets.retain(|t| t.target_id != *target_id);
        if char.combat.targets.is_empty() {
            char.combat.in_combat = false;
        }
    }

    Ok(())
}

/// Process a character attacking another player (PvP)
fn process_character_attacks_player(
    _db: &db::Db,
    _connections: &SharedConnections,
    char: &mut ironmud::CharacterData,
    target_id: &uuid::Uuid,
) -> Result<()> {
    // Find target player by name stored in target_id (it's actually a string converted)
    // Actually, target_id is a UUID. We need to find the character somehow.
    // For now, skip PvP in automatic combat rounds.
    // PvP attacks are handled manually through the attack command.

    // Remove this target from combat since we can't process it automatically
    char.combat.targets.retain(|t| t.target_id != *target_id);
    if char.combat.targets.is_empty() {
        char.combat.in_combat = false;
    }

    Ok(())
}

/// Attempt to have a mobile flee from combat
/// Returns Some(true) if successfully fled, Some(false) if failed, None if couldn't attempt
fn attempt_mobile_flee(
    db: &db::Db,
    connections: &SharedConnections,
    mobile: &mut ironmud::MobileData,
) -> Option<bool> {
    use rand::Rng;
    use rand::seq::SliceRandom;

    let room_id = mobile.current_room_id?;
    let room = db.get_room_data(&room_id).ok()??;

    // Build valid exit list using existing wander logic
    let exits = get_valid_wander_exits(db, &room).ok()?;
    if exits.is_empty() {
        // No escape - broadcast failure (sleeping players don't see combat)
        broadcast_to_room_awake(connections, &room_id,
            &format!("{} looks around frantically for an escape!\n", mobile.name));
        return Some(false);
    }

    // 50% success rate
    let mut rng = rand::thread_rng();
    if rng.gen_range(0..100) >= 50 {
        // Failed flee attempt (sleeping players don't see combat)
        broadcast_to_room_awake(connections, &room_id,
            &format!("{} tries to flee but stumbles!\n", mobile.name));
        return Some(false);
    }

    // Success - pick random exit and move
    let (direction, target_room_id) = exits.choose(&mut rng)?.clone();

    // Broadcast departure (sleeping players don't see combat)
    broadcast_to_room_awake(connections, &room_id,
        &format!("{} flees {}!\n", mobile.name, direction));

    // Remove this mobile from all player combat targets before clearing our targets
    // Collect character names to update (to avoid calling sync_character_to_session while holding lock)
    let mut chars_to_sync: Vec<ironmud::CharacterData> = Vec::new();

    for target in &mobile.combat.targets {
        if target.target_type == ironmud::CombatTargetType::Player {
            // Target ID for players is stored as the player name
            // Find the character by searching connections
            let player_names: Vec<String> = {
                if let Ok(conns) = connections.lock() {
                    conns.iter()
                        .filter_map(|(_, session)| {
                            if let Some(ref char) = session.character {
                                // Check if this character is targeting the mobile
                                if char.combat.targets.iter().any(|t| t.target_id == mobile.id) {
                                    return Some(char.name.clone());
                                }
                            }
                            None
                        })
                        .collect()
                } else {
                    Vec::new()
                }
            };

            // Update combat state for each player (lock is released now)
            for player_name in player_names {
                if let Ok(Some(mut char_data)) = db.get_character_data(&player_name) {
                    char_data.combat.targets.retain(|t| t.target_id != mobile.id);
                    if char_data.combat.targets.is_empty() {
                        char_data.combat.in_combat = false;
                    }
                    let _ = db.save_character_data(char_data.clone());
                    chars_to_sync.push(char_data);
                }
            }
        }
    }

    // Sync all updated characters to their sessions (safe - no lock held)
    for char_data in chars_to_sync {
        sync_character_to_session(connections, &char_data);
    }

    // Move mobile
    mobile.current_room_id = Some(target_room_id);

    // Exit combat
    mobile.combat.in_combat = false;
    mobile.combat.targets.clear();

    // Save mobile
    let _ = db.save_mobile_data(mobile.clone());

    // Broadcast arrival (sleeping players don't see)
    let arrival_dir = get_opposite_direction_rust(&direction);
    broadcast_to_room_awake(connections, &target_room_id,
        &format!("{} arrives from the {}, fleeing!\n", mobile.name, arrival_dir));

    Some(true)
}

/// Process a combat round for a single mobile
fn process_mobile_combat_round(
    db: &db::Db,
    connections: &SharedConnections,
    mobile_id: &uuid::Uuid,
) -> Result<()> {
    use rand::Rng;

    let mut mobile = match db.get_mobile_data(mobile_id)? {
        Some(m) => m,
        None => {
            debug!("Mobile {} not found in database", mobile_id);
            return Ok(());
        }
    };

    debug!("Processing combat for mobile {} ({}): in_combat={}, targets={}",
           mobile.name, mobile_id, mobile.combat.in_combat, mobile.combat.targets.len());

    // Skip if not actually in combat
    if !mobile.combat.in_combat || mobile.combat.targets.is_empty() {
        debug!("Mobile {} skipping - not in combat or no targets", mobile.name);
        return Ok(());
    }

    // Get room ID for messaging
    let room_id = match mobile.current_room_id {
        Some(rid) => rid,
        None => {
            debug!("Mobile {} has no room, skipping", mobile.name);
            return Ok(());
        }
    };

    debug!("Mobile {} is in room {}", mobile.name, room_id);

    // Handle stun
    if mobile.combat.stun_rounds_remaining > 0 {
        debug!("Mobile {} is stunned ({} rounds remaining)", mobile.name, mobile.combat.stun_rounds_remaining);
        mobile.combat.stun_rounds_remaining -= 1;
        let mobile_name = mobile.name.clone();
        db.save_mobile_data(mobile)?;

        broadcast_to_room_awake(connections, &room_id, &format!("{} is stunned and cannot act!", mobile_name));
        debug!("Mobile {} stun handling complete, returning", mobile_name);
        return Ok(());
    }

    // Apply bleeding damage
    let bleeding: i32 = mobile.wounds.iter().map(|w| w.bleeding_severity).sum();
    debug!("Mobile {} bleeding check: {} damage", mobile.name, bleeding);
    if bleeding > 0 {
        mobile.current_hp -= bleeding;
        debug!("Mobile {} HP after bleeding: {}", mobile.name, mobile.current_hp);
        db.save_mobile_data(mobile.clone())?;

        broadcast_to_room_awake(connections, &room_id, &format!("{} loses {} HP from bleeding!", mobile.name, bleeding));

        if mobile.current_hp <= 0 {
            // Create corpse and handle death
            debug!("Mobile {} died from bleeding, calling process_mobile_death", mobile.name);
            process_mobile_death(db, connections, &mut mobile, &room_id)?;
            debug!("Mobile {} death processing complete", mobile.name);
            return Ok(());
        }
        debug!("Mobile {} survived bleeding, continuing", mobile.name);
    }

    // Check stamina for combat action
    const MOBILE_COMBAT_STAMINA_COST: i32 = 5;
    const MOBILE_MIN_STAMINA_RESTORE: i32 = 5;

    if mobile.current_stamina <= 0 {
        // Too exhausted - skip turn but restore minimum stamina
        debug!("Mobile {} exhausted, restoring stamina", mobile.name);
        mobile.current_stamina = MOBILE_MIN_STAMINA_RESTORE;
        debug!("Mobile {} saving exhausted state", mobile.name);
        db.save_mobile_data(mobile.clone())?;
        debug!("Mobile {} broadcasting exhaustion message", mobile.name);
        broadcast_to_room_awake(connections, &room_id,
            &format!("{} pauses to catch their breath.", mobile.name));
        debug!("Mobile {} exhaustion handling complete", mobile.name);
        return Ok(());
    }

    // Consume stamina for attack
    mobile.current_stamina = (mobile.current_stamina - MOBILE_COMBAT_STAMINA_COST).max(0);

    // Check if mobile should attempt to flee (HP <= 25%)
    let mut rng = rand::thread_rng();
    if mobile.current_hp > 0 && mobile.max_hp > 0 {
        let hp_percent = (mobile.current_hp * 100) / mobile.max_hp;
        if hp_percent <= 25 {
            // 30% chance to attempt flee each round
            if rng.gen_range(0..100) < 30 {
                if let Some(fled) = attempt_mobile_flee(db, connections, &mut mobile) {
                    if fled {
                        // Successfully fled - skip attack this round
                        return Ok(());
                    }
                    // Failed flee - continue with attack
                }
            }
        }
    }

    // Get primary target
    let target = match mobile.combat.targets.first() {
        Some(t) => t.clone(),
        None => {
            mobile.combat.in_combat = false;
            mobile.combat.targets.clear();
            db.save_mobile_data(mobile)?;
            return Ok(());
        }
    };

    // Mobile attacks player
    if target.target_type == ironmud::CombatTargetType::Player {
        // Find the player character - target_id is character name stored as UUID
        // Actually we need to iterate connections to find the player
        debug!("Mobile {} finding player in room", mobile.name);
        let player_name = find_player_name_in_room(connections, &room_id);
        debug!("Mobile {} found player: {:?}", mobile.name, player_name);

        if let Some(player_name) = player_name {
            let mobile_name = mobile.name.clone();
            debug!("Mobile {} attacking player {}", mobile_name, player_name);
            process_mobile_attacks_player(db, connections, &mut mobile, &player_name, &room_id)?;
            debug!("Mobile {} attack complete, saving", mobile_name);
            db.save_mobile_data(mobile)?;
            debug!("Mobile {} save complete", mobile_name);
        } else {
            // Target not found, exit combat
            let mobile_name = mobile.name.clone();
            debug!("Mobile {} target not found, exiting combat", mobile_name);
            mobile.combat.in_combat = false;
            mobile.combat.targets.clear();
            db.save_mobile_data(mobile)?;
        }
    }

    debug!("Mobile combat round complete");
    Ok(())
}

/// Process a mobile attacking a player
fn process_mobile_attacks_player(
    db: &db::Db,
    connections: &SharedConnections,
    mobile: &mut ironmud::MobileData,
    player_name: &str,
    room_id: &uuid::Uuid,
) -> Result<()> {
    use rand::Rng;

    let mut char = match db.get_character_data(player_name)? {
        Some(c) => c,
        None => return Ok(()),
    };

    // Verify player is still in the same room
    if char.current_room_id != *room_id {
        // Player left, exit combat
        mobile.combat.in_combat = false;
        mobile.combat.targets.clear();
        return Ok(());
    }

    // Check if player is sleeping - if so, wake them up and give automatic hit
    let was_sleeping = char.position == ironmud::CharacterPosition::Sleeping;
    if was_sleeping {
        char.position = ironmud::CharacterPosition::Standing;
        db.save_character_data(char.clone())?;
        sync_character_to_session(connections, &char);
        send_message_to_character(connections, player_name, "You are jolted awake by an attack!");
        broadcast_to_room_except_awake(connections, room_id, &format!("{} is jolted awake!", char.name), player_name);
    }

    // Ensure player is in combat with this mobile (reactive combat)
    if !char.combat.in_combat || !char.combat.targets.iter().any(|t| t.target_id == mobile.id) {
        char.combat.in_combat = true;
        if !char.combat.targets.iter().any(|t| t.target_id == mobile.id) {
            char.combat.targets.push(ironmud::CombatTarget {
                target_type: ironmud::CombatTargetType::Mobile,
                target_id: mobile.id,
            });
        }
        db.save_character_data(char.clone())?;
        sync_character_to_session(connections, &char);
    }

    let mut rng = rand::thread_rng();

    // Calculate hit chance (automatic hit if target was sleeping)
    let attacker_dex_mod = (mobile.stat_dex as i32 - 10) / 2;
    let target_dex_mod = (char.stat_dex as i32 - 10) / 2;
    let target_ac = 0; // TODO: Calculate player AC from armor
    let skill = 0; // Mobile skill level (mobiles don't have skill levels)

    let hit_chance = (50 + skill * 5 + attacker_dex_mod - target_dex_mod - target_ac).clamp(5, 95);
    let roll = rng.gen_range(1..=100);

    // Skip hit roll if target was sleeping (automatic hit)
    if !was_sleeping && roll > hit_chance {
        // Miss
        send_message_to_character(connections, player_name, &format!("{} swings at you but misses!", mobile.name));
        broadcast_to_room_except_awake(connections, room_id, &format!("{} swings at {} but misses!", mobile.name, char.name), player_name);
        return Ok(());
    }

    // Hit - calculate damage (use mobile's damage dice)
    let (count, sides, bonus) = parse_damage_dice(&mobile.damage_dice);
    let mut damage = roll_dice(count, sides) + bonus;

    // Check for critical hit (5% base for mobiles, no skill bonus)
    let crit_chance = 5;
    let crit_roll = rng.gen_range(1..=100);
    let is_crit = crit_roll <= crit_chance;

    // Track critical effect for messaging
    let mut crit_effect = String::new();

    if is_crit {
        // Scale damage: 1.5x for mobiles (no skill)
        damage = (damage * 3) / 2;

        // Roll for secondary crit effect (1-4)
        let effect_roll = rng.gen_range(1..=4);
        crit_effect = match effect_roll {
            1 => {
                // Bleeding
                let severity = 2; // Base severity for mobiles
                let body_part = roll_random_body_part(&mut rng);
                add_character_wound_bleeding(db, player_name, &body_part, severity)?;
                "Bleeding".to_string()
            }
            2 => {
                // Stun: 1 round for mobiles
                char.combat.stun_rounds_remaining += 1;
                db.save_character_data(char.clone())?;
                "Stun".to_string()
            }
            3 => {
                // Limb disable
                let body_part = roll_random_body_part(&mut rng);
                escalate_character_wound_to_severe(db, player_name, &body_part)?;
                format!("{} Disabled", body_part)
            }
            _ => String::new(), // Clean crit
        };

        // Reload character from DB to get any wounds that were added
        // (add_character_wound_bleeding and escalate_character_wound_to_severe save directly to DB)
        if let Some(fresh_char) = db.get_character_data(player_name)? {
            char = fresh_char;
        }
    }

    // Apply damage
    char.hp -= damage;
    db.save_character_data(char.clone())?;

    // Sync updated character to session so prompt shows correct HP
    sync_character_to_session(connections, &char);

    // Build message with crit text (yellow/bold)
    let crit_text = if is_crit {
        if crit_effect.is_empty() {
            " \x1b[1;33m[CRITICAL]\x1b[0m".to_string()
        } else {
            format!(" \x1b[1;33m[CRITICAL - {}!]\x1b[0m", crit_effect)
        }
    } else {
        String::new()
    };

    // Send messages (red for damage taken) - sleeping bystanders don't see combat
    send_message_to_character(connections, player_name, &format!("\x1b[1;31m{} hits you for {} damage!{}\x1b[0m", mobile.name, damage, crit_text));
    broadcast_to_room_except_awake(connections, room_id, &format!("{} hits {} for {} damage!", mobile.name, char.name, damage), player_name);

    // Check if player died or went unconscious
    if char.hp <= 0 {
        if char.is_unconscious {
            // Already unconscious and took damage - instant death!
            process_player_death(db, connections, &mut char, room_id)?;

            // Remove player from mobile's targets
            mobile.combat.targets.retain(|t| t.target_type != ironmud::CombatTargetType::Player);
            if mobile.combat.targets.is_empty() {
                mobile.combat.in_combat = false;
            }
        } else {
            // First time reaching 0 HP - go unconscious
            char.is_unconscious = true;
            char.bleedout_rounds_remaining = 5; // 5 round bleedout timer
            let char_name_for_msg = char.name.clone();
            db.save_character_data(char.clone())?;

            send_message_to_character(connections, player_name, "You collapse, unconscious!");
            broadcast_to_room_except_awake(connections, room_id, &format!("{} collapses, unconscious!", char_name_for_msg), player_name);

            // If mobile is aggressive, they will continue attacking and kill the player
            if mobile.flags.aggressive {
                // Reload character and process instant death
                if let Ok(Some(mut char)) = db.get_character_data(player_name) {
                    process_player_death(db, connections, &mut char, room_id)?;

                    // Remove player from mobile's targets
                    mobile.combat.targets.retain(|t| t.target_type != ironmud::CombatTargetType::Player);
                    if mobile.combat.targets.is_empty() {
                        mobile.combat.in_combat = false;
                    }
                }
            }
        }
    }

    Ok(())
}

/// Find the first player in a room
fn find_player_name_in_room(connections: &SharedConnections, room_id: &uuid::Uuid) -> Option<String> {
    debug!("find_player_name_in_room: acquiring connections lock");
    if let Ok(conns) = connections.lock() {
        debug!("find_player_name_in_room: lock acquired");
        for (_, session) in conns.iter() {
            if let Some(ref char) = session.character {
                if char.current_room_id == *room_id {
                    debug!("find_player_name_in_room: found player {}", char.name);
                    return Some(char.name.clone());
                }
            }
        }
        debug!("find_player_name_in_room: no player found in room");
    } else {
        debug!("find_player_name_in_room: failed to acquire lock");
    }
    None
}

/// Roll dice (e.g., 2d6)
fn roll_dice(count: i32, sides: i32) -> i32 {
    use rand::Rng;

    if count <= 0 || sides <= 0 {
        return 0;
    }

    let mut rng = rand::thread_rng();
    let mut total = 0;
    for _ in 0..count {
        total += rng.gen_range(1..=sides);
    }
    total
}

/// Parse damage dice string like "2d6" or "2d6+3" into (count, sides, bonus)
fn parse_damage_dice(dice_str: &str) -> (i32, i32, i32) {
    if dice_str.is_empty() {
        return (1, 4, 0); // Default to 1d4
    }

    // Parse formats: "2d6", "2d6+3", "2d6-1"
    let parts: Vec<&str> = dice_str.split('d').collect();
    if parts.len() != 2 {
        return (1, 4, 0);
    }

    let count: i32 = parts[0].parse().unwrap_or(1);

    // Check for bonus/penalty
    let sides_and_bonus = parts[1];
    if sides_and_bonus.contains('+') {
        let sp: Vec<&str> = sides_and_bonus.split('+').collect();
        let sides: i32 = sp[0].parse().unwrap_or(4);
        let bonus: i32 = sp.get(1).and_then(|s| s.parse().ok()).unwrap_or(0);
        return (count, sides, bonus);
    } else if sides_and_bonus.contains('-') {
        let sp: Vec<&str> = sides_and_bonus.split('-').collect();
        let sides: i32 = sp[0].parse().unwrap_or(4);
        let penalty: i32 = sp.get(1).and_then(|s| s.parse().ok()).unwrap_or(0);
        return (count, sides, -penalty);
    }

    let sides: i32 = sides_and_bonus.parse().unwrap_or(4);
    (count, sides, 0)
}

/// Get weapon info for a character (skill, dice_count, dice_sides, damage_bonus)
fn get_character_weapon_info(db: &db::Db, char: &ironmud::CharacterData) -> (String, i32, i32, i32) {
    // Default unarmed values
    let default = ("unarmed".to_string(), 1, 2, 0);

    // Get equipped items from database
    let equipped_items = match db.get_equipped_items(&char.name) {
        Ok(items) => items,
        Err(_) => return default,
    };

    // Look through equipped items for a wielded weapon
    for item in &equipped_items {
        // Check if wielded
        for loc in &item.wear_locations {
            if *loc == ironmud::WearLocation::Wielded {
                let skill = item.weapon_skill.as_ref()
                    .map(|s| format!("{:?}", s).to_lowercase())
                    .unwrap_or_else(|| "unarmed".to_string());
                return (skill, item.damage_dice_count, item.damage_dice_sides, 0);
            }
        }
    }

    default
}

/// Get skill level for a character
fn get_skill_level_for_character(char: &ironmud::CharacterData, skill_name: &str) -> i32 {
    if let Some(skill) = char.skills.get(&skill_name.to_lowercase()) {
        return skill.level;
    }
    0
}

/// Add skill experience to a character, returns true if leveled up
fn add_skill_experience_to_character(char: &mut ironmud::CharacterData, skill_name: &str, amount: i32) -> bool {
    // XP required per level - matches Rhai version in characters.rs
    fn xp_for_level(level: i32) -> i32 {
        match level {
            0 => 100,   1 => 200,   2 => 350,   3 => 550,   4 => 800,
            5 => 1100,  6 => 1500,  7 => 2000,  8 => 2600,  9 => 3300,
            _ => 0,
        }
    }

    let max_level = 10;
    let skill_key = skill_name.to_lowercase();

    if let Some(skill) = char.skills.get_mut(&skill_key) {
        if skill.level >= max_level {
            return false;
        }
        skill.experience += amount;

        // Check for level up (may level multiple times if XP is high)
        let mut leveled_up = false;
        loop {
            let xp_needed = xp_for_level(skill.level);
            if xp_needed == 0 || skill.experience < xp_needed || skill.level >= max_level {
                break;
            }
            skill.experience -= xp_needed;
            skill.level += 1;
            leveled_up = true;
            if skill.level >= max_level {
                skill.experience = 0;
                break;
            }
        }
        return leveled_up;
    }

    // Skill not found, create it
    char.skills.insert(skill_key, ironmud::SkillProgress {
        level: 0,
        experience: amount,
    });
    false
}

/// Roll a random body part for combat effects
fn roll_random_body_part<R: rand::Rng>(rng: &mut R) -> String {
    // Weights from COMBAT_SYSTEM.md
    let roll = rng.gen_range(1..=100);
    match roll {
        1..=35 => "torso",
        36..=47 => "left arm",
        48..=59 => "right arm",
        60..=71 => "left leg",
        72..=83 => "right leg",
        84..=91 => "head",
        92..=95 => "left hand",
        96..=96 => "right hand",  // Adjusted for correct weights
        97..=97 => "left foot",
        98..=98 => "right foot",
        _ => "neck",
    }.to_string()
}

/// Add bleeding to a mobile's wound on a body part
fn add_mobile_wound_bleeding(db: &db::Db, mobile_id: &uuid::Uuid, body_part: &str, severity: i32) -> Result<()> {
    if let Ok(Some(mut mobile)) = db.get_mobile_data(mobile_id) {
        // Find existing wound on this body part, or create one
        let mut found = false;
        for wound in &mut mobile.wounds {
            if format!("{:?}", wound.body_part).to_lowercase().replace("_", " ") == body_part.to_lowercase() {
                wound.bleeding_severity += severity;
                found = true;
                break;
            }
        }

        if !found {
            // Create a new wound with bleeding
            let bp = ironmud::BodyPart::from_str(body_part).unwrap_or(ironmud::BodyPart::Torso);
            mobile.wounds.push(ironmud::Wound {
                body_part: bp,
                level: ironmud::WoundLevel::Minor,
                wound_type: ironmud::WoundType::Cut,
                bleeding_severity: severity,
            });
        }

        db.save_mobile_data(mobile)?;
    }
    Ok(())
}

/// Escalate a mobile's wound to Severe level (limb disable)
fn escalate_mobile_wound_to_severe(db: &db::Db, mobile_id: &uuid::Uuid, body_part: &str) -> Result<()> {
    if let Ok(Some(mut mobile)) = db.get_mobile_data(mobile_id) {
        // Find existing wound on this body part
        let mut found = false;
        for wound in &mut mobile.wounds {
            if format!("{:?}", wound.body_part).to_lowercase().replace("_", " ") == body_part.to_lowercase() {
                wound.level = ironmud::WoundLevel::Severe;
                found = true;
                break;
            }
        }

        if !found {
            // Create a new Severe wound
            let bp = ironmud::BodyPart::from_str(body_part).unwrap_or(ironmud::BodyPart::Torso);
            mobile.wounds.push(ironmud::Wound {
                body_part: bp,
                level: ironmud::WoundLevel::Severe,
                wound_type: ironmud::WoundType::Fracture,
                bleeding_severity: 0,
            });
        }

        db.save_mobile_data(mobile)?;
    }
    Ok(())
}

/// Add bleeding to a character's wound on a body part
fn add_character_wound_bleeding(db: &db::Db, char_name: &str, body_part: &str, severity: i32) -> Result<()> {
    if let Ok(Some(mut char)) = db.get_character_data(char_name) {
        // Find existing wound on this body part, or create one
        let mut found = false;
        for wound in &mut char.wounds {
            if format!("{:?}", wound.body_part).to_lowercase().replace("_", " ") == body_part.to_lowercase() {
                wound.bleeding_severity += severity;
                found = true;
                break;
            }
        }

        if !found {
            // Create a new wound with bleeding
            let bp = ironmud::BodyPart::from_str(body_part).unwrap_or(ironmud::BodyPart::Torso);
            char.wounds.push(ironmud::Wound {
                body_part: bp,
                level: ironmud::WoundLevel::Minor,
                wound_type: ironmud::WoundType::Cut,
                bleeding_severity: severity,
            });
        }

        db.save_character_data(char)?;
    }
    Ok(())
}

/// Escalate a character's wound to Severe level (limb disable)
fn escalate_character_wound_to_severe(db: &db::Db, char_name: &str, body_part: &str) -> Result<()> {
    if let Ok(Some(mut char)) = db.get_character_data(char_name) {
        // Find existing wound on this body part
        let mut found = false;
        for wound in &mut char.wounds {
            if format!("{:?}", wound.body_part).to_lowercase().replace("_", " ") == body_part.to_lowercase() {
                wound.level = ironmud::WoundLevel::Severe;
                found = true;
                break;
            }
        }

        if !found {
            // Create a new Severe wound
            let bp = ironmud::BodyPart::from_str(body_part).unwrap_or(ironmud::BodyPart::Torso);
            char.wounds.push(ironmud::Wound {
                body_part: bp,
                level: ironmud::WoundLevel::Severe,
                wound_type: ironmud::WoundType::Fracture,
                bleeding_severity: 0,
            });
        }

        db.save_character_data(char)?;
    }
    Ok(())
}

/// Process player death: create corpse, transfer items, respawn
fn process_player_death(
    db: &db::Db,
    connections: &SharedConnections,
    char: &mut ironmud::CharacterData,
    room_id: &uuid::Uuid,
) -> Result<()> {
    use std::time::{SystemTime, UNIX_EPOCH};

    let char_name = char.name.clone();

    // Send death messages
    send_message_to_character(connections, &char_name, "You have died!");
    broadcast_to_room_except(connections, room_id, &format!("{} has died!", char_name), &char_name);

    // Create corpse
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    let corpse = ironmud::ItemData {
        id: uuid::Uuid::new_v4(),
        name: format!("corpse of {}", char_name),
        short_desc: format!("The corpse of {} lies here.", char_name),
        long_desc: format!("The lifeless body of {} lies in a crumpled heap.", char_name),
        keywords: vec!["corpse".to_string(), "body".to_string(), char_name.to_lowercase()],
        item_type: ironmud::ItemType::Container,
        category: None,
        teaches_recipe: None,
        wear_locations: vec![],
        armor_class: None,
        protects: vec![],
        flags: ironmud::ItemFlags {
            no_get: true,
            is_corpse: true,
            corpse_owner: char_name.clone(),
            corpse_created_at: now,
            corpse_is_player: true,
            corpse_gold: char.gold as i64,
            ..Default::default()
        },
        weight: 100,
        value: 0,
        location: ironmud::ItemLocation::Room(*room_id),
        damage_dice_count: 0,
        damage_dice_sides: 0,
        damage_type: Default::default(),
        two_handed: false,
        weapon_skill: None,
        // Container fields - corpses are containers
        container_contents: vec![],
        container_max_items: 1000,
        container_max_weight: 10000,
        container_closed: false,
        container_locked: false,
        container_key_id: None,
        weight_reduction: 0,
        // Liquid container fields
        liquid_type: ironmud::LiquidType::default(),
        liquid_current: 0,
        liquid_max: 0,
        liquid_poisoned: false,
        liquid_effects: vec![],
        // Food fields
        food_nutrition: 0,
        food_poisoned: false,
        food_spoil_duration: 0,
        food_created_at: None,
        food_effects: vec![],
        // Level/stats
        level_requirement: 0,
        stat_str: 0,
        stat_dex: 0,
        stat_con: 0,
        stat_int: 0,
        stat_wis: 0,
        stat_cha: 0,
        insulation: 0,
        is_prototype: false,
        vnum: None,
        triggers: vec![],
        vending_stock: vec![],
        vending_sell_rate: 150,
        quality: 0,
        bait_uses: 0,
        holes: 0,
        medical_tier: 0,
        medical_uses: 0,
        treats_wound_types: vec![],
        max_treatable_wound: String::new(),
        transport_link: None,
    };

    let corpse_id = corpse.id;
    let mut corpse = corpse;

    // Transfer inventory to corpse (source of truth is ItemLocation::Inventory)
    if let Ok(inventory_items) = db.get_items_in_inventory(&char_name) {
        for item in inventory_items {
            let item_id = item.id;
            let mut updated_item = item;
            updated_item.location = ironmud::ItemLocation::Container(corpse_id);
            let _ = db.save_item_data(updated_item);
            corpse.container_contents.push(item_id);
        }
    }

    // Transfer equipment to corpse (source of truth is ItemLocation::Equipped)
    if let Ok(equipped_items) = db.get_equipped_items(&char_name) {
        for item in equipped_items {
            let item_id = item.id;
            let mut updated_item = item;
            updated_item.location = ironmud::ItemLocation::Container(corpse_id);
            let _ = db.save_item_data(updated_item);
            corpse.container_contents.push(item_id);
        }
    }

    // Save corpse
    db.save_item_data(corpse)?;

    // Clear character's gold (inventory items already moved to corpse above)
    char.gold = 0;

    // Respawn character
    let spawn_room = char.spawn_room_id
        .unwrap_or_else(|| uuid::Uuid::parse_str(ironmud::STARTING_ROOM_ID).unwrap());

    char.current_room_id = spawn_room;
    char.hp = char.max_hp / 4;
    if char.hp < 1 { char.hp = 1; }
    char.is_unconscious = false;
    char.bleedout_rounds_remaining = 0;
    char.wounds.clear();
    char.combat.in_combat = false;
    char.combat.targets.clear();
    char.combat.stun_rounds_remaining = 0;

    db.save_character_data(char.clone())?;

    // Send respawn message
    send_message_to_character(connections, &char_name, "You awaken at your spawn point...");
    send_message_to_character(connections, &char_name, &format!("You have {} HP.", char.hp));

    Ok(())
}

/// Process mobile death: create corpse with items
fn process_mobile_death(
    db: &db::Db,
    connections: &SharedConnections,
    mobile: &mut ironmud::MobileData,
    room_id: &uuid::Uuid,
) -> Result<()> {
    use std::time::{SystemTime, UNIX_EPOCH};

    debug!("process_mobile_death: starting for {}", mobile.name);
    let mobile_name = mobile.name.clone();

    // Send death message (red) - sleeping bystanders don't see combat
    debug!("process_mobile_death: broadcasting death message");
    broadcast_to_room_awake(connections, room_id, &format!("\x1b[1;31m{} collapses to the ground, dead!\x1b[0m", mobile_name));
    debug!("process_mobile_death: death message broadcast complete");

    // Create corpse
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    let corpse = ironmud::ItemData {
        id: uuid::Uuid::new_v4(),
        name: format!("corpse of {}", mobile_name),
        short_desc: format!("The corpse of {} lies here.", mobile_name),
        long_desc: format!("The lifeless body of {} lies in a crumpled heap.", mobile_name),
        keywords: vec!["corpse".to_string(), "body".to_string(), mobile_name.to_lowercase()],
        item_type: ironmud::ItemType::Container,
        category: None,
        teaches_recipe: None,
        wear_locations: vec![],
        armor_class: None,
        protects: vec![],
        flags: ironmud::ItemFlags {
            no_get: true,
            is_corpse: true,
            corpse_owner: mobile_name.clone(),
            corpse_created_at: now,
            corpse_is_player: false,  // Mobile corpse - 10 minute decay
            corpse_gold: 0,  // Mobiles don't carry gold by default
            ..Default::default()
        },
        weight: 100,
        value: 0,
        location: ironmud::ItemLocation::Room(*room_id),
        damage_dice_count: 0,
        damage_dice_sides: 0,
        damage_type: Default::default(),
        two_handed: false,
        weapon_skill: None,
        // Container fields - corpses are containers
        container_contents: vec![],
        container_max_items: 1000,
        container_max_weight: 10000,
        container_closed: false,
        container_locked: false,
        container_key_id: None,
        weight_reduction: 0,
        // Liquid container fields
        liquid_type: ironmud::LiquidType::default(),
        liquid_current: 0,
        liquid_max: 0,
        liquid_poisoned: false,
        liquid_effects: vec![],
        // Food fields
        food_nutrition: 0,
        food_poisoned: false,
        food_spoil_duration: 0,
        food_created_at: None,
        food_effects: vec![],
        // Level/stats
        level_requirement: 0,
        stat_str: 0,
        stat_dex: 0,
        stat_con: 0,
        stat_int: 0,
        stat_wis: 0,
        stat_cha: 0,
        insulation: 0,
        is_prototype: false,
        vnum: None,
        triggers: vec![],
        vending_stock: vec![],
        vending_sell_rate: 150,
        quality: 0,
        bait_uses: 0,
        holes: 0,
        medical_tier: 0,
        medical_uses: 0,
        treats_wound_types: vec![],
        max_treatable_wound: String::new(),
        transport_link: None,
    };

    // Save corpse
    debug!("process_mobile_death: saving corpse");
    db.save_item_data(corpse)?;
    debug!("process_mobile_death: corpse saved");

    // Clear mobile's combat state (not strictly necessary since we're deleting)
    mobile.combat.in_combat = false;
    mobile.combat.targets.clear();

    // Remove the dead mobile from the database
    debug!("process_mobile_death: deleting mobile from database");
    db.delete_mobile(&mobile.id)?;
    debug!("process_mobile_death: mobile deleted, returning");

    Ok(())
}

/// Send a message to a specific character by name
fn send_message_to_character(connections: &SharedConnections, char_name: &str, message: &str) {
    if let Ok(conns) = connections.lock() {
        for (_, session) in conns.iter() {
            if let Some(ref char) = session.character {
                if char.name.to_lowercase() == char_name.to_lowercase() {
                    let _ = session.sender.send(format!("{}\n", message));
                    return;
                }
            }
        }
    }
}

/// Sync character data from database to session (for automatic combat updates)
fn sync_character_to_session(connections: &SharedConnections, char_data: &ironmud::CharacterData) {
    if let Ok(mut conns) = connections.lock() {
        for (_, session) in conns.iter_mut() {
            if let Some(ref existing_char) = session.character {
                if existing_char.name.to_lowercase() == char_data.name.to_lowercase() {
                    session.character = Some(char_data.clone());
                    return;
                }
            }
        }
    }
}

/// Broadcast to everyone in a room except a specific character
fn broadcast_to_room_except(connections: &SharedConnections, room_id: &uuid::Uuid, message: &str, exclude: &str) {
    if let Ok(conns) = connections.lock() {
        for (_, session) in conns.iter() {
            if let Some(ref char) = session.character {
                if char.current_room_id == *room_id && char.name.to_lowercase() != exclude.to_lowercase() {
                    let _ = session.sender.send(format!("{}\n", message));
                }
            }
        }
    }
}

/// Broadcast to non-sleeping characters in a room (excludes one character by name)
fn broadcast_to_room_except_awake(connections: &SharedConnections, room_id: &uuid::Uuid, message: &str, exclude: &str) {
    if let Ok(conns) = connections.lock() {
        for (_, session) in conns.iter() {
            if let Some(ref char) = session.character {
                if char.current_room_id == *room_id
                    && char.name.to_lowercase() != exclude.to_lowercase()
                    && char.position != ironmud::CharacterPosition::Sleeping
                {
                    let _ = session.sender.send(format!("{}\n", message));
                }
            }
        }
    }
}

/// Broadcast to everyone in a room
fn broadcast_to_room(connections: &SharedConnections, room_id: &uuid::Uuid, message: &str) {
    debug!("broadcast_to_room: acquiring connections lock");
    if let Ok(conns) = connections.lock() {
        debug!("broadcast_to_room: lock acquired, iterating sessions");
        for (_, session) in conns.iter() {
            if let Some(ref char) = session.character {
                if char.current_room_id == *room_id {
                    let _ = session.sender.send(format!("{}\n", message));
                }
            }
        }
        debug!("broadcast_to_room: done iterating, releasing lock");
    } else {
        debug!("broadcast_to_room: failed to acquire lock (poisoned?)");
    }
}

/// Broadcast to awake characters in a room (sleeping players don't see)
fn broadcast_to_room_awake(connections: &SharedConnections, room_id: &uuid::Uuid, message: &str) {
    if let Ok(conns) = connections.lock() {
        for (_, session) in conns.iter() {
            if let Some(ref char) = session.character {
                if char.current_room_id == *room_id
                    && char.position != ironmud::CharacterPosition::Sleeping
                {
                    let _ = session.sender.send(format!("{}\n", message));
                }
            }
        }
    }
}

// === Weather Exposure Tick System ===

/// Background task that processes weather exposure effects
async fn run_exposure_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(EXPOSURE_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_exposure_tick(&db, &connections) {
            error!("Exposure tick error: {}", e);
        }
    }
}

/// Process weather exposure for all logged-in players
fn process_exposure_tick(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use ironmud::{TemperatureCategory, WeatherCondition, BodyPart, WoundType, WoundLevel, Wound};

    let game_time = db.get_game_time()?;
    let outdoor_temp = game_time.calculate_effective_temperature();
    let weather = game_time.weather;

    // Collect helpline alerts to send after the main loop
    let mut helpline_alerts: Vec<String> = Vec::new();

    // Collect room broadcasts to send after releasing the lock (prevents deadlock)
    let mut room_broadcasts: Vec<(uuid::Uuid, String, String)> = Vec::new();

    let mut conns = connections.lock().unwrap();

    for (_conn_id, session) in conns.iter_mut() {
        if let Some(ref mut char) = session.character {
            // Skip if character creation is not complete
            if !char.creation_complete {
                continue;
            }

            // Skip exposure for god mode players
            if char.god_mode {
                continue;
            }

            // Get current room data
            let room = match db.get_room_data(&char.current_room_id) {
                Ok(Some(r)) => r,
                _ => continue,
            };

            let mut modified = false;

            // === Calculate effective temperature for this room ===
            // Check for climate_controlled (room or area inherited)
            let is_climate_controlled = room.flags.climate_controlled ||
                room.area_id.and_then(|aid| db.get_area_data(&aid).ok().flatten())
                    .map(|area| area.flags.climate_controlled)
                    .unwrap_or(false);
            let is_outdoors = !room.flags.indoors && !is_climate_controlled;

            // Indoor spaces moderate temperature toward 15°C (59°F comfortable)
            let effective_temp = if !is_outdoors {
                let target = 15;
                outdoor_temp + ((target - outdoor_temp) * 60 / 100)
            } else {
                outdoor_temp
            };

            let temp_category = match effective_temp {
                t if t < 0 => TemperatureCategory::Freezing,
                t if t < 10 => TemperatureCategory::Cold,
                t if t < 15 => TemperatureCategory::Cool,
                t if t < 20 => TemperatureCategory::Mild,
                t if t < 25 => TemperatureCategory::Warm,
                t if t < 35 => TemperatureCategory::Hot,
                _ => TemperatureCategory::Sweltering,
            };

            // === Process wet status ===
            let has_waterproof = check_waterproof_coverage(char, db);
            let has_warmth = check_room_warmth(&char.current_room_id, db);

            // Rain/snow causes wetness outdoors
            if is_outdoors && !has_waterproof {
                let wet_increase = match weather {
                    WeatherCondition::Thunderstorm | WeatherCondition::Blizzard => 30,
                    WeatherCondition::HeavyRain => 25,
                    WeatherCondition::Rain | WeatherCondition::Snow => 20,
                    WeatherCondition::LightRain | WeatherCondition::LightSnow => 10,
                    WeatherCondition::Fog => 5,
                    WeatherCondition::PartlyCloudy | WeatherCondition::Overcast |
                    WeatherCondition::Cloudy | WeatherCondition::Clear => 0,
                };
                if wet_increase > 0 {
                    char.wet_level = (char.wet_level + wet_increase).min(100);
                    char.is_wet = true;
                    modified = true;
                }
            }

            // Drying: faster near warmth sources (campfire, fireplace)
            let dry_rate = if has_warmth {
                30 // Near fire - fastest drying
            } else if room.flags.indoors {
                10 // Indoors - moderate drying
            } else {
                5 // Outdoors - slow drying
            };

            // Can dry if: near warmth, indoors, or outdoors with clear weather
            if char.wet_level > 0 && (has_warmth || room.flags.indoors || (is_outdoors && weather == WeatherCondition::Clear)) {
                char.wet_level = (char.wet_level - dry_rate).max(0);
                char.is_wet = char.wet_level > 0;
                modified = true;
            }

            // === Process temperature exposure ===
            let insulation = calculate_character_insulation(char, db);
            let wet_penalty = char.wet_level / 2; // Wet reduces insulation effectiveness

            // Cold exposure - only dangerous temperatures cause exposure
            let cold_threshold = match temp_category {
                TemperatureCategory::Freezing => 80,  // < 0°C - Need heavy insulation
                TemperatureCategory::Cold => 40,      // 0-9°C - Need moderate insulation
                TemperatureCategory::Cool => 0,       // 10-14°C - Cool but safe
                _ => 0,
            };

            if cold_threshold > 0 {
                let effective_insulation = (insulation - wet_penalty).max(0);
                let exposure_rate = if effective_insulation >= cold_threshold {
                    // Recovering - faster indoors, even faster near warmth
                    if has_warmth { -20 } else if !is_outdoors { -10 } else { -5 }
                } else {
                    ((cold_threshold - effective_insulation) / 10).max(1) as i32
                };
                char.cold_exposure = (char.cold_exposure + exposure_rate).clamp(0, 100);
                modified = true;
            } else {
                // Warm enough, recover from cold - faster indoors, even faster near warmth
                if char.cold_exposure > 0 {
                    let recovery = if has_warmth { 25 } else if !is_outdoors { 15 } else { 10 };
                    char.cold_exposure = (char.cold_exposure - recovery).max(0);
                    modified = true;
                }
            }

            // Heat exposure (insulation works against you in heat!)
            let heat_threshold = match temp_category {
                TemperatureCategory::Sweltering => 30, // High heat exposure
                TemperatureCategory::Hot => 15,        // Moderate heat exposure
                _ => 0,
            };

            if heat_threshold > 0 && is_outdoors {
                // Insulation makes heat worse!
                let exposure_rate = (heat_threshold + (insulation / 5)).max(1) as i32;
                char.heat_exposure = (char.heat_exposure + exposure_rate).clamp(0, 100);
                modified = true;
            } else {
                // Cool/indoors, recover from heat
                if char.heat_exposure > 0 {
                    char.heat_exposure = (char.heat_exposure - 15).max(0);
                    modified = true;
                }
            }

            // === Apply conditions based on exposure ===

            // Hypothermia at 50% cold exposure
            let had_hypothermia = char.has_hypothermia;
            char.has_hypothermia = char.cold_exposure >= 50;
            if char.has_hypothermia && !had_hypothermia {
                let _ = session.sender.send("You begin to shiver uncontrollably. You're getting hypothermia!\n".to_string());
            } else if !char.has_hypothermia && had_hypothermia {
                let _ = session.sender.send("Your body temperature returns to normal.\n".to_string());
            }

            // Frostbite wound at 80% cold exposure
            if char.cold_exposure >= 80 && char.has_frostbite.is_empty() {
                // Add frostbite wound to extremities
                let frostbite_part = if rand::random::<bool>() { BodyPart::LeftFoot } else { BodyPart::RightHand };
                char.has_frostbite.push(frostbite_part);
                char.wounds.push(Wound {
                    body_part: frostbite_part,
                    level: WoundLevel::Moderate,
                    wound_type: WoundType::Frostbite,
                    bleeding_severity: 0,
                });
                let _ = session.sender.send(format!("Your {} is getting frostbitten!\n", frostbite_part.to_display_string()));
                modified = true;
            }

            // Heat exhaustion at 50% heat exposure
            let had_heat_exhaustion = char.has_heat_exhaustion;
            char.has_heat_exhaustion = char.heat_exposure >= 50;
            if char.has_heat_exhaustion && !had_heat_exhaustion {
                let _ = session.sender.send("You're feeling lightheaded and weak from the heat!\n".to_string());
            } else if !char.has_heat_exhaustion && had_heat_exhaustion {
                let _ = session.sender.send("You feel better as you cool down.\n".to_string());
            }

            // Heat stroke at 80% heat exposure
            let had_heat_stroke = char.has_heat_stroke;
            char.has_heat_stroke = char.heat_exposure >= 80;
            if char.has_heat_stroke && !had_heat_stroke {
                let _ = session.sender.send("WARNING: You're suffering from heat stroke! Get to shade or you will collapse!\n".to_string());
            }

            // Illness progression from being wet and cold
            if char.is_wet && char.cold_exposure >= 25 {
                char.illness_progress = (char.illness_progress + 5).min(100);
                if char.illness_progress >= 50 && !char.has_illness {
                    char.has_illness = true;
                    let _ = session.sender.send("You're coming down with a cold. You should get warm and dry!\n".to_string());
                }
                modified = true;
            } else if char.has_illness {
                // Natural recovery when warm and dry
                if !char.is_wet && char.cold_exposure == 0 {
                    char.illness_progress = (char.illness_progress - 2).max(0);
                    if char.illness_progress == 0 {
                        char.has_illness = false;
                        let _ = session.sender.send("You feel better - your illness has passed.\n".to_string());
                    }
                    modified = true;
                }
            }

            // === Condition damage ===

            // Heat stroke damage
            if char.has_heat_stroke && !char.god_mode {
                char.hp = (char.hp - 2).max(1);
                modified = true;
            }

            // Illness damage (minor HP drain)
            if char.has_illness && char.illness_progress >= 75 {
                char.hp = (char.hp - 1).max(1);
                modified = true;
            }

            // Involuntary sneeze when ill (random chance each tick)
            if char.has_illness {
                use rand::Rng;
                let mut rng = rand::thread_rng();
                // ~10% chance per tick (every 30 seconds) = sneeze roughly every 5 minutes
                if rng.gen_range(0..100) < 10 {
                    // Tell the player they sneezed
                    let _ = session.sender.send("You sneeze uncontrollably!\n".to_string());
                    // Collect broadcast for others in the room (sent after lock is released)
                    room_broadcasts.push((
                        char.current_room_id,
                        format!("{} sneezes.", char.name),
                        char.name.clone(),
                    ));
                }
            }

            // Involuntary coughing when severely ill (illness_progress >= 75)
            if char.has_illness && char.illness_progress >= 75 {
                use rand::Rng;
                let mut rng = rand::thread_rng();
                // ~15% chance per tick = cough roughly every 3-4 minutes when severe
                if rng.gen_range(0..100) < 15 {
                    let _ = session.sender.send("You have a coughing fit!\n".to_string());
                    room_broadcasts.push((
                        char.current_room_id,
                        format!("{} coughs violently.", char.name),
                        char.name.clone(),
                    ));
                }
            }

            // Shivering from cold exposure (25+, more frequent as exposure increases)
            if char.cold_exposure >= 25 {
                use rand::Rng;
                let mut rng = rand::thread_rng();
                // Chance scales with exposure: 5% at 25, 10% at 50, 15% at 75, 20% at 100
                let shiver_chance = 5 + (char.cold_exposure - 25) / 5;
                if rng.gen_range(0..100) < shiver_chance as i32 {
                    let (player_msg, room_msg) = if char.cold_exposure >= 75 {
                        ("You shiver violently from the bitter cold!\n", format!("{} shivers violently.", char.name))
                    } else if char.cold_exposure >= 50 {
                        ("You shiver uncontrollably!\n", format!("{} shivers uncontrollably.", char.name))
                    } else {
                        ("You shiver from the cold.\n", format!("{} shivers.", char.name))
                    };
                    let _ = session.sender.send(player_msg.to_string());
                    room_broadcasts.push((
                        char.current_room_id,
                        room_msg,
                        char.name.clone(),
                    ));
                }
            }

            // Sweating from heat exposure (25+, more frequent as exposure increases)
            if char.heat_exposure >= 25 {
                use rand::Rng;
                let mut rng = rand::thread_rng();
                // Chance scales with exposure: 5% at 25, 10% at 50, 15% at 75, 20% at 100
                let sweat_chance = 5 + (char.heat_exposure - 25) / 5;
                if rng.gen_range(0..100) < sweat_chance as i32 {
                    let (player_msg, room_msg) = if char.heat_exposure >= 75 {
                        ("Sweat pours down your face as you struggle with the oppressive heat!\n", format!("{} is drenched in sweat.", char.name))
                    } else if char.heat_exposure >= 50 {
                        ("You wipe the sweat from your brow.\n", format!("{} wipes sweat from their brow.", char.name))
                    } else {
                        ("You feel yourself starting to sweat.\n", format!("{} is starting to sweat.", char.name))
                    };
                    let _ = session.sender.send(player_msg.to_string());
                    room_broadcasts.push((
                        char.current_room_id,
                        room_msg,
                        char.name.clone(),
                    ));
                }
            }

            // === Auto-alert helpline for critical states ===
            if char.has_heat_stroke || char.cold_exposure >= 90 {
                // Collect alert for helpline channel
                let room_name = room.title.clone();
                let alert_msg = if char.has_heat_stroke {
                    format!("{} is suffering from heat stroke!", char.name)
                } else {
                    format!("{} is severely hypothermic!", char.name)
                };
                helpline_alerts.push(format!("[HELPLINE] {} Location: {}\n", alert_msg, room_name));
            }

            if modified {
                let _ = db.save_character_data(char.clone());
            }
        }
    }

    // Drop the connections lock before sending broadcasts (prevents deadlock)
    drop(conns);

    // Send collected room broadcasts (each call acquires its own lock briefly)
    for (room_id, message, exclude) in room_broadcasts {
        broadcast_to_room_except(connections, &room_id, &message, &exclude);
    }

    // Send helpline alerts to all players with helpline enabled
    if !helpline_alerts.is_empty() {
        if let Ok(conns) = connections.lock() {
            for session in conns.values() {
                if let Some(ref char) = session.character {
                    if char.helpline_enabled {
                        for alert in &helpline_alerts {
                            let _ = session.sender.send(alert.clone());
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

/// Check if character has waterproof coverage from equipment
fn check_waterproof_coverage(char: &ironmud::CharacterData, db: &db::Db) -> bool {
    // Query database for equipped items (source of truth is ItemLocation::Equipped)
    if let Ok(equipped_items) = db.get_equipped_items(&char.name) {
        for item in equipped_items {
            if item.flags.waterproof {
                return true;
            }
        }
    }
    false
}

/// Check if room has warmth-providing items (campfire, fireplace, etc.)
fn check_room_warmth(room_id: &uuid::Uuid, db: &db::Db) -> bool {
    if let Ok(items) = db.get_items_in_room(room_id) {
        for item in items {
            if item.flags.provides_warmth {
                return true;
            }
        }
    }
    false
}

/// Transport tick interval in seconds (check frequently for responsive elevators)
const TRANSPORT_TICK_INTERVAL_SECS: u64 = 1;

/// Background task that processes transport movement (elevators, buses, trains)
async fn run_transport_tick(db: db::Db, connections: SharedConnections) {
    let mut ticker = interval(Duration::from_secs(TRANSPORT_TICK_INTERVAL_SECS));

    loop {
        ticker.tick().await;

        if let Err(e) = process_transport_tick(&db, &connections) {
            error!("Transport tick error: {}", e);
        }
    }
}

/// Get type-specific arrival messages for a transport
fn get_transport_arrival_messages(transport_type: &ironmud::TransportType, name: &str, stop_name: &str) -> (String, String) {
    use ironmud::TransportType;
    match transport_type {
        TransportType::Elevator => (
            format!("*Ding!* The {} stops. The doors slide open to {}.\n", name, stop_name),
            format!("The {} arrives and the doors slide open.\n", name),
        ),
        TransportType::Bus => (
            format!("The {} slows to a stop at {}. The doors hiss open.\n", name, stop_name),
            format!("The {} pulls up to the stop with a squeal of brakes.\n", name),
        ),
        TransportType::Train => (
            format!("The {} slows with a screech of brakes. \"{}!\" calls the conductor.\n", name, stop_name),
            format!("The {} rumbles into the station, coming to a stop.\n", name),
        ),
        TransportType::Ferry => (
            format!("The {} docks at {}. The gangway is lowered.\n", name, stop_name),
            format!("The {} approaches the dock, its horn sounding.\n", name),
        ),
        TransportType::Airship => (
            format!("The {} descends gently to {}. The boarding ramp extends.\n", name, stop_name),
            format!("The {} descends from the clouds, mooring at the tower.\n", name),
        ),
    }
}

/// Get type-specific departure messages for a transport
fn get_transport_departure_messages(transport_type: &ironmud::TransportType, name: &str, next_stop: &str) -> (String, String) {
    use ironmud::TransportType;
    match transport_type {
        TransportType::Elevator => (
            format!("The doors slide closed. Next stop: {}.\n", next_stop),
            format!("The {} doors slide closed.\n", name),
        ),
        TransportType::Bus => (
            format!("The doors close with a hiss. Next stop: {}.\n", next_stop),
            format!("The {} pulls away from the curb.\n", name),
        ),
        TransportType::Train => (
            format!("\"All aboard!\" The doors close and the {} lurches forward. Next stop: {}.\n", name, next_stop),
            format!("With a blast of its whistle, the {} departs.\n", name),
        ),
        TransportType::Ferry => (
            format!("The gangway is raised. The {} casts off, heading for {}.\n", name, next_stop),
            format!("The {} sounds its horn and pulls away from the dock.\n", name),
        ),
        TransportType::Airship => (
            format!("The boarding ramp retracts. The {} rises smoothly toward {}.\n", name, next_stop),
            format!("The {} releases its moorings and ascends into the sky.\n", name),
        ),
    }
}

/// Process NPC boarding and disembarking when transport arrives at a stop
fn process_npc_transport_at_stop(
    db: &db::Db,
    connections: &SharedConnections,
    transport: &ironmud::TransportData,
    stop_index: usize,
    game_hour: u8,
) {
    use ironmud::NPCTravelSchedule;

    let stop = &transport.stops[stop_index];
    let stop_room_id = stop.room_id;
    let interior_room_id = transport.interior_room_id;

    // Get all mobiles with transport routes for this transport
    let mobiles = match db.list_all_mobiles() {
        Ok(m) => m,
        Err(_) => return,
    };

    for mut mobile in mobiles {
        if let Some(ref mut route) = mobile.transport_route {
            if route.transport_id != transport.id {
                continue;
            }

            // Handle Permanent schedule (conductors) - always on transport
            if matches!(route.schedule, NPCTravelSchedule::Permanent) {
                if !route.is_on_transport {
                    // Put them on the transport
                    mobile.current_room_id = Some(interior_room_id);
                    route.is_on_transport = true;
                    let _ = db.save_mobile_data(mobile);
                }
                continue;
            }

            // Check if NPC should disembark at this stop
            if route.is_on_transport {
                let should_disembark = if route.is_at_destination {
                    // Going home - disembark at home stop
                    stop_index == route.home_stop_index
                } else {
                    // Going to destination - disembark at destination stop
                    stop_index == route.destination_stop_index
                };

                if should_disembark {
                    // Move NPC to stop room
                    mobile.current_room_id = Some(stop_room_id);
                    route.is_on_transport = false;
                    route.is_at_destination = !route.is_at_destination; // Toggle location
                    let _ = db.save_mobile_data(mobile.clone());

                    // Announce arrival
                    let msg = format!("{} steps off the {}.\n", mobile.name, transport.name);
                    broadcast_to_room_awake(connections, &stop_room_id, &msg);
                    continue;
                }
            }

            // Check if NPC should board at this stop
            if !route.is_on_transport {
                let at_boarding_stop = if route.is_at_destination {
                    // At destination, check if should return home
                    stop_index == route.destination_stop_index &&
                    mobile.current_room_id == Some(stop_room_id)
                } else {
                    // At home, check if should go to destination
                    stop_index == route.home_stop_index &&
                    mobile.current_room_id == Some(stop_room_id)
                };

                if at_boarding_stop {
                    let should_board = match &route.schedule {
                        NPCTravelSchedule::FixedHours { depart_hour, return_hour } => {
                            if route.is_at_destination {
                                // At destination, board to return home
                                game_hour >= *return_hour || game_hour < *depart_hour
                            } else {
                                // At home, board to go to destination
                                game_hour >= *depart_hour && game_hour < *return_hour
                            }
                        }
                        NPCTravelSchedule::Random { chance_per_hour } => {
                            // Roll for chance
                            use rand::Rng;
                            rand::thread_rng().gen_range(1..=100) <= *chance_per_hour
                        }
                        NPCTravelSchedule::Permanent => false, // Handled above
                    };

                    if should_board {
                        // Move NPC to transport interior
                        mobile.current_room_id = Some(interior_room_id);
                        route.is_on_transport = true;
                        let _ = db.save_mobile_data(mobile.clone());

                        // Announce boarding
                        let msg = format!("{} boards the {}.\n", mobile.name, transport.name);
                        broadcast_to_room_awake(connections, &stop_room_id, &msg);
                    }
                }
            }
        }
    }
}

/// Process all transports, completing travel for those in motion
fn process_transport_tick(db: &db::Db, connections: &SharedConnections) -> Result<()> {
    use ironmud::{TransportState, TransportSchedule};

    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);

    let transports = db.list_all_transports()?;

    for mut transport in transports {
        match transport.state {
            TransportState::Moving => {
                // Check if travel time has elapsed
                let travel_complete_time = transport.last_state_change + transport.travel_time_secs;
                if now >= travel_complete_time {
                    // Travel complete - arrive at destination
                    let stop = &transport.stops[transport.current_stop_index];
                    let stop_name = stop.name.clone();
                    let stop_room_id = stop.room_id;
                    let exit_direction = stop.exit_direction.clone();

                    // Create exits (connect transport to stop)
                    // Exit from stop room to vehicle interior
                    db.set_room_exit(&stop_room_id, &exit_direction, &transport.interior_room_id)?;
                    // Exit from vehicle interior to stop room
                    db.set_room_exit(&transport.interior_room_id, "out", &stop_room_id)?;

                    // Update transport state
                    transport.state = TransportState::Stopped;
                    transport.last_state_change = now;
                    db.save_transport(&transport)?;

                    // Set dynamic description on stop room
                    let dynamic_desc = format!("The {} is here, doors open.", transport.name);
                    if let Ok(Some(mut room)) = db.get_room_data(&stop_room_id) {
                        room.dynamic_desc = Some(dynamic_desc);
                        let _ = db.save_room_data(room);
                    }

                    // Type-specific arrival messages
                    let (inside_msg, outside_msg) = get_transport_arrival_messages(
                        &transport.transport_type, &transport.name, &stop_name
                    );
                    broadcast_to_room(connections, &transport.interior_room_id, &inside_msg);
                    broadcast_to_room_awake(connections, &stop_room_id, &outside_msg);

                    // Process NPC boarding/disembarking
                    let game_hour = db.get_game_time().map(|t| t.hour).unwrap_or(12);
                    process_npc_transport_at_stop(db, connections, &transport, transport.current_stop_index, game_hour);
                }
            }
            TransportState::Stopped => {
                // For scheduled transports, check if it's time to depart
                if let TransportSchedule::GameTime { dwell_time_secs, .. } = transport.schedule {
                    let depart_time = transport.last_state_change + dwell_time_secs;
                    if now >= depart_time {
                        // Check operating hours
                        let game_time = db.get_game_time()?;
                        let hour = game_time.hour;
                        if transport.is_within_operating_hours(hour) {
                            // Time to depart
                            let current_stop = &transport.stops[transport.current_stop_index];
                            let current_stop_room_id = current_stop.room_id;
                            let current_exit_dir = current_stop.exit_direction.clone();

                            // Remove exits (disconnect transport from stop)
                            db.clear_room_exit(&current_stop_room_id, &current_exit_dir)?;
                            db.clear_room_exit(&transport.interior_room_id, "out")?;

                            // Clear dynamic description from stop room
                            if let Ok(Some(mut room)) = db.get_room_data(&current_stop_room_id) {
                                room.dynamic_desc = None;
                                let _ = db.save_room_data(room);
                            }

                            // Advance to next stop
                            transport.advance_to_next_stop();
                            let next_stop_name = transport.stops[transport.current_stop_index].name.clone();

                            // Update state
                            transport.state = TransportState::Moving;
                            transport.last_state_change = now;
                            db.save_transport(&transport)?;

                            // Type-specific departure messages
                            let (inside_msg, outside_msg) = get_transport_departure_messages(
                                &transport.transport_type, &transport.name, &next_stop_name
                            );
                            broadcast_to_room(connections, &transport.interior_room_id, &inside_msg);
                            broadcast_to_room_awake(connections, &current_stop_room_id, &outside_msg);
                        }
                    }
                }
                // On-demand transports stay stopped until called
            }
        }
    }

    Ok(())
}