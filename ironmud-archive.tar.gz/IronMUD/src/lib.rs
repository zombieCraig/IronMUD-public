use anyhow::Result;
use notify::{RecursiveMode, Watcher};
use rhai::{Engine, AST};
use std::collections::{HashMap, VecDeque};
use std::path::Path;
use std::sync::{Arc, Mutex};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use tokio::sync::mpsc;
use tracing::{debug, error, info};
use uuid::Uuid;
use serde::{Deserialize, Serialize};
use rhai::Position;
use glob::glob;

pub mod claude;
pub mod gemini;
pub mod completion;
pub mod db;
pub mod game;
pub mod matrix;
pub mod script;
pub mod telnet;

use game::Entity; // Keep this one for the Entity struct

// Starting room UUID constant
pub const STARTING_ROOM_ID: &str = "00000000-0000-0000-0000-000000000001";

// Define CharacterData, ConnectionId and PlayerSession here
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CharacterData {
    pub name: String,
    pub password_hash: String,
    pub current_room_id: Uuid,
    #[serde(default)]
    pub aliases: HashMap<String, String>,
    #[serde(default)]
    pub is_builder: bool,
    #[serde(default)]
    pub is_admin: bool,
    #[serde(default)]
    pub god_mode: bool,
    #[serde(default = "default_level")]
    pub level: i32,
    #[serde(default)]
    pub gold: i32,
    // Character creation wizard fields
    #[serde(default)]
    pub race: String,
    #[serde(default)]
    pub short_description: String,
    #[serde(default = "default_class")]
    pub class_name: String,
    #[serde(default)]
    pub traits: Vec<String>,
    #[serde(default = "default_trait_points")]
    pub trait_points: i32,
    #[serde(default)]
    pub creation_complete: bool,
    // Thirst system fields
    #[serde(default = "default_max_thirst")]
    pub thirst: i32,
    #[serde(default = "default_max_thirst")]
    pub max_thirst: i32,
    #[serde(default)]
    pub last_thirst_tick: i64,
    // HP system fields
    #[serde(default = "default_max_hp")]
    pub hp: i32,
    #[serde(default = "default_max_hp")]
    pub max_hp: i32,
    // Prompt settings
    #[serde(default)]
    pub prompt_mode: String,  // "simple" (default) or "verbose"
    // Password management
    #[serde(default)]
    pub must_change_password: bool,
    // Builder mode: show room flags/vnum in room display (persisted)
    #[serde(default)]
    pub show_room_flags: bool,
    // Builder debug channel subscription
    #[serde(default)]
    pub builder_debug_enabled: bool,
    // Stamina system fields
    #[serde(default = "default_max_stamina")]
    pub stamina: i32,
    #[serde(default = "default_max_stamina")]
    pub max_stamina: i32,
    #[serde(default)]
    pub position: CharacterPosition,
    // Skill system
    #[serde(default)]
    pub skills: HashMap<String, SkillProgress>,
    // Learned recipes (recipe IDs learned from books/trainers, not auto-learned)
    #[serde(default)]
    pub learned_recipes: std::collections::HashSet<String>,
    // Foraging cooldown tracking (room_id -> timestamp of last forage)
    #[serde(default)]
    pub foraged_rooms: HashMap<String, i64>,
    // Group/Party system fields
    #[serde(default)]
    pub following: Option<String>,    // Name of character being followed
    #[serde(default)]
    pub is_grouped: bool,             // Whether actively grouped (not just following)
    // Character stats (affect carrying capacity, health, stamina, etc.)
    #[serde(default = "default_stat")]
    pub stat_str: i32,  // Strength - affects carrying capacity
    #[serde(default = "default_stat")]
    pub stat_dex: i32,  // Dexterity
    #[serde(default = "default_stat")]
    pub stat_con: i32,  // Constitution - affects max health/stamina
    #[serde(default = "default_stat")]
    pub stat_int: i32,  // Intelligence
    #[serde(default = "default_stat")]
    pub stat_wis: i32,  // Wisdom
    #[serde(default = "default_stat")]
    pub stat_cha: i32,  // Charisma
    // Combat system fields
    #[serde(default)]
    pub spawn_room_id: Option<Uuid>,  // Respawn location on death
    #[serde(default)]
    pub combat: CombatState,
    #[serde(default)]
    pub wounds: Vec<Wound>,
    // Death/unconscious state (not persisted - cleared on login)
    #[serde(skip)]
    pub is_unconscious: bool,
    #[serde(skip)]
    pub bleedout_rounds_remaining: i32,
    // Weather exposure status (transient, cleared on login)
    #[serde(skip)]
    pub is_wet: bool,
    #[serde(skip)]
    pub wet_level: i32,           // 0-100, higher = more soaked
    #[serde(skip)]
    pub cold_exposure: i32,       // 0-100, escalates to hypothermia at thresholds
    #[serde(skip)]
    pub heat_exposure: i32,       // 0-100, escalates to heat exhaustion
    // Environmental conditions (persisted)
    #[serde(default)]
    pub illness_progress: i32,    // 0-100, illness severity
    #[serde(default)]
    pub has_hypothermia: bool,
    #[serde(default)]
    pub has_frostbite: Vec<BodyPart>,  // Body parts affected
    #[serde(default)]
    pub has_heat_exhaustion: bool,
    #[serde(default)]
    pub has_heat_stroke: bool,
    #[serde(default)]
    pub has_illness: bool,
    // Helpline channel subscription
    #[serde(default)]
    pub helpline_enabled: bool,
}

fn default_level() -> i32 {
    1
}

fn default_stat() -> i32 {
    10  // Average stat value
}

fn default_max_thirst() -> i32 {
    100
}

fn default_max_hp() -> i32 {
    100
}

fn default_max_stamina() -> i32 {
    100
}

fn default_class() -> String {
    "unemployed".to_string()
}

fn default_trait_points() -> i32 {
    10
}

// Character creation data structures (loaded from scripts/data/*.json)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClassDefinition {
    pub id: String,
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub starting_skills: Vec<String>,
    #[serde(default)]
    pub stat_bonuses: HashMap<String, i32>,
    #[serde(default = "default_true")]
    pub available: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TraitCategory {
    Positive,
    Negative,
}

impl Default for TraitCategory {
    fn default() -> Self {
        TraitCategory::Positive
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum CharacterPosition {
    #[default]
    Standing,
    Sitting,
    Sleeping,
}

impl std::fmt::Display for CharacterPosition {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CharacterPosition::Standing => write!(f, "standing"),
            CharacterPosition::Sitting => write!(f, "sitting"),
            CharacterPosition::Sleeping => write!(f, "sleeping"),
        }
    }
}

// Combat system types
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum CombatTargetType {
    #[default]
    Mobile,
    Player,
}

impl CombatTargetType {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "mobile" | "mob" | "npc" => Some(CombatTargetType::Mobile),
            "player" | "character" => Some(CombatTargetType::Player),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            CombatTargetType::Mobile => "mobile",
            CombatTargetType::Player => "player",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CombatTarget {
    pub target_type: CombatTargetType,
    pub target_id: Uuid,
}

impl Default for CombatTarget {
    fn default() -> Self {
        CombatTarget {
            target_type: CombatTargetType::default(),
            target_id: Uuid::nil(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CombatState {
    #[serde(default)]
    pub in_combat: bool,
    #[serde(default)]
    pub targets: Vec<CombatTarget>,
    #[serde(default)]
    pub stun_rounds_remaining: i32,
}

/// Combat zone type - determines what combat is allowed in an area/room
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum CombatZoneType {
    #[default]
    Pve,   // Default: can attack mobiles, not players
    Safe,  // No combat at all
    Pvp,   // Can attack mobiles and players
}

impl CombatZoneType {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "pve" | "normal" | "default" => Some(CombatZoneType::Pve),
            "safe" | "peaceful" | "no_combat" => Some(CombatZoneType::Safe),
            "pvp" | "arena" | "full" => Some(CombatZoneType::Pvp),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            CombatZoneType::Pve => "pve",
            CombatZoneType::Safe => "safe",
            CombatZoneType::Pvp => "pvp",
        }
    }

    /// Returns true if players can attack mobiles in this zone
    pub fn can_attack_mobiles(&self) -> bool {
        match self {
            CombatZoneType::Pve => true,
            CombatZoneType::Safe => false,
            CombatZoneType::Pvp => true,
        }
    }

    /// Returns true if players can attack other players in this zone
    pub fn can_attack_players(&self) -> bool {
        match self {
            CombatZoneType::Pve => false,
            CombatZoneType::Safe => false,
            CombatZoneType::Pvp => true,
        }
    }
}

/// Body parts for combat targeting and wound tracking
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
pub enum BodyPart {
    Head,
    Neck,
    Torso,
    LeftArm,
    RightArm,
    LeftLeg,
    RightLeg,
    LeftHand,
    RightHand,
    LeftFoot,
    RightFoot,
}

impl BodyPart {
    /// Returns the hit weight for random targeting (total = 100)
    pub fn hit_weight(&self) -> u32 {
        match self {
            BodyPart::Head => 8,
            BodyPart::Neck => 3,
            BodyPart::Torso => 35,
            BodyPart::LeftArm | BodyPart::RightArm => 12,
            BodyPart::LeftLeg | BodyPart::RightLeg => 12,
            BodyPart::LeftHand | BodyPart::RightHand => 4,
            BodyPart::LeftFoot | BodyPart::RightFoot => 4,
        }
    }

    /// Returns true if this is a vital body part (critical wounds cause instant KO)
    pub fn is_vital(&self) -> bool {
        matches!(self, BodyPart::Head | BodyPart::Neck | BodyPart::Torso)
    }

    /// Returns all body parts
    pub fn all() -> Vec<BodyPart> {
        vec![
            BodyPart::Head,
            BodyPart::Neck,
            BodyPart::Torso,
            BodyPart::LeftArm,
            BodyPart::RightArm,
            BodyPart::LeftLeg,
            BodyPart::RightLeg,
            BodyPart::LeftHand,
            BodyPart::RightHand,
            BodyPart::LeftFoot,
            BodyPart::RightFoot,
        ]
    }

    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().replace([' ', '_'], "").as_str() {
            "head" => Some(BodyPart::Head),
            "neck" => Some(BodyPart::Neck),
            "torso" | "chest" | "body" => Some(BodyPart::Torso),
            "leftarm" | "larm" => Some(BodyPart::LeftArm),
            "rightarm" | "rarm" => Some(BodyPart::RightArm),
            "leftleg" | "lleg" => Some(BodyPart::LeftLeg),
            "rightleg" | "rleg" => Some(BodyPart::RightLeg),
            "lefthand" | "lhand" => Some(BodyPart::LeftHand),
            "righthand" | "rhand" => Some(BodyPart::RightHand),
            "leftfoot" | "lfoot" => Some(BodyPart::LeftFoot),
            "rightfoot" | "rfoot" => Some(BodyPart::RightFoot),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            BodyPart::Head => "head",
            BodyPart::Neck => "neck",
            BodyPart::Torso => "torso",
            BodyPart::LeftArm => "left arm",
            BodyPart::RightArm => "right arm",
            BodyPart::LeftLeg => "left leg",
            BodyPart::RightLeg => "right leg",
            BodyPart::LeftHand => "left hand",
            BodyPart::RightHand => "right hand",
            BodyPart::LeftFoot => "left foot",
            BodyPart::RightFoot => "right foot",
        }
    }
}

/// Wound severity levels
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum WoundLevel {
    #[default]
    None,
    Minor,      // 10% penalty
    Moderate,   // 25% penalty
    Severe,     // 50% penalty
    Critical,   // 75% penalty
    Disabled,   // 100% penalty
}

impl WoundLevel {
    /// Returns the penalty percentage (0-100) for this wound level
    pub fn penalty(&self) -> i32 {
        match self {
            WoundLevel::None => 0,
            WoundLevel::Minor => 10,
            WoundLevel::Moderate => 25,
            WoundLevel::Severe => 50,
            WoundLevel::Critical => 75,
            WoundLevel::Disabled => 100,
        }
    }

    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "none" => Some(WoundLevel::None),
            "minor" => Some(WoundLevel::Minor),
            "moderate" => Some(WoundLevel::Moderate),
            "severe" => Some(WoundLevel::Severe),
            "critical" => Some(WoundLevel::Critical),
            "disabled" => Some(WoundLevel::Disabled),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            WoundLevel::None => "none",
            WoundLevel::Minor => "minor",
            WoundLevel::Moderate => "moderate",
            WoundLevel::Severe => "severe",
            WoundLevel::Critical => "critical",
            WoundLevel::Disabled => "disabled",
        }
    }

    /// Returns the next worse wound level
    pub fn escalate(&self) -> Self {
        match self {
            WoundLevel::None => WoundLevel::Minor,
            WoundLevel::Minor => WoundLevel::Moderate,
            WoundLevel::Moderate => WoundLevel::Severe,
            WoundLevel::Severe => WoundLevel::Critical,
            WoundLevel::Critical => WoundLevel::Disabled,
            WoundLevel::Disabled => WoundLevel::Disabled,
        }
    }
}

/// Type of wound based on damage type
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WoundType {
    Cut,        // Slashing damage
    Puncture,   // Piercing damage
    Bruise,     // Bludgeoning (mild)
    Fracture,   // Bludgeoning (severe)
    Burn,       // Fire damage
    Frostbite,  // Cold damage
    Poisoned,   // Poison damage
    Corroded,   // Acid damage
}

impl WoundType {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "cut" | "slash" | "laceration" => Some(WoundType::Cut),
            "puncture" | "pierce" | "stab" => Some(WoundType::Puncture),
            "bruise" | "blunt" => Some(WoundType::Bruise),
            "fracture" | "break" | "crush" => Some(WoundType::Fracture),
            "burn" | "fire" | "scorch" => Some(WoundType::Burn),
            "frostbite" | "cold" | "freeze" => Some(WoundType::Frostbite),
            "poisoned" | "poison" | "toxic" => Some(WoundType::Poisoned),
            "corroded" | "acid" | "dissolve" => Some(WoundType::Corroded),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            WoundType::Cut => "cut",
            WoundType::Puncture => "puncture",
            WoundType::Bruise => "bruise",
            WoundType::Fracture => "fracture",
            WoundType::Burn => "burn",
            WoundType::Frostbite => "frostbite",
            WoundType::Poisoned => "poisoned",
            WoundType::Corroded => "corroded",
        }
    }
}

/// A wound on a body part
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Wound {
    pub body_part: BodyPart,
    pub level: WoundLevel,
    pub wound_type: WoundType,
    #[serde(default)]
    pub bleeding_severity: i32,  // 0-5, damage per round from bleeding
}

/// Weapon skill categories for combat
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Hash)]
#[serde(rename_all = "snake_case")]
pub enum WeaponSkill {
    ShortBlades,  // Daggers, knives, shortswords
    LongBlades,   // Swords, longswords, greatswords
    ShortBlunt,   // Clubs, maces, hammers
    LongBlunt,    // Warhammers, staves, mauls
    Polearms,     // Spears, halberds, pikes
    Unarmed,      // Fists, natural weapons
    Ranged,       // Bows, crossbows
}

impl WeaponSkill {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
            "shortblades" | "shortblade" | "dagger" | "knife" => Some(WeaponSkill::ShortBlades),
            "longblades" | "longblade" | "sword" | "longsword" => Some(WeaponSkill::LongBlades),
            "shortblunt" | "club" | "mace" | "hammer" => Some(WeaponSkill::ShortBlunt),
            "longblunt" | "warhammer" | "staff" | "maul" => Some(WeaponSkill::LongBlunt),
            "polearms" | "polearm" | "spear" | "halberd" | "pike" => Some(WeaponSkill::Polearms),
            "unarmed" | "fists" | "fist" | "natural" => Some(WeaponSkill::Unarmed),
            "ranged" | "bow" | "crossbow" | "archery" => Some(WeaponSkill::Ranged),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            WeaponSkill::ShortBlades => "short blades",
            WeaponSkill::LongBlades => "long blades",
            WeaponSkill::ShortBlunt => "short blunt",
            WeaponSkill::LongBlunt => "long blunt",
            WeaponSkill::Polearms => "polearms",
            WeaponSkill::Unarmed => "unarmed",
            WeaponSkill::Ranged => "ranged",
        }
    }

    /// Returns all weapon skill types
    pub fn all() -> Vec<WeaponSkill> {
        vec![
            WeaponSkill::ShortBlades,
            WeaponSkill::LongBlades,
            WeaponSkill::ShortBlunt,
            WeaponSkill::LongBlunt,
            WeaponSkill::Polearms,
            WeaponSkill::Unarmed,
            WeaponSkill::Ranged,
        ]
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TraitDefinition {
    pub id: String,
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub cost: i32,
    #[serde(default)]
    pub category: TraitCategory,
    #[serde(default)]
    pub effects: HashMap<String, i32>,
    #[serde(default)]
    pub conflicts_with: Vec<String>,
    #[serde(default = "default_true")]
    pub available: bool,
}

// Skill system
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct SkillProgress {
    pub level: i32,           // 0-10
    pub experience: i32,      // XP toward next level
}

// Recipe/Crafting system
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Recipe {
    pub id: String,
    pub name: String,
    pub skill: String,                  // "crafting" or "cooking"
    #[serde(default)]
    pub skill_required: i32,            // Minimum skill level (0-10)
    #[serde(default)]
    pub auto_learn: bool,               // Learned automatically at skill level?
    #[serde(default)]
    pub ingredients: Vec<RecipeIngredient>,
    #[serde(default)]
    pub tools: Vec<RecipeTool>,
    pub output_vnum: String,            // Prototype vnum to spawn
    #[serde(default = "default_one")]
    pub output_quantity: i32,           // How many to produce
    #[serde(default)]
    pub base_xp: i32,                   // XP awarded on success
    #[serde(default = "default_one")]
    pub difficulty: i32,                // Affects quality roll (1-10)
}

fn default_one() -> i32 {
    1
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecipeIngredient {
    #[serde(default)]
    pub vnum: Option<String>,           // Exact vnum (if specified)
    #[serde(default)]
    pub category: Option<String>,       // Category match (e.g., "flour", "meat")
    #[serde(default = "default_one")]
    pub quantity: i32,                  // How many needed
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RecipeTool {
    #[serde(default)]
    pub vnum: Option<String>,           // Exact tool vnum (if specified)
    #[serde(default)]
    pub category: Option<String>,       // Tool category (e.g., "knife", "forge")
    #[serde(default)]
    pub location: ToolLocation,         // Where to find it
}

#[derive(Debug, Clone, Serialize, Deserialize, Default, PartialEq)]
pub enum ToolLocation {
    #[default]
    Inventory,                          // Must be in player's inventory
    Room,                               // Must be in current room
    Either,                             // Can be in inventory OR room
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RaceSuggestion {
    pub name: String,
    #[serde(default)]
    pub description: String,
}

fn default_true() -> bool {
    true
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomData {
    pub id: Uuid,
    pub title: String,
    pub description: String,
    pub exits: RoomExits,
    #[serde(default)]
    pub flags: RoomFlags,
    #[serde(default)]
    pub extra_descs: Vec<ExtraDesc>,
    #[serde(default)]
    pub vnum: Option<String>,
    #[serde(default)]
    pub area_id: Option<Uuid>,
    #[serde(default)]
    pub triggers: Vec<RoomTrigger>,
    #[serde(default)]
    pub doors: std::collections::HashMap<String, DoorState>,
    // Seasonal descriptions - auto-display based on current game season
    #[serde(default)]
    pub spring_desc: Option<String>,
    #[serde(default)]
    pub summer_desc: Option<String>,
    #[serde(default)]
    pub autumn_desc: Option<String>,
    #[serde(default)]
    pub winter_desc: Option<String>,
    // Dynamic description - set by triggers for weather, events, etc.
    #[serde(default)]
    pub dynamic_desc: Option<String>,
    // Fishing system
    #[serde(default)]
    pub water_type: WaterType,
    #[serde(default)]
    pub catch_table: Vec<CatchEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RoomExits {
    pub north: Option<Uuid>,
    pub east: Option<Uuid>,
    pub south: Option<Uuid>,
    pub west: Option<Uuid>,
    pub up: Option<Uuid>,
    pub down: Option<Uuid>,
    #[serde(default)]
    pub out: Option<Uuid>,  // Used for transport vehicles, buildings, etc.
    #[serde(default)]
    pub custom: std::collections::HashMap<String, Uuid>,  // Custom exits like "elevator", "train", "portal"
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct DoorState {
    pub name: String,              // "door", "gate", "hatch", etc.
    pub is_closed: bool,
    pub is_locked: bool,
    pub key_id: Option<Uuid>,
    pub description: Option<String>,
    #[serde(default)]
    pub keywords: Vec<String>,     // Additional keywords like "wooden", "iron"
}

// === Fishing System - Water Types ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum WaterType {
    #[default]
    None,
    Freshwater,
    Saltwater,
    Magical,
}

impl WaterType {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "none" => Some(WaterType::None),
            "freshwater" | "fresh" => Some(WaterType::Freshwater),
            "saltwater" | "salt" | "ocean" => Some(WaterType::Saltwater),
            "magical" | "magic" => Some(WaterType::Magical),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            WaterType::None => "none",
            WaterType::Freshwater => "freshwater",
            WaterType::Saltwater => "saltwater",
            WaterType::Magical => "magical",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CatchEntry {
    pub vnum: String,       // Item vnum to spawn
    pub weight: i32,        // Relative spawn weight
    pub min_skill: i32,     // Minimum skill level (0-10)
    pub rarity: String,     // common/uncommon/rare/legendary
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ForageEntry {
    pub vnum: String,       // Item vnum to spawn (weight comes from item prototype)
    pub min_skill: i32,     // Minimum skill level (0-10)
    pub rarity: String,     // common/uncommon/rare/legendary
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RoomFlags {
    #[serde(default)]
    pub dark: bool,
    /// Room-level combat zone override (None = inherit from area)
    #[serde(default)]
    pub combat_zone: Option<CombatZoneType>,
    #[serde(default)]
    pub no_mob: bool,
    #[serde(default)]
    pub indoors: bool,
    #[serde(default)]
    pub underwater: bool,
    // Climate/weather flags
    #[serde(default)]
    pub climate_controlled: bool,  // Room ignores outside weather/temp
    #[serde(default)]
    pub always_hot: bool,          // Forge, volcano, etc.
    #[serde(default)]
    pub always_cold: bool,         // Ice cave, freezer, etc.
    #[serde(default)]
    pub city: bool,                // City rooms stay lit at night
    #[serde(default)]
    pub no_windows: bool,          // No day/night messages (caves, deep buildings)
    // Stamina system flag
    #[serde(default)]
    pub difficult_terrain: bool,   // Costs 2 stamina to traverse instead of 1
    // Foraging flag
    #[serde(default)]
    pub dirt_floor: bool,          // Allows wilderness foraging
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExtraDesc {
    pub keywords: Vec<String>,
    pub description: String,
}

// === Room Trigger System ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TriggerType {
    OnEnter,
    OnExit,
    OnLook,
    Periodic,
    OnTimeChange,    // Fires when time of day changes (dawn, dusk, etc.)
    OnWeatherChange, // Fires when weather changes (rain starts, clears up, etc.)
    OnSeasonChange,  // Fires when season changes (spring, summer, autumn, winter)
    OnMonthChange,   // Fires when month changes (1-12)
}

impl Default for TriggerType {
    fn default() -> Self {
        TriggerType::OnEnter
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomTrigger {
    pub trigger_type: TriggerType,
    pub script_name: String,      // e.g., "forest_trap" or "@say_greeting" for templates
    pub enabled: bool,
    #[serde(default = "default_trigger_interval")]
    pub interval_secs: i64,       // For periodic triggers (default 60)
    #[serde(default)]
    pub last_fired: i64,          // Unix timestamp of last execution
    #[serde(default = "default_trigger_chance")]
    pub chance: i32,              // 1-100 percent (100 = always)
    #[serde(default)]
    pub args: Vec<String>,        // Template arguments
}

fn default_trigger_interval() -> i64 {
    60
}

fn default_trigger_chance() -> i32 {
    100
}

impl Default for RoomTrigger {
    fn default() -> Self {
        RoomTrigger {
            trigger_type: TriggerType::OnEnter,
            script_name: String::new(),
            enabled: true,
            interval_secs: 60,
            last_fired: 0,
            chance: 100,
            args: Vec::new(),
        }
    }
}

// === Game Time and Weather System ===

/// Game time constants
pub const REAL_MINUTES_PER_GAME_HOUR: u64 = 2;  // 2 real minutes = 1 game hour
pub const GAME_HOURS_PER_DAY: u64 = 24;
pub const GAME_DAYS_PER_MONTH: u64 = 30;
pub const GAME_MONTHS_PER_YEAR: u64 = 12;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Season {
    Spring,  // Months 3, 4, 5
    Summer,  // Months 6, 7, 8
    Autumn,  // Months 9, 10, 11
    Winter,  // Months 12, 1, 2
}

impl Default for Season {
    fn default() -> Self {
        Season::Spring
    }
}

impl std::fmt::Display for Season {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Season::Spring => write!(f, "Spring"),
            Season::Summer => write!(f, "Summer"),
            Season::Autumn => write!(f, "Autumn"),
            Season::Winter => write!(f, "Winter"),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TimeOfDay {
    Dawn,       // 5-6
    Morning,    // 7-11
    Noon,       // 12-13
    Afternoon,  // 14-16
    Dusk,       // 17-18
    Evening,    // 19-21
    Night,      // 22-4
}

impl Default for TimeOfDay {
    fn default() -> Self {
        TimeOfDay::Morning
    }
}

impl std::fmt::Display for TimeOfDay {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TimeOfDay::Dawn => write!(f, "dawn"),
            TimeOfDay::Morning => write!(f, "morning"),
            TimeOfDay::Noon => write!(f, "high noon"),
            TimeOfDay::Afternoon => write!(f, "afternoon"),
            TimeOfDay::Dusk => write!(f, "dusk"),
            TimeOfDay::Evening => write!(f, "evening"),
            TimeOfDay::Night => write!(f, "night"),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WeatherCondition {
    Clear,
    PartlyCloudy,
    Cloudy,
    Overcast,
    LightRain,
    Rain,
    HeavyRain,
    Thunderstorm,
    LightSnow,
    Snow,
    Blizzard,
    Fog,
}

impl Default for WeatherCondition {
    fn default() -> Self {
        WeatherCondition::Clear
    }
}

impl std::fmt::Display for WeatherCondition {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            WeatherCondition::Clear => write!(f, "clear and sunny"),
            WeatherCondition::PartlyCloudy => write!(f, "partly cloudy"),
            WeatherCondition::Cloudy => write!(f, "cloudy"),
            WeatherCondition::Overcast => write!(f, "overcast and grey"),
            WeatherCondition::LightRain => write!(f, "lightly raining"),
            WeatherCondition::Rain => write!(f, "raining"),
            WeatherCondition::HeavyRain => write!(f, "raining heavily"),
            WeatherCondition::Thunderstorm => write!(f, "stormy with thunder"),
            WeatherCondition::LightSnow => write!(f, "lightly snowing"),
            WeatherCondition::Snow => write!(f, "snowing"),
            WeatherCondition::Blizzard => write!(f, "a blizzard"),
            WeatherCondition::Fog => write!(f, "foggy"),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TemperatureCategory {
    Freezing,   // < 0C
    Cold,       // 0-9C
    Cool,       // 10-14C
    Mild,       // 15-19C
    Warm,       // 20-24C
    Hot,        // 25-34C
    Sweltering, // >= 35C
}

impl Default for TemperatureCategory {
    fn default() -> Self {
        TemperatureCategory::Mild
    }
}

impl std::fmt::Display for TemperatureCategory {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TemperatureCategory::Freezing => write!(f, "freezing cold"),
            TemperatureCategory::Cold => write!(f, "cold"),
            TemperatureCategory::Cool => write!(f, "cool"),
            TemperatureCategory::Mild => write!(f, "mild"),
            TemperatureCategory::Warm => write!(f, "warm"),
            TemperatureCategory::Hot => write!(f, "hot"),
            TemperatureCategory::Sweltering => write!(f, "sweltering"),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GameTime {
    /// Unix timestamp when game time started (server first run)
    pub epoch_start: i64,
    /// Current game hour (0-23)
    pub hour: u8,
    /// Current game day (1-30)
    pub day: u8,
    /// Current game month (1-12)
    pub month: u8,
    /// Current game year (starting at 1)
    pub year: u32,
    /// Current weather condition
    pub weather: WeatherCondition,
    /// Base temperature in Celsius (modified by season/time/weather)
    pub base_temperature: i32,
    /// Timestamp of last weather change
    pub last_weather_change: i64,
    /// Timestamp of last time tick
    pub last_time_tick: i64,
}

impl Default for GameTime {
    fn default() -> Self {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs() as i64)
            .unwrap_or(0);
        GameTime {
            epoch_start: now,
            hour: 8,  // Start at 8 AM
            day: 1,
            month: 3, // Start in spring (Month 3)
            year: 1,
            weather: WeatherCondition::Clear,
            base_temperature: 18, // Mild spring temperature
            last_weather_change: now,
            last_time_tick: now,
        }
    }
}

impl GameTime {
    pub fn get_season(&self) -> Season {
        match self.month {
            3 | 4 | 5 => Season::Spring,
            6 | 7 | 8 => Season::Summer,
            9 | 10 | 11 => Season::Autumn,
            12 | 1 | 2 => Season::Winter,
            _ => Season::Spring,
        }
    }

    pub fn get_time_of_day(&self) -> TimeOfDay {
        match self.hour {
            5..=6 => TimeOfDay::Dawn,
            7..=11 => TimeOfDay::Morning,
            12..=13 => TimeOfDay::Noon,
            14..=16 => TimeOfDay::Afternoon,
            17..=18 => TimeOfDay::Dusk,
            19..=21 => TimeOfDay::Evening,
            _ => TimeOfDay::Night,  // 22-4
        }
    }

    pub fn get_temperature_category(&self) -> TemperatureCategory {
        let effective_temp = self.calculate_effective_temperature();
        match effective_temp {
            t if t < 0 => TemperatureCategory::Freezing,
            t if t < 10 => TemperatureCategory::Cold,
            t if t < 15 => TemperatureCategory::Cool,
            t if t < 20 => TemperatureCategory::Mild,
            t if t < 25 => TemperatureCategory::Warm,
            t if t < 35 => TemperatureCategory::Hot,
            _ => TemperatureCategory::Sweltering,
        }
    }

    pub fn calculate_effective_temperature(&self) -> i32 {
        let mut temp = self.base_temperature;

        // Season modifier
        temp += match self.get_season() {
            Season::Winter => -15,
            Season::Autumn => -5,
            Season::Spring => 0,
            Season::Summer => 10,
        };

        // Time of day modifier
        temp += match self.get_time_of_day() {
            TimeOfDay::Night => -8,
            TimeOfDay::Dawn => -5,
            TimeOfDay::Morning => -2,
            TimeOfDay::Noon => 3,
            TimeOfDay::Afternoon => 2,
            TimeOfDay::Dusk => -1,
            TimeOfDay::Evening => -4,
        };

        // Weather modifier
        temp += match self.weather {
            WeatherCondition::Clear => 2,
            WeatherCondition::PartlyCloudy => 0,
            WeatherCondition::Cloudy => -2,
            WeatherCondition::Overcast => -4,
            WeatherCondition::LightRain => -3,
            WeatherCondition::Rain => -5,
            WeatherCondition::HeavyRain => -7,
            WeatherCondition::Thunderstorm => -8,
            WeatherCondition::LightSnow => -5,
            WeatherCondition::Snow => -8,
            WeatherCondition::Blizzard => -15,
            WeatherCondition::Fog => -2,
        };

        temp
    }

    pub fn is_daytime(&self) -> bool {
        self.hour >= 6 && self.hour < 20
    }

    /// Advance time by one hour, handling day/month/year rollovers
    pub fn advance_hour(&mut self) {
        self.hour += 1;
        if self.hour >= 24 {
            self.hour = 0;
            self.day += 1;
            if self.day > GAME_DAYS_PER_MONTH as u8 {
                self.day = 1;
                self.month += 1;
                if self.month > GAME_MONTHS_PER_YEAR as u8 {
                    self.month = 1;
                    self.year += 1;
                }
            }
        }
    }
}

// === Transportation System ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TransportType {
    Elevator,
    Bus,
    Train,
    Ferry,
    Airship,
}

impl Default for TransportType {
    fn default() -> Self {
        TransportType::Elevator
    }
}

impl TransportType {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "elevator" => Some(TransportType::Elevator),
            "bus" => Some(TransportType::Bus),
            "train" => Some(TransportType::Train),
            "ferry" => Some(TransportType::Ferry),
            "airship" => Some(TransportType::Airship),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            TransportType::Elevator => "elevator",
            TransportType::Bus => "bus",
            TransportType::Train => "train",
            TransportType::Ferry => "ferry",
            TransportType::Airship => "airship",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum TransportState {
    #[default]
    Stopped,
    Moving,
}

impl TransportState {
    pub fn to_display_string(&self) -> &'static str {
        match self {
            TransportState::Stopped => "stopped",
            TransportState::Moving => "moving",
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TransportSchedule {
    OnDemand,
    GameTime {
        frequency_hours: i32,
        operating_start: u8,
        operating_end: u8,
        dwell_time_secs: i64,
    },
}

impl Default for TransportSchedule {
    fn default() -> Self {
        TransportSchedule::OnDemand
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransportStop {
    pub room_id: Uuid,
    pub name: String,
    pub exit_direction: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransportData {
    pub id: Uuid,
    #[serde(default)]
    pub vnum: Option<String>,
    pub name: String,
    #[serde(default)]
    pub transport_type: TransportType,
    pub interior_room_id: Uuid,
    #[serde(default)]
    pub stops: Vec<TransportStop>,
    #[serde(default)]
    pub current_stop_index: usize,
    #[serde(default)]
    pub state: TransportState,
    #[serde(default = "default_transport_direction")]
    pub direction: i8,
    #[serde(default)]
    pub schedule: TransportSchedule,
    #[serde(default = "default_travel_time")]
    pub travel_time_secs: i64,
    #[serde(default)]
    pub last_state_change: i64,
}

fn default_transport_direction() -> i8 {
    1
}

fn default_travel_time() -> i64 {
    30
}

impl TransportData {
    pub fn new(name: String, interior_room_id: Uuid) -> Self {
        TransportData {
            id: Uuid::new_v4(),
            vnum: None,
            name,
            transport_type: TransportType::default(),
            interior_room_id,
            stops: Vec::new(),
            current_stop_index: 0,
            state: TransportState::Stopped,
            direction: 1,
            schedule: TransportSchedule::OnDemand,
            travel_time_secs: 30,
            last_state_change: 0,
        }
    }

    /// Check if the transport is within operating hours (for GameTime schedules)
    pub fn is_within_operating_hours(&self, hour: u8) -> bool {
        match &self.schedule {
            TransportSchedule::OnDemand => true,
            TransportSchedule::GameTime { operating_start, operating_end, .. } => {
                if operating_start <= operating_end {
                    // Normal range: e.g., 6 AM to 11 PM
                    hour >= *operating_start && hour <= *operating_end
                } else {
                    // Overnight range: e.g., 11 PM to 6 AM
                    hour >= *operating_start || hour <= *operating_end
                }
            }
        }
    }

    /// Get the current stop, if any
    pub fn current_stop(&self) -> Option<&TransportStop> {
        self.stops.get(self.current_stop_index)
    }

    /// Advance to the next stop, handling direction reversal for ping-pong routes
    pub fn advance_to_next_stop(&mut self) {
        if self.stops.is_empty() {
            return;
        }

        let next_index = self.current_stop_index as i64 + self.direction as i64;

        if next_index < 0 {
            // At start, reverse direction
            self.direction = 1;
            self.current_stop_index = 1.min(self.stops.len() - 1);
        } else if next_index >= self.stops.len() as i64 {
            // At end, reverse direction
            self.direction = -1;
            self.current_stop_index = self.stops.len().saturating_sub(2);
        } else {
            self.current_stop_index = next_index as usize;
        }
    }
}

// === NPC Transport Route System ===

/// Schedule for when an NPC travels via transport
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum NPCTravelSchedule {
    /// NPC travels at fixed game hours (e.g., commuter going to work)
    FixedHours {
        depart_hour: u8,   // Hour to leave home for destination
        return_hour: u8,   // Hour to return home
    },
    /// NPC has a random chance to travel each game hour
    Random {
        chance_per_hour: i32,  // 1-100 percent chance to travel per hour
    },
    /// NPC stays on the transport permanently (e.g., conductor)
    Permanent,
}

impl Default for NPCTravelSchedule {
    fn default() -> Self {
        NPCTravelSchedule::FixedHours {
            depart_hour: 8,
            return_hour: 17,
        }
    }
}

/// Configuration for an NPC that uses transport
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TransportRoute {
    pub transport_id: Uuid,           // Which transport to use
    pub home_stop_index: usize,       // Where NPC "lives" (boards from)
    pub destination_stop_index: usize, // Where NPC travels to
    pub schedule: NPCTravelSchedule,
    #[serde(default)]
    pub is_at_destination: bool,      // Track if NPC is currently at destination
    #[serde(default)]
    pub is_on_transport: bool,        // Track if NPC is currently riding
}

impl TransportRoute {
    pub fn new(transport_id: Uuid, home_stop_index: usize, destination_stop_index: usize) -> Self {
        TransportRoute {
            transport_id,
            home_stop_index,
            destination_stop_index,
            schedule: NPCTravelSchedule::default(),
            is_at_destination: false,
            is_on_transport: false,
        }
    }
}

// === Item Trigger System ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ItemTriggerType {
    OnGet,
    OnDrop,
    OnUse,
    OnExamine,
    OnPrompt,  // Fires when building prompt for equipped items
}

impl Default for ItemTriggerType {
    fn default() -> Self {
        ItemTriggerType::OnGet
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ItemTrigger {
    pub trigger_type: ItemTriggerType,
    pub script_name: String,      // e.g., "cursed_item" or "@say_greeting" for templates
    pub enabled: bool,
    #[serde(default = "default_trigger_chance")]
    pub chance: i32,              // 1-100 percent (100 = always)
    #[serde(default)]
    pub args: Vec<String>,        // Template arguments
}

impl Default for ItemTrigger {
    fn default() -> Self {
        ItemTrigger {
            trigger_type: ItemTriggerType::OnGet,
            script_name: String::new(),
            enabled: true,
            chance: 100,
            args: Vec::new(),
        }
    }
}

// === Mobile/NPC Trigger System ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MobileTriggerType {
    OnGreet,    // Player enters room with NPC
    OnAttack,   // NPC is attacked
    OnDeath,    // NPC dies
    OnSay,      // Player says something in room (for advanced dialogue)
    OnIdle,     // Periodic when players present in room
}

impl Default for MobileTriggerType {
    fn default() -> Self {
        MobileTriggerType::OnGreet
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MobileTrigger {
    pub trigger_type: MobileTriggerType,
    pub script_name: String,      // e.g., "guard_greet" or "@say_greeting" for templates
    pub enabled: bool,
    #[serde(default = "default_trigger_chance")]
    pub chance: i32,              // 1-100 percent (100 = always)
    #[serde(default)]
    pub args: Vec<String>,        // Template arguments (e.g., greeting message)
    #[serde(default = "default_trigger_interval")]
    pub interval_secs: i64,       // For OnIdle triggers (default 60)
    #[serde(default)]
    pub last_fired: i64,          // Unix timestamp of last execution
}

impl Default for MobileTrigger {
    fn default() -> Self {
        MobileTrigger {
            trigger_type: MobileTriggerType::OnGreet,
            script_name: String::new(),
            enabled: true,
            chance: 100,
            args: Vec::new(),
            interval_secs: 60,
            last_fired: 0,
        }
    }
}

// === Area Flags System ===

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct AreaFlags {
    /// Area-wide climate control - rooms inherit unless they override
    #[serde(default)]
    pub climate_controlled: bool,
}

// === Area Permission System ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum AreaPermission {
    /// Only the owner can edit (strictest)
    OwnerOnly,
    /// Owner + trusted builders can edit
    Trusted,
    /// Any builder can edit (default, backwards compatible)
    #[default]
    AllBuilders,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AreaData {
    pub id: Uuid,
    pub name: String,
    pub prefix: String,
    #[serde(default)]
    pub description: String,
    #[serde(default)]
    pub level_min: i32,
    #[serde(default)]
    pub level_max: i32,
    #[serde(default)]
    pub theme: String,
    /// Owner character name (None = no owner, any builder can edit)
    #[serde(default)]
    pub owner: Option<String>,
    /// Permission level for the area
    #[serde(default)]
    pub permission_level: AreaPermission,
    /// List of trusted builder names (used when permission_level = Trusted)
    #[serde(default)]
    pub trusted_builders: Vec<String>,
    /// Forageable items in city rooms (rooms with city flag)
    #[serde(default)]
    pub city_forage_table: Vec<ForageEntry>,
    /// Forageable items in wilderness rooms (rooms with dirt_floor flag)
    #[serde(default)]
    pub wilderness_forage_table: Vec<ForageEntry>,
    /// Combat zone type (PvE/Safe/PvP) - area default, can be overridden at room level
    #[serde(default)]
    pub combat_zone: CombatZoneType,
    /// Area-wide flags that rooms can inherit
    #[serde(default)]
    pub flags: AreaFlags,
}

// === Spawn Point System ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SpawnEntityType {
    Mobile,
    Item,
}

/// Destination for spawned items in spawn dependencies
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SpawnDestination {
    /// Item goes in mobile's inventory
    Inventory,
    /// Item is worn by mobile at specified location
    Equipped(WearLocation),
    /// Item goes inside spawned container (for item spawn points)
    Container,
}

/// Defines an item to spawn along with the main entity
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpawnDependency {
    pub item_vnum: String,
    pub destination: SpawnDestination,
    #[serde(default = "default_spawn_count")]
    pub count: i32,
}

fn default_spawn_count() -> i32 { 1 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpawnPointData {
    pub id: Uuid,
    pub area_id: Uuid,
    pub room_id: Uuid,
    pub entity_type: SpawnEntityType,
    pub vnum: String,
    pub max_count: i32,
    pub respawn_interval_secs: i64,
    pub enabled: bool,
    #[serde(default)]
    pub last_spawn_time: i64,
    #[serde(default)]
    pub spawned_entities: Vec<Uuid>,
    /// Item dependencies to spawn alongside the main entity
    #[serde(default)]
    pub dependencies: Vec<SpawnDependency>,
}

// === Item System ===

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WearLocation {
    // Single slots
    Head,
    Neck,
    Shoulders,
    Back,
    Torso,
    Waist,
    Ears,
    Wielded,
    OffHand,
    // Left/Right arm slots
    LeftArm,
    RightArm,
    WristLeft,
    WristRight,
    // Left/Right hand slots
    LeftHand,
    RightHand,
    FingerLeft,
    FingerRight,
    // Left/Right leg slots
    LeftLeg,
    RightLeg,
    LeftAnkle,
    RightAnkle,
    // Left/Right foot slots
    LeftFoot,
    RightFoot,
    // DEPRECATED - kept for data migration
    #[serde(rename = "arms")]
    Arms,
    #[serde(rename = "hands")]
    Hands,
    #[serde(rename = "legs")]
    Legs,
    #[serde(rename = "ankles")]
    Ankles,
    #[serde(rename = "feet")]
    Feet,
    #[serde(rename = "wrists")]
    Wrists,
}

impl WearLocation {
    pub fn from_str(s: &str) -> Option<WearLocation> {
        match s.to_lowercase().replace([' ', '_', '-'], "").as_str() {
            // Single slots
            "head" => Some(WearLocation::Head),
            "neck" => Some(WearLocation::Neck),
            "shoulders" => Some(WearLocation::Shoulders),
            "back" => Some(WearLocation::Back),
            "torso" => Some(WearLocation::Torso),
            "waist" => Some(WearLocation::Waist),
            "ears" => Some(WearLocation::Ears),
            "wielded" => Some(WearLocation::Wielded),
            "offhand" => Some(WearLocation::OffHand),
            // Left/Right arm
            "leftarm" | "larm" => Some(WearLocation::LeftArm),
            "rightarm" | "rarm" => Some(WearLocation::RightArm),
            "leftwrist" | "wristleft" | "lwrist" => Some(WearLocation::WristLeft),
            "rightwrist" | "wristright" | "rwrist" => Some(WearLocation::WristRight),
            // Left/Right hand
            "lefthand" | "lhand" => Some(WearLocation::LeftHand),
            "righthand" | "rhand" => Some(WearLocation::RightHand),
            "leftfinger" | "fingerleft" | "lfinger" => Some(WearLocation::FingerLeft),
            "rightfinger" | "fingerright" | "rfinger" => Some(WearLocation::FingerRight),
            // Left/Right leg
            "leftleg" | "lleg" => Some(WearLocation::LeftLeg),
            "rightleg" | "rleg" => Some(WearLocation::RightLeg),
            "leftankle" | "lankle" => Some(WearLocation::LeftAnkle),
            "rightankle" | "rankle" => Some(WearLocation::RightAnkle),
            // Left/Right foot
            "leftfoot" | "lfoot" => Some(WearLocation::LeftFoot),
            "rightfoot" | "rfoot" => Some(WearLocation::RightFoot),
            // Deprecated (map to L+R for backward compat)
            "arms" => Some(WearLocation::Arms),
            "hands" => Some(WearLocation::Hands),
            "legs" => Some(WearLocation::Legs),
            "ankles" => Some(WearLocation::Ankles),
            "feet" => Some(WearLocation::Feet),
            "wrists" => Some(WearLocation::Wrists),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            // Single slots
            WearLocation::Head => "head",
            WearLocation::Neck => "neck",
            WearLocation::Shoulders => "shoulders",
            WearLocation::Back => "back",
            WearLocation::Torso => "torso",
            WearLocation::Waist => "waist",
            WearLocation::Ears => "ears",
            WearLocation::Wielded => "wielded",
            WearLocation::OffHand => "off-hand",
            // Left/Right arm
            WearLocation::LeftArm => "left arm",
            WearLocation::RightArm => "right arm",
            WearLocation::WristLeft => "left wrist",
            WearLocation::WristRight => "right wrist",
            // Left/Right hand
            WearLocation::LeftHand => "left hand",
            WearLocation::RightHand => "right hand",
            WearLocation::FingerLeft => "left finger",
            WearLocation::FingerRight => "right finger",
            // Left/Right leg
            WearLocation::LeftLeg => "left leg",
            WearLocation::RightLeg => "right leg",
            WearLocation::LeftAnkle => "left ankle",
            WearLocation::RightAnkle => "right ankle",
            // Left/Right foot
            WearLocation::LeftFoot => "left foot",
            WearLocation::RightFoot => "right foot",
            // Deprecated
            WearLocation::Arms => "arms",
            WearLocation::Hands => "hands",
            WearLocation::Legs => "legs",
            WearLocation::Ankles => "ankles",
            WearLocation::Feet => "feet",
            WearLocation::Wrists => "wrists",
        }
    }

    /// Returns all active (non-deprecated) wear locations
    pub fn all() -> Vec<WearLocation> {
        vec![
            WearLocation::Head,
            WearLocation::Neck,
            WearLocation::Shoulders,
            WearLocation::Back,
            WearLocation::Torso,
            WearLocation::Waist,
            WearLocation::Ears,
            WearLocation::Wielded,
            WearLocation::OffHand,
            WearLocation::LeftArm,
            WearLocation::RightArm,
            WearLocation::WristLeft,
            WearLocation::WristRight,
            WearLocation::LeftHand,
            WearLocation::RightHand,
            WearLocation::FingerLeft,
            WearLocation::FingerRight,
            WearLocation::LeftLeg,
            WearLocation::RightLeg,
            WearLocation::LeftAnkle,
            WearLocation::RightAnkle,
            WearLocation::LeftFoot,
            WearLocation::RightFoot,
        ]
    }

    /// Returns true if this is a deprecated wear location
    pub fn is_deprecated(&self) -> bool {
        matches!(
            self,
            WearLocation::Arms
                | WearLocation::Hands
                | WearLocation::Legs
                | WearLocation::Ankles
                | WearLocation::Feet
                | WearLocation::Wrists
        )
    }

    /// For deprecated locations, returns the L/R equivalents
    pub fn to_lr_equivalents(&self) -> Vec<WearLocation> {
        match self {
            WearLocation::Arms => vec![WearLocation::LeftArm, WearLocation::RightArm],
            WearLocation::Hands => vec![WearLocation::LeftHand, WearLocation::RightHand],
            WearLocation::Legs => vec![WearLocation::LeftLeg, WearLocation::RightLeg],
            WearLocation::Ankles => vec![WearLocation::LeftAnkle, WearLocation::RightAnkle],
            WearLocation::Feet => vec![WearLocation::LeftFoot, WearLocation::RightFoot],
            WearLocation::Wrists => vec![WearLocation::WristLeft, WearLocation::WristRight],
            _ => vec![*self],
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum ItemType {
    #[default]
    Misc,
    Armor,
    Weapon,
    Container,
    LiquidContainer,
    Food,
    Key,
    Gold,
}

impl ItemType {
    pub fn from_str(s: &str) -> Option<ItemType> {
        match s.to_lowercase().as_str() {
            "misc" => Some(ItemType::Misc),
            "armor" => Some(ItemType::Armor),
            "weapon" => Some(ItemType::Weapon),
            "container" => Some(ItemType::Container),
            "liquid_container" | "liquidcontainer" | "drink" | "drinkcon" => Some(ItemType::LiquidContainer),
            "food" => Some(ItemType::Food),
            "key" => Some(ItemType::Key),
            "gold" => Some(ItemType::Gold),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            ItemType::Misc => "misc",
            ItemType::Armor => "armor",
            ItemType::Weapon => "weapon",
            ItemType::Container => "container",
            ItemType::LiquidContainer => "liquid_container",
            ItemType::Food => "food",
            ItemType::Key => "key",
            ItemType::Gold => "gold",
        }
    }
}

/// Returns the tier description for a gold amount
pub fn get_gold_tier_description(amount: i32) -> &'static str {
    match amount {
        1..=10 => "a few coins",
        11..=50 => "some gold",
        51..=200 => "a pile of gold",
        201..=1000 => "a large pile of gold",
        _ if amount > 1000 => "a fortune in gold",
        _ => "some gold", // fallback for 0 or negative
    }
}

/// Returns the short description for gold (shown in room listings)
pub fn get_gold_short_desc(amount: i32) -> String {
    let tier = get_gold_tier_description(amount);
    // Capitalize first letter
    let mut chars = tier.chars();
    match chars.next() {
        None => String::new(),
        Some(first) => first.to_uppercase().collect::<String>() + chars.as_str() + " lies here.",
    }
}

/// Returns the long description for gold (shown when examined)
pub fn get_gold_long_desc(amount: i32) -> String {
    match amount {
        1..=10 => format!("A small scattering of {} gold coins glints in the light.", amount),
        11..=50 => format!("A modest collection of {} gold coins is piled here.", amount),
        51..=200 => format!("An enticing pile of {} gold coins awaits collection.", amount),
        201..=1000 => format!("A large heap of {} gold coins gleams invitingly.", amount),
        _ => format!("An absolutely staggering fortune of {} gold coins fills the area.", amount),
    }
}

/// Creates a new gold item with the specified amount
pub fn create_gold_item(amount: i32) -> ItemData {
    let tier = get_gold_tier_description(amount);
    let mut item = ItemData::new(
        tier.to_string(),
        get_gold_short_desc(amount),
        get_gold_long_desc(amount),
    );
    item.item_type = ItemType::Gold;
    item.value = amount;
    item.keywords = vec!["gold".to_string(), "coins".to_string(), "coin".to_string()];
    item.weight = (amount / 100).max(1);
    item
}

/// Updates gold item descriptions after the amount changes (e.g., after merging)
pub fn update_gold_descriptions(item: &mut ItemData) {
    if item.item_type == ItemType::Gold {
        item.name = get_gold_tier_description(item.value).to_string();
        item.short_desc = get_gold_short_desc(item.value);
        item.long_desc = get_gold_long_desc(item.value);
        item.weight = (item.value / 100).max(1);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum DamageType {
    #[default]
    Bludgeoning,
    Slashing,
    Piercing,
    Fire,
    Cold,
    Lightning,
    Poison,
    Acid,
}

impl DamageType {
    pub fn from_str(s: &str) -> Option<DamageType> {
        match s.to_lowercase().as_str() {
            "bludgeoning" | "bludgeon" => Some(DamageType::Bludgeoning),
            "slashing" | "slash" => Some(DamageType::Slashing),
            "piercing" | "pierce" => Some(DamageType::Piercing),
            "fire" => Some(DamageType::Fire),
            "cold" => Some(DamageType::Cold),
            "lightning" => Some(DamageType::Lightning),
            "poison" => Some(DamageType::Poison),
            "acid" => Some(DamageType::Acid),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            DamageType::Bludgeoning => "bludgeoning",
            DamageType::Slashing => "slashing",
            DamageType::Piercing => "piercing",
            DamageType::Fire => "fire",
            DamageType::Cold => "cold",
            DamageType::Lightning => "lightning",
            DamageType::Poison => "poison",
            DamageType::Acid => "acid",
        }
    }

    pub fn all() -> Vec<&'static str> {
        vec!["bludgeoning", "slashing", "piercing", "fire", "cold", "lightning", "poison", "acid"]
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum EffectType {
    #[default]
    None,
    Heal,
    Poison,
    ManaRestore,
    StaminaRestore,
    StrengthBoost,
    DexterityBoost,
    ConstitutionBoost,
    IntelligenceBoost,
    WisdomBoost,
    CharismaBoost,
    Haste,
    Slow,
    Invisibility,
    DetectInvisible,
    Regeneration,
    Drunk,
    Satiated,
    Quenched,
}

impl EffectType {
    pub fn from_str(s: &str) -> Option<EffectType> {
        match s.to_lowercase().as_str() {
            "none" => Some(EffectType::None),
            "heal" => Some(EffectType::Heal),
            "poison" => Some(EffectType::Poison),
            "mana_restore" | "manarestore" | "mana" => Some(EffectType::ManaRestore),
            "stamina_restore" | "staminarestore" | "stamina" => Some(EffectType::StaminaRestore),
            "strength_boost" | "strengthboost" | "str_boost" | "strength" => Some(EffectType::StrengthBoost),
            "dexterity_boost" | "dexterityboost" | "dex_boost" | "dexterity" => Some(EffectType::DexterityBoost),
            "constitution_boost" | "constitutionboost" | "con_boost" | "constitution" => Some(EffectType::ConstitutionBoost),
            "intelligence_boost" | "intelligenceboost" | "int_boost" | "intelligence" => Some(EffectType::IntelligenceBoost),
            "wisdom_boost" | "wisdomboost" | "wis_boost" | "wisdom" => Some(EffectType::WisdomBoost),
            "charisma_boost" | "charismaboost" | "cha_boost" | "charisma" => Some(EffectType::CharismaBoost),
            "haste" => Some(EffectType::Haste),
            "slow" => Some(EffectType::Slow),
            "invisibility" | "invis" => Some(EffectType::Invisibility),
            "detect_invisible" | "detectinvisible" | "detect_invis" => Some(EffectType::DetectInvisible),
            "regeneration" | "regen" => Some(EffectType::Regeneration),
            "drunk" => Some(EffectType::Drunk),
            "satiated" => Some(EffectType::Satiated),
            "quenched" => Some(EffectType::Quenched),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            EffectType::None => "none",
            EffectType::Heal => "heal",
            EffectType::Poison => "poison",
            EffectType::ManaRestore => "mana_restore",
            EffectType::StaminaRestore => "stamina_restore",
            EffectType::StrengthBoost => "strength_boost",
            EffectType::DexterityBoost => "dexterity_boost",
            EffectType::ConstitutionBoost => "constitution_boost",
            EffectType::IntelligenceBoost => "intelligence_boost",
            EffectType::WisdomBoost => "wisdom_boost",
            EffectType::CharismaBoost => "charisma_boost",
            EffectType::Haste => "haste",
            EffectType::Slow => "slow",
            EffectType::Invisibility => "invisibility",
            EffectType::DetectInvisible => "detect_invisible",
            EffectType::Regeneration => "regeneration",
            EffectType::Drunk => "drunk",
            EffectType::Satiated => "satiated",
            EffectType::Quenched => "quenched",
        }
    }

    pub fn all() -> Vec<&'static str> {
        vec![
            "none", "heal", "poison", "mana_restore", "stamina_restore",
            "strength_boost", "dexterity_boost", "constitution_boost",
            "intelligence_boost", "wisdom_boost", "charisma_boost",
            "haste", "slow", "invisibility", "detect_invisible",
            "regeneration", "drunk", "satiated", "quenched",
        ]
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum LiquidType {
    #[default]
    Water,
    Ale,
    Wine,
    Beer,
    Alcohol,
    Milk,
    Juice,
    Tea,
    Coffee,
    Poison,
    HealingPotion,
    ManaPotion,
    Blood,
    Oil,
}

impl LiquidType {
    pub fn from_str(s: &str) -> Option<LiquidType> {
        match s.to_lowercase().as_str() {
            "water" => Some(LiquidType::Water),
            "ale" => Some(LiquidType::Ale),
            "wine" => Some(LiquidType::Wine),
            "beer" | "mead" => Some(LiquidType::Beer),
            "alcohol" => Some(LiquidType::Alcohol),
            "milk" => Some(LiquidType::Milk),
            "juice" => Some(LiquidType::Juice),
            "tea" => Some(LiquidType::Tea),
            "coffee" => Some(LiquidType::Coffee),
            "poison" => Some(LiquidType::Poison),
            "healing_potion" | "healingpotion" | "heal_potion" => Some(LiquidType::HealingPotion),
            "mana_potion" | "manapotion" => Some(LiquidType::ManaPotion),
            "blood" => Some(LiquidType::Blood),
            "oil" => Some(LiquidType::Oil),
            _ => None,
        }
    }

    pub fn to_display_string(&self) -> &'static str {
        match self {
            LiquidType::Water => "water",
            LiquidType::Ale => "ale",
            LiquidType::Wine => "wine",
            LiquidType::Beer => "beer",
            LiquidType::Alcohol => "alcohol",
            LiquidType::Milk => "milk",
            LiquidType::Juice => "juice",
            LiquidType::Tea => "tea",
            LiquidType::Coffee => "coffee",
            LiquidType::Poison => "poison",
            LiquidType::HealingPotion => "healing_potion",
            LiquidType::ManaPotion => "mana_potion",
            LiquidType::Blood => "blood",
            LiquidType::Oil => "oil",
        }
    }

    pub fn all() -> Vec<&'static str> {
        vec![
            "water", "ale", "wine", "beer", "alcohol", "milk", "juice", "tea",
            "coffee", "poison", "healing_potion", "mana_potion", "blood", "oil",
        ]
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ItemEffect {
    pub effect_type: EffectType,
    pub magnitude: i32,
    pub duration: i32,  // seconds, 0 = instant
    #[serde(default)]
    pub script_callback: Option<String>,
}

impl Default for ItemEffect {
    fn default() -> Self {
        ItemEffect {
            effect_type: EffectType::None,
            magnitude: 0,
            duration: 0,
            script_callback: None,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ItemFlags {
    #[serde(default)]
    pub no_drop: bool,
    #[serde(default)]
    pub no_get: bool,
    #[serde(default)]
    pub no_remove: bool,
    #[serde(default)]
    pub invisible: bool,
    #[serde(default)]
    pub glow: bool,
    #[serde(default)]
    pub hum: bool,
    #[serde(default)]
    pub no_sell: bool,
    #[serde(default)]
    pub unique: bool,
    #[serde(default)]
    pub quest_item: bool,
    #[serde(default)]
    pub vending: bool,          // Functions as a vending machine
    #[serde(default)]
    pub provides_light: bool,   // Provides light when equipped/wielded
    #[serde(default)]
    pub fishing_rod: bool,      // Can be used for fishing when held
    #[serde(default)]
    pub bait: bool,             // Can be used as fishing bait
    #[serde(default)]
    pub foraging_tool: bool,    // Can be used as foraging tool (uses quality for bonus)
    #[serde(default)]
    pub waterproof: bool,       // Protects from rain/water when worn
    #[serde(default)]
    pub provides_warmth: bool,  // Radiates warmth to room (campfire, fireplace)
    #[serde(default)]
    pub medical_tool: bool,     // Can be used for medical treatment
    // Corpse system fields
    #[serde(default)]
    pub is_corpse: bool,        // This item is a corpse container
    #[serde(default)]
    pub corpse_owner: String,   // Name of the dead character/mobile
    #[serde(default)]
    pub corpse_created_at: i64, // Unix timestamp when corpse was created
    #[serde(default)]
    pub corpse_is_player: bool, // true = 1hr decay, false = 10min decay
    #[serde(default)]
    pub corpse_gold: i64,       // Gold carried by the corpse
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
#[serde(tag = "type", content = "id")]
pub enum ItemLocation {
    #[default]
    Nowhere,
    Room(Uuid),
    Inventory(String),
    Equipped(String),
    Container(Uuid),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ItemData {
    pub id: Uuid,
    pub name: String,
    pub short_desc: String,
    pub long_desc: String,
    #[serde(default)]
    pub keywords: Vec<String>,
    #[serde(default)]
    pub item_type: ItemType,
    // Category for recipe ingredient/tool matching (e.g., "flour", "meat", "forge")
    #[serde(default)]
    pub category: Option<String>,
    // Recipe ID this item teaches when read/used (for recipe books/scrolls)
    #[serde(default)]
    pub teaches_recipe: Option<String>,
    #[serde(default)]
    pub wear_locations: Vec<WearLocation>,
    #[serde(default)]
    pub armor_class: Option<i32>,
    /// Body parts this armor protects (for armor items)
    #[serde(default)]
    pub protects: Vec<BodyPart>,
    #[serde(default)]
    pub flags: ItemFlags,
    #[serde(default)]
    pub weight: i32,
    #[serde(default)]
    pub value: i32,
    #[serde(default)]
    pub location: ItemLocation,
    // Weapon fields
    #[serde(default)]
    pub damage_dice_count: i32,
    #[serde(default)]
    pub damage_dice_sides: i32,
    #[serde(default)]
    pub damage_type: DamageType,
    #[serde(default)]
    pub two_handed: bool,
    /// Weapon skill used by this weapon (for combat XP)
    #[serde(default)]
    pub weapon_skill: Option<WeaponSkill>,
    // Container fields (ItemType::Container)
    #[serde(default)]
    pub container_contents: Vec<Uuid>,
    #[serde(default)]
    pub container_max_items: i32,
    #[serde(default)]
    pub container_max_weight: i32,
    #[serde(default)]
    pub container_closed: bool,
    #[serde(default)]
    pub container_locked: bool,
    #[serde(default)]
    pub container_key_id: Option<Uuid>,
    // Weight reduction when worn (0-100 percent, e.g., 50 = contents weigh 50% when worn)
    #[serde(default)]
    pub weight_reduction: i32,
    // Liquid Container fields (ItemType::LiquidContainer)
    #[serde(default)]
    pub liquid_type: LiquidType,
    #[serde(default)]
    pub liquid_current: i32,
    #[serde(default)]
    pub liquid_max: i32,
    #[serde(default)]
    pub liquid_poisoned: bool,
    #[serde(default)]
    pub liquid_effects: Vec<ItemEffect>,
    // Food fields (ItemType::Food)
    #[serde(default)]
    pub food_nutrition: i32,
    #[serde(default)]
    pub food_poisoned: bool,
    #[serde(default)]
    pub food_spoil_duration: i64,
    #[serde(default)]
    pub food_created_at: Option<i64>,
    #[serde(default)]
    pub food_effects: Vec<ItemEffect>,
    // Level requirement and stat bonuses
    #[serde(default)]
    pub level_requirement: i32,
    #[serde(default)]
    pub stat_str: i32,
    #[serde(default)]
    pub stat_dex: i32,
    #[serde(default)]
    pub stat_con: i32,
    #[serde(default)]
    pub stat_int: i32,
    #[serde(default)]
    pub stat_wis: i32,
    #[serde(default)]
    pub stat_cha: i32,
    // Insulation for temperature/weather system
    #[serde(default)]
    pub insulation: i32,  // 0-100 scale for warmth
    // Prototype fields
    #[serde(default)]
    pub is_prototype: bool,
    #[serde(default)]
    pub vnum: Option<String>,
    // Item triggers
    #[serde(default)]
    pub triggers: Vec<ItemTrigger>,
    // Vending machine fields (requires flags.vending = true)
    #[serde(default)]
    pub vending_stock: Vec<String>,      // Vnums for infinite stock
    #[serde(default = "default_vending_sell_rate")]
    pub vending_sell_rate: i32,          // % charged when selling (default 150)
    // Generic quality field (0-100, used by fishing rods, bait, etc.)
    #[serde(default)]
    pub quality: i32,
    // Bait-specific fields (requires flags.bait = true)
    #[serde(default)]
    pub bait_uses: i32,                  // Uses remaining (0 = infinite)
    // Combat system - armor degradation
    /// Armor holes from combat damage (0-3, destroyed at 3)
    #[serde(default)]
    pub holes: i32,
    // Medical tool fields (requires flags.medical_tool = true)
    #[serde(default)]
    pub medical_tier: i32,              // 1=basic, 2=intermediate, 3=advanced
    #[serde(default)]
    pub medical_uses: i32,              // 0 = reusable, >0 = consumable uses
    #[serde(default)]
    pub treats_wound_types: Vec<String>, // ["cut", "puncture", "burn", etc.]
    #[serde(default)]
    pub max_treatable_wound: String,    // "minor", "moderate", "severe", "critical"
    // Transport sign - links to a TransportData to show status when read
    #[serde(default)]
    pub transport_link: Option<Uuid>,
}

impl ItemData {
    pub fn new(name: String, short_desc: String, long_desc: String) -> Self {
        ItemData {
            id: Uuid::new_v4(),
            name,
            short_desc,
            long_desc,
            keywords: Vec::new(),
            item_type: ItemType::Misc,
            category: None,
            teaches_recipe: None,
            wear_locations: Vec::new(),
            armor_class: None,
            protects: Vec::new(),
            holes: 0,
            flags: ItemFlags::default(),
            weight: 0,
            value: 0,
            location: ItemLocation::Nowhere,
            damage_dice_count: 0,
            damage_dice_sides: 0,
            damage_type: DamageType::default(),
            two_handed: false,
            weapon_skill: None,
            // Container fields
            container_contents: Vec::new(),
            container_max_items: 0,
            container_max_weight: 0,
            container_closed: false,
            container_locked: false,
            container_key_id: None,
            weight_reduction: 0,
            // Liquid container fields
            liquid_type: LiquidType::default(),
            liquid_current: 0,
            liquid_max: 0,
            liquid_poisoned: false,
            liquid_effects: Vec::new(),
            // Food fields
            food_nutrition: 0,
            food_poisoned: false,
            food_spoil_duration: 0,
            food_created_at: None,
            food_effects: Vec::new(),
            level_requirement: 0,
            stat_str: 0,
            stat_dex: 0,
            stat_con: 0,
            stat_int: 0,
            stat_wis: 0,
            stat_cha: 0,
            insulation: 0,
            is_prototype: false,
            vnum: None,
            triggers: Vec::new(),
            // Vending machine fields
            vending_stock: Vec::new(),
            vending_sell_rate: 150,
            // Quality and bait fields
            quality: 0,
            bait_uses: 0,
            // Medical tool fields
            medical_tier: 0,
            medical_uses: 0,
            treats_wound_types: Vec::new(),
            max_treatable_wound: String::new(),
            // Transport sign
            transport_link: None,
        }
    }
}

// === Mobile/NPC System ===

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct MobileFlags {
    #[serde(default)]
    pub aggressive: bool,    // Attacks players on sight (future)
    #[serde(default)]
    pub sentinel: bool,      // Never wanders from spawn room
    #[serde(default)]
    pub scavenger: bool,     // Picks up items from ground (future)
    #[serde(default)]
    pub shopkeeper: bool,    // Can buy/sell items
    #[serde(default)]
    pub no_attack: bool,     // Cannot be attacked
    #[serde(default)]
    pub healer: bool,        // Can provide healing services
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MobileData {
    // Identity
    pub id: Uuid,
    pub name: String,           // "a goblin guard"
    pub short_desc: String,     // "A goblin guard stands here."
    pub long_desc: String,      // Full description
    #[serde(default)]
    pub keywords: Vec<String>,  // ["goblin", "guard"]

    // Location
    #[serde(default)]
    pub current_room_id: Option<Uuid>,

    // Prototype system (same as items)
    #[serde(default)]
    pub is_prototype: bool,
    #[serde(default)]
    pub vnum: String,           // "goblin_guard"

    // Base stats (for future combat)
    #[serde(default)]
    pub level: i32,
    #[serde(default = "default_mobile_hp")]
    pub max_hp: i32,
    #[serde(default = "default_mobile_hp")]
    pub current_hp: i32,
    #[serde(default = "default_mobile_stamina")]
    pub max_stamina: i32,
    #[serde(default = "default_mobile_stamina")]
    pub current_stamina: i32,
    #[serde(default)]
    pub damage_dice: String,    // "2d6+3"
    #[serde(default)]
    pub damage_type: DamageType,
    #[serde(default)]
    pub armor_class: i32,

    // Attributes
    #[serde(default = "default_stat")]
    pub stat_str: i32,
    #[serde(default = "default_stat")]
    pub stat_dex: i32,
    #[serde(default = "default_stat")]
    pub stat_con: i32,
    #[serde(default = "default_stat")]
    pub stat_int: i32,
    #[serde(default = "default_stat")]
    pub stat_wis: i32,
    #[serde(default = "default_stat")]
    pub stat_cha: i32,

    // AI/Behavior flags
    #[serde(default)]
    pub flags: MobileFlags,

    // Simple dialogue (keyword -> response)
    #[serde(default)]
    pub dialogue: HashMap<String, String>,

    // Shop system (requires shopkeeper flag)
    #[serde(default)]
    pub shop_stock: Vec<String>,        // Vnums for infinite base stock
    #[serde(default)]
    pub shop_inventory: Vec<Uuid>,      // Items bought from players (finite)
    #[serde(default = "default_shop_buy_rate")]
    pub shop_buy_rate: i32,             // % paid when buying from player (e.g., 50)
    #[serde(default = "default_shop_sell_rate")]
    pub shop_sell_rate: i32,            // % charged when selling (e.g., 150)
    #[serde(default = "default_shop_buys_types")]
    pub shop_buys_types: Vec<String>,   // Item types this shop buys ("all" = any, empty = none)

    // Healer system (requires healer flag)
    #[serde(default)]
    pub healer_type: String,             // "medic", "herbalist", "cleric"
    #[serde(default)]
    pub healing_free: bool,              // Free healing or charges gold?
    #[serde(default = "default_healing_cost_multiplier")]
    pub healing_cost_multiplier: i32,    // 100 = base price, 200 = 2x, etc.

    // Trigger system
    #[serde(default)]
    pub triggers: Vec<MobileTrigger>,

    // Transport route (for NPCs that travel)
    #[serde(default)]
    pub transport_route: Option<TransportRoute>,

    // Combat system
    #[serde(default)]
    pub combat: CombatState,
    #[serde(default)]
    pub wounds: Vec<Wound>,
    // Death/unconscious state (not persisted)
    #[serde(skip)]
    pub is_unconscious: bool,
    #[serde(skip)]
    pub bleedout_rounds_remaining: i32,
}

fn default_mobile_hp() -> i32 {
    10
}

fn default_mobile_stamina() -> i32 {
    50
}

fn default_shop_buy_rate() -> i32 {
    50
}

fn default_shop_sell_rate() -> i32 {
    150
}

fn default_shop_buys_types() -> Vec<String> {
    vec!["all".to_string()]
}

fn default_healing_cost_multiplier() -> i32 {
    100  // Base price, no markup
}

fn default_vending_sell_rate() -> i32 {
    150
}

impl MobileData {
    pub fn new(name: String) -> Self {
        MobileData {
            id: Uuid::new_v4(),
            name: name.clone(),
            short_desc: format!("{} is here.", name),
            long_desc: String::new(),
            keywords: Vec::new(),
            current_room_id: None,
            is_prototype: true,
            vnum: String::new(),
            level: 1,
            max_hp: 10,
            current_hp: 10,
            max_stamina: 50,
            current_stamina: 50,
            damage_dice: "1d4".to_string(),
            damage_type: DamageType::default(),
            armor_class: 10,
            stat_str: 10,
            stat_dex: 10,
            stat_con: 10,
            stat_int: 10,
            stat_wis: 10,
            stat_cha: 10,
            flags: MobileFlags::default(),
            dialogue: HashMap::new(),
            shop_stock: Vec::new(),
            shop_inventory: Vec::new(),
            shop_buy_rate: 50,
            shop_sell_rate: 150,
            shop_buys_types: vec!["all".to_string()],
            healer_type: String::new(),
            healing_free: false,
            healing_cost_multiplier: 100,
            triggers: Vec::new(),
            transport_route: None,
            combat: CombatState::default(),
            wounds: Vec::new(),
            // Death/unconscious state (not persisted)
            is_unconscious: false,
            bleedout_rounds_remaining: 0,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CommandMeta {
    pub access: String,      // "guest", "any", "user", "admin"
    pub description: String,
}

pub type ConnectionId = Uuid;

/// State for an active fishing session
#[derive(Debug, Clone)]
pub struct FishingState {
    pub started_at: i64,            // When cast started (unix timestamp)
    pub bite_time: i64,             // When fish will bite (unix timestamp)
    pub rod_item_id: Uuid,          // The fishing rod being used
    pub bait_item_id: Option<Uuid>, // Optional bait being used
    pub room_id: Uuid,              // Room where fishing started
    pub bite_notified: bool,        // Whether bite notification was sent
    pub warning_notified: bool,     // Whether warning notification was sent
}

pub struct PlayerSession {
    pub character: Option<CharacterData>,
    pub sender: mpsc::UnboundedSender<String>,
    pub addr: std::net::SocketAddr,
    // OLC (Online Creation) fields
    pub olc_mode: Option<String>,
    pub olc_buffer: Vec<String>,
    pub olc_edit_room: Option<Uuid>,
    pub olc_extra_keywords: Vec<String>,
    pub olc_undo_buffer: Option<Vec<String>>,
    // Character creation wizard state (JSON-serialized)
    pub wizard_data: Option<String>,
    // MXP (MUD eXtension Protocol) support
    pub mxp_enabled: bool,
    // ANSI color support
    pub colors_enabled: bool,
    // Builder mode: show room flags/vnum in room display
    pub show_room_flags: bool,
    // Telnet protocol state for tab completion
    pub telnet_state: telnet::TelnetState,
    pub input_buffer: String,
    pub cursor_pos: usize,
    // Readline-like input handling
    pub command_history: VecDeque<String>,
    pub history_index: Option<usize>,  // None = editing new line, Some(n) = viewing history[n]
    pub saved_input: String,           // Saved current input when navigating history
    pub escape_state: telnet::EscapeState,  // State for multi-byte escape sequences
    // AI integration fields (Claude or Gemini)
    pub pending_ai_request: Option<Uuid>,
    pub pending_ai_response: Option<claude::AiResponse>,
    pub pending_ai_target: Option<claude::AiDescriptionTarget>,
    // Fishing state
    pub fishing_state: Option<FishingState>,
    // AFK (Away From Keyboard) status
    pub afk: bool,
    // Idle tracking (unix timestamp of last activity)
    pub last_activity_time: i64,
}

/// Input events from the read handler
#[derive(Debug, Clone)]
pub enum InputEvent {
    /// Complete line (Enter pressed)
    Line(String),
    /// Tab key pressed for completion
    Tab,
    /// Raw bytes for fallback line mode (client doesn't support char mode)
    RawLine(String),
}

pub type SharedConnections = Arc<Mutex<HashMap<ConnectionId, PlayerSession>>>;
pub type SharedState = Arc<Mutex<World>>;

pub struct World {
    pub engine: Engine,
    pub db: crate::db::Db,
    pub connections: SharedConnections,
    pub scripts: HashMap<String, AST>,
    pub command_metadata: HashMap<String, CommandMeta>,
    // Character creation data (loaded from scripts/data/*.json)
    pub class_definitions: HashMap<String, ClassDefinition>,
    pub trait_definitions: HashMap<String, TraitDefinition>,
    pub race_suggestions: Vec<RaceSuggestion>,
    // Crafting/cooking recipes (created via recedit command)
    pub recipes: HashMap<String, Recipe>,
    // Transportation system (elevators, buses, trains, etc.)
    pub transports: HashMap<Uuid, TransportData>,
    // Matrix integration sender (for disconnect notifications)
    pub matrix_sender: Option<matrix::MatrixSender>,
    // Shutdown command sender (for admin shutdown command)
    pub shutdown_sender: Option<tokio::sync::mpsc::UnboundedSender<ShutdownCommand>>,
    // Shutdown cancellation sender (to abort pending shutdown)
    pub shutdown_cancel_sender: Option<tokio::sync::watch::Sender<bool>>,
}

/// Command sent to trigger server shutdown
#[derive(Debug, Clone)]
pub struct ShutdownCommand {
    pub delay_seconds: u64,
    pub reason: String,
    pub admin_name: String,
}

/// Result of a shutdown cancellation attempt
#[derive(Debug, Clone, PartialEq)]
pub enum CancelShutdownResult {
    Cancelled,
    NoShutdownPending,
}

// Helper functions that work with SharedConnections directly (for use by Rhai functions)
pub fn set_character_for_connection(connections: &SharedConnections, connection_id_str: String, character_data: CharacterData) -> Result<(), Box<rhai::EvalAltResult>> {
    let connection_id = uuid::Uuid::parse_str(&connection_id_str)
        .map_err(|e| Box::new(rhai::EvalAltResult::ErrorRuntime(format!("Invalid Connection ID: {}", e).into(), Position::NONE)))?;
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        // Copy persisted settings from CharacterData to session
        session.show_room_flags = character_data.show_room_flags;
        session.character = Some(character_data);
        Ok(())
    } else {
        Err(Box::new(rhai::EvalAltResult::ErrorRuntime("Connection not found.".into(), Position::NONE)))
    }
}

pub fn get_character_for_connection(connections: &SharedConnections, connection_id_str: String) -> Result<CharacterData, Box<rhai::EvalAltResult>> {
    let connection_id = uuid::Uuid::parse_str(&connection_id_str)
        .map_err(|e| Box::new(rhai::EvalAltResult::ErrorRuntime(format!("Invalid Connection ID: {}", e).into(), Position::NONE)))?;
    let conns = connections.lock().unwrap();
    if let Some(session) = conns.get(&connection_id) {
        session.character.clone().ok_or_else(|| {
            Box::new(rhai::EvalAltResult::ErrorRuntime("No character logged in for this connection.".into(), Position::NONE))
        })
    } else {
        Err(Box::new(rhai::EvalAltResult::ErrorRuntime("Connection not found.".into(), Position::NONE)))
    }
}

pub fn clear_player_character(connections: &SharedConnections, connection_id_str: String) -> Result<(), Box<rhai::EvalAltResult>> {
    let connection_id = uuid::Uuid::parse_str(&connection_id_str)
        .map_err(|e| Box::new(rhai::EvalAltResult::ErrorRuntime(format!("Invalid Connection ID: {}", e).into(), Position::NONE)))?;
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        session.character = None;
        Ok(())
    } else {
        Err(Box::new(rhai::EvalAltResult::ErrorRuntime("Connection not found.".into(), Position::NONE)))
    }
}

pub fn disconnect_client(connections: &SharedConnections, connection_id_str: String) -> Result<(), Box<rhai::EvalAltResult>> {
    let connection_id = uuid::Uuid::parse_str(&connection_id_str)
        .map_err(|e| Box::new(rhai::EvalAltResult::ErrorRuntime(format!("Invalid Connection ID: {}", e).into(), Position::NONE)))?;
    let mut conns = connections.lock().unwrap();
    if conns.remove(&connection_id).is_some() {
        Ok(())
    } else {
        Err(Box::new(rhai::EvalAltResult::ErrorRuntime("Connection not found.".into(), Position::NONE)))
    }
}

pub fn send_client_message(connections: &SharedConnections, connection_id_str: String, message: String) {
    if let Ok(connection_id) = uuid::Uuid::parse_str(&connection_id_str) {
        let conns = connections.lock().unwrap();
        if let Some(session) = conns.get(&connection_id) {
            let _ = session.sender.send(message + "\n");
        }
    }
}

pub fn get_characters_in_room(connections: &SharedConnections, room_id: Uuid) -> Vec<String> {
    let conns = connections.lock().unwrap();
    conns.values()
        .filter_map(|session| {
            session.character.as_ref().and_then(|char| {
                if char.current_room_id == room_id {
                    Some(char.name.clone())
                } else {
                    None
                }
            })
        })
        .collect()
}

pub fn get_characters_in_room_with_positions(connections: &SharedConnections, room_id: Uuid) -> Vec<(String, CharacterPosition)> {
    let conns = connections.lock().unwrap();
    conns.values()
        .filter_map(|session| {
            session.character.as_ref().and_then(|char| {
                if char.current_room_id == room_id {
                    Some((char.name.clone(), char.position))
                } else {
                    None
                }
            })
        })
        .collect()
}

pub fn broadcast_to_room(
    connections: &SharedConnections,
    room_id: Uuid,
    message: String,
    exclude_name: Option<&str>,
) {
    let conns = connections.lock().unwrap();
    for (_id, session) in conns.iter() {
        if let Some(ref character) = session.character {
            if character.current_room_id == room_id {
                if let Some(exclude) = exclude_name {
                    if character.name == exclude {
                        continue;
                    }
                }
                let _ = session.sender.send(message.clone() + "\n");
            }
        }
    }
}

/// Broadcast a message to all awake players in a room (skips sleeping players)
pub fn broadcast_to_room_awake(
    connections: &SharedConnections,
    room_id: Uuid,
    message: String,
    exclude_name: Option<&str>,
) {
    let conns = connections.lock().unwrap();
    for (_id, session) in conns.iter() {
        if let Some(ref character) = session.character {
            if character.current_room_id == room_id {
                // Skip sleeping players
                if character.position == CharacterPosition::Sleeping {
                    continue;
                }
                if let Some(exclude) = exclude_name {
                    if character.name == exclude {
                        continue;
                    }
                }
                let _ = session.sender.send(message.clone() + "\n");
            }
        }
    }
}

/// Broadcast different messages to awake vs sleeping players
/// Sleeping players get a dream-like version of events
pub fn broadcast_to_room_dreaming(
    connections: &SharedConnections,
    room_id: Uuid,
    awake_message: String,
    sleeping_message: String,
    exclude_name: Option<&str>,
) {
    let conns = connections.lock().unwrap();
    for (_id, session) in conns.iter() {
        if let Some(ref character) = session.character {
            if character.current_room_id == room_id {
                if let Some(exclude) = exclude_name {
                    if character.name == exclude {
                        continue;
                    }
                }
                let msg = if character.position == CharacterPosition::Sleeping {
                    sleeping_message.clone() + "\n"
                } else {
                    awake_message.clone() + "\n"
                };
                let _ = session.sender.send(msg);
            }
        }
    }
}

/// Broadcast a message to all logged-in players
pub fn broadcast_to_all_players(connections: &SharedConnections, message: &str) {
    let conns = connections.lock().unwrap();
    for session in conns.values() {
        if session.character.is_some() {
            let _ = session.sender.send(message.to_string());
        }
    }
}

/// Broadcast a message to players in rooms that can see outside (no no_windows flag, not climate controlled)
pub fn broadcast_to_outdoor_players(db: &db::Db, connections: &SharedConnections, message: &str) {
    let conns = connections.lock().unwrap();
    for session in conns.values() {
        if let Some(ref character) = session.character {
            if let Ok(Some(room)) = db.get_room_data(&character.current_room_id) {
                // Check for climate_controlled (room or area inherited)
                let is_climate_controlled = room.flags.climate_controlled ||
                    room.area_id.and_then(|aid| db.get_area_data(&aid).ok().flatten())
                        .map(|area| area.flags.climate_controlled)
                        .unwrap_or(false);
                // Skip if room has no windows OR is climate controlled
                if !room.flags.no_windows && !is_climate_controlled {
                    let _ = session.sender.send(message.to_string());
                }
            } else {
                // If we can't get room data, default to showing the message
                let _ = session.sender.send(message.to_string());
            }
        }
    }
}

/// Broadcast a message to builders/admins who have builder_debug_enabled
pub fn broadcast_to_builders(connections: &SharedConnections, message: &str) {
    let conns = connections.lock().unwrap();
    for session in conns.values() {
        if let Some(ref character) = session.character {
            if (character.is_builder || character.is_admin) && character.builder_debug_enabled {
                let _ = session.sender.send(format!("[Builder] {}\n", message));
            }
        }
    }
}

/// Get the message to broadcast when time of day changes
pub fn get_time_transition_message(tod: &TimeOfDay) -> &'static str {
    match tod {
        TimeOfDay::Dawn => "The sun begins to rise on the horizon, painting the sky in shades of orange and pink.",
        TimeOfDay::Morning => "The morning sun casts long shadows across the land.",
        TimeOfDay::Noon => "The sun reaches its peak in the sky, bathing everything in bright light.",
        TimeOfDay::Afternoon => "The afternoon sun warms the land as the day continues.",
        TimeOfDay::Dusk => "The sun begins to set, painting the sky in orange and crimson hues.",
        TimeOfDay::Evening => "Twilight settles over the land as stars begin to appear.",
        TimeOfDay::Night => "Darkness falls as night takes hold. The stars shine brightly overhead.",
    }
}

/// Get the message to broadcast when season changes
pub fn get_season_transition_message(season: &Season) -> &'static str {
    match season {
        Season::Spring => "The air grows warmer as spring arrives. Flowers begin to bloom across the land.",
        Season::Summer => "Summer has arrived! The sun beats down warmly and the days grow long.",
        Season::Autumn => "The leaves begin to change color as autumn settles in. A cool breeze carries the scent of fallen leaves.",
        Season::Winter => "Winter descends upon the land. A chill fills the air as frost blankets the ground.",
    }
}

/// Fire environmental triggers of a given type for all rooms with players
/// Returns true if any triggers were fired
pub fn fire_environmental_triggers_impl(
    db: &db::Db,
    connections: &SharedConnections,
    trigger_type: TriggerType,
    context: &std::collections::HashMap<String, String>,
) -> bool {
    use rand::Rng;

    let rooms = match db.list_all_rooms() {
        Ok(r) => r,
        Err(_) => return false,
    };

    let mut any_fired = false;

    for room in rooms {
        // For time, weather, and season triggers, skip indoor/climate_controlled rooms
        if trigger_type == TriggerType::OnTimeChange || trigger_type == TriggerType::OnWeatherChange || trigger_type == TriggerType::OnSeasonChange {
            // Check for climate_controlled (room or area inherited)
            let is_climate_controlled = room.flags.climate_controlled ||
                room.area_id.and_then(|aid| db.get_area_data(&aid).ok().flatten())
                    .map(|area| area.flags.climate_controlled)
                    .unwrap_or(false);
            if room.flags.indoors || is_climate_controlled {
                continue;
            }
        }

        // Find matching triggers
        for trigger in &room.triggers {
            if trigger.trigger_type != trigger_type || !trigger.enabled {
                continue;
            }

            // Check chance
            if trigger.chance < 100 {
                let roll: i32 = rand::thread_rng().gen_range(1..=100);
                if roll > trigger.chance {
                    continue;
                }
            }

            // Find all players in this room
            let players_in_room: Vec<(Uuid, tokio::sync::mpsc::UnboundedSender<String>)> = {
                let conns = connections.lock().unwrap();
                conns.iter()
                    .filter_map(|(conn_id, session)| {
                        if let Some(ref char) = session.character {
                            if char.current_room_id == room.id {
                                return Some((*conn_id, session.sender.clone()));
                            }
                        }
                        None
                    })
                    .collect()
            };

            if players_in_room.is_empty() {
                continue;
            }

            // Handle built-in templates (script_name starts with @)
            if trigger.script_name.starts_with('@') {
                let template_name = &trigger.script_name[1..];
                execute_room_template(template_name, &trigger.args, &room.id, connections, context);
                any_fired = true;
                continue;
            }

            // Execute trigger script
            let script_path = format!("scripts/triggers/{}.rhai", trigger.script_name);
            let script_content = match std::fs::read_to_string(&script_path) {
                Ok(content) => content,
                Err(_) => continue,
            };

            // Create a minimal Rhai engine for trigger execution
            let mut trigger_engine = rhai::Engine::new();

            // Register send_client_message
            for (conn_id, sender) in &players_in_room {
                let conn_id_str = conn_id.to_string();
                let sender_clone = sender.clone();

                trigger_engine.register_fn("send_client_message", move |cid: String, message: String| {
                    if cid == conn_id_str {
                        let _ = sender_clone.send(message);
                    }
                });
            }

            // Register broadcast_to_room
            let conns_clone = connections.clone();
            let room_id = room.id;
            trigger_engine.register_fn("broadcast_to_room", move |_rid: String, message: String, _exclude: String| {
                let conns = conns_clone.lock().unwrap();
                for (_, session) in conns.iter() {
                    if let Some(ref char) = session.character {
                        if char.current_room_id == room_id {
                            let _ = session.sender.send(message.clone());
                        }
                    }
                }
            });

            // Register random_int
            trigger_engine.register_fn("random_int", |min: i64, max: i64| {
                if min >= max {
                    return min;
                }
                rand::thread_rng().gen_range(min..=max)
            });

            // Compile and run trigger
            if let Ok(ast) = trigger_engine.compile(&script_content) {
                for (conn_id, _) in &players_in_room {
                    let mut scope = rhai::Scope::new();
                    let room_id_str = room.id.to_string();
                    let conn_id_str = conn_id.to_string();

                    // Build context map
                    let mut rhai_context = rhai::Map::new();
                    for (k, v) in context {
                        rhai_context.insert(k.clone().into(), v.clone().into());
                    }

                    let _ = trigger_engine.call_fn::<rhai::Dynamic>(
                        &mut scope,
                        &ast,
                        "run_trigger",
                        (room_id_str, conn_id_str, rhai_context),
                    );
                }
                any_fired = true;
            }
        }
    }

    any_fired
}

/// Execute a built-in room template for environmental triggers
fn execute_room_template(
    template_name: &str,
    args: &[String],
    room_id: &Uuid,
    connections: &SharedConnections,
    context: &std::collections::HashMap<String, String>,
) {
    // Helper to broadcast message to all players in the room
    let broadcast = |msg: &str| {
        if let Ok(conns) = connections.lock() {
            for (_, session) in conns.iter() {
                if let Some(ref char_data) = session.character {
                    if char_data.current_room_id == *room_id {
                        let _ = session.sender.send(format!("{}\n", msg));
                    }
                }
            }
        }
    };

    match template_name {
        "room_message" => {
            if let Some(message) = args.first() {
                broadcast(message);
            }
        }
        "time_message" => {
            if args.len() >= 2 {
                let target_time = &args[0].to_lowercase();
                let message = &args[1];

                if let Some(new_time) = context.get("new_time") {
                    if new_time.to_lowercase() == *target_time {
                        broadcast(message);
                    }
                }
            }
        }
        "weather_message" => {
            if args.len() >= 2 {
                let target_weather = args[0].to_lowercase();
                let message = &args[1];

                if let Some(new_weather) = context.get("new_weather") {
                    let weather_lower = new_weather.to_lowercase();
                    let matches = weather_lower == target_weather
                        || (target_weather == "raining" && (weather_lower.contains("rain") || weather_lower == "thunderstorm"))
                        || (target_weather == "snowing" && weather_lower.contains("snow"))
                        || (target_weather == "stormy" && weather_lower == "thunderstorm")
                        || (target_weather == "precipitation" && (weather_lower.contains("rain") || weather_lower.contains("snow")));

                    if matches {
                        broadcast(message);
                    }
                }
            }
        }
        "season_message" => {
            if args.len() >= 2 {
                let target_season = args[0].to_lowercase();
                let message = &args[1];

                if let Some(new_season) = context.get("new_season") {
                    if new_season.to_lowercase() == target_season {
                        broadcast(message);
                    }
                }
            }
        }
        _ => {}
    }
}

#[derive(Clone)]
pub struct OnlinePlayer {
    pub name: String,
    pub room_id: Uuid,
    pub addr: String,
}

pub fn get_online_players(connections: &SharedConnections) -> Vec<OnlinePlayer> {
    let conns = connections.lock().unwrap();
    conns.values()
        .filter_map(|session| {
            session.character.as_ref().map(|c| OnlinePlayer {
                name: c.name.clone(),
                room_id: c.current_room_id,
                addr: session.addr.to_string(),
            })
        })
        .collect()
}

/// Save all logged-in player characters to the database.
/// Called during graceful shutdown to prevent data loss.
pub fn save_all_players(connections: &SharedConnections, db: &crate::db::Db) -> usize {
    let conns = connections.lock().unwrap();
    let mut saved_count = 0;

    for (_conn_id, session) in conns.iter() {
        if let Some(ref char_data) = session.character {
            match db.save_character_data(char_data.clone()) {
                Ok(()) => {
                    info!("Saved character on shutdown: {}", char_data.name);
                    saved_count += 1;
                }
                Err(e) => {
                    error!("Failed to save {} on shutdown: {}", char_data.name, e);
                }
            }
        }
    }

    saved_count
}

pub fn find_player_connection_by_name(connections: &SharedConnections, player_name: &str) -> Option<ConnectionId> {
    let conns = connections.lock().unwrap();
    for (id, session) in conns.iter() {
        if let Some(ref character) = session.character {
            if character.name.eq_ignore_ascii_case(player_name) {
                return Some(*id);
            }
        }
    }
    None
}

pub fn get_default_aliases() -> HashMap<String, String> {
    let mut defaults = HashMap::new();
    defaults.insert("n".to_string(), "go north".to_string());
    defaults.insert("s".to_string(), "go south".to_string());
    defaults.insert("e".to_string(), "go east".to_string());
    defaults.insert("w".to_string(), "go west".to_string());
    defaults.insert("u".to_string(), "go up".to_string());
    defaults.insert("d".to_string(), "go down".to_string());
    defaults.insert("'".to_string(), "say".to_string());
    defaults.insert(":".to_string(), "emote".to_string());
    defaults.insert("hold".to_string(), "wield".to_string());
    defaults.insert("afk".to_string(), "set afk".to_string());
    defaults.insert("kill".to_string(), "attack".to_string());
    defaults
}

fn resolve_alias(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    alias: &str,
) -> Option<String> {
    let conns = connections.lock().unwrap();
    if let Some(session) = conns.get(&connection_id) {
        if let Some(ref character) = session.character {
            // User aliases take precedence over defaults
            if let Some(expansion) = character.aliases.get(alias) {
                return Some(expansion.clone());
            }
        }
    }
    // Fall back to default aliases
    get_default_aliases().get(alias).cloned()
}

fn expand_alias(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    command_name: &str,
    args: &str,
) -> String {
    if let Some(expansion) = resolve_alias(connections, connection_id, command_name) {
        if args.is_empty() {
            expansion
        } else {
            // Append args to each semicolon-separated command
            expansion
                .split(';')
                .map(|cmd| format!("{} {}", cmd.trim(), args))
                .collect::<Vec<_>>()
                .join(";")
        }
    } else if args.is_empty() {
        command_name.to_string()
    } else {
        format!("{} {}", command_name, args)
    }
}

// === Line Editor Shared Handler ===

/// Help text for the line editor
const EDITOR_HELP: &str = "\
=== Line Editor Commands ===
  .l            - List buffer with line numbers
  .d <n>        - Delete line n
  .i <n> <text> - Insert text before line n
  .r <n> <text> - Replace line n with text
  .s /old/new/  - Substitute: replace all 'old' with 'new'
  .c            - Clear entire buffer
  .u            - Undo last change
  .p            - Preview without line numbers
  .h            - Show this help
  .             - Save and exit
  @             - Cancel and exit
  <text>        - Append text as new line
";

/// Result of processing a line editor command
enum EditorCommandResult {
    /// Command handled, send this message to client
    Handled(String),
    /// User wants to save - buffer contents returned as joined string
    Save(String),
    /// User wants to cancel
    Cancel,
    /// Not an editor command - treat as text to append
    AppendText(String),
}

/// Process line editor commands for any OLC mode.
/// Takes mutable references to the buffer and undo buffer.
/// Returns an EditorCommandResult indicating what action to take.
fn handle_editor_command(
    input: &str,
    buffer: &mut Vec<String>,
    undo_buffer: &mut Option<Vec<String>>,
) -> EditorCommandResult {
    let trimmed = input.trim();
    let trimmed_lower = trimmed.to_lowercase();

    // Help
    if trimmed_lower == ".h" {
        return EditorCommandResult::Handled(EDITOR_HELP.to_string());
    }

    // Substitute: .s /old/new/ - replace all occurrences
    if trimmed_lower.starts_with(".s ") {
        let rest = &trimmed[3..];
        if rest.len() < 4 {
            return EditorCommandResult::Handled("Usage: .s /old/new/ (use any delimiter)\n".to_string());
        }
        let delim = rest.chars().next().unwrap();
        let rest_after_delim = &rest[delim.len_utf8()..];
        let parts: Vec<&str> = rest_after_delim.split(delim).collect();
        if parts.len() < 2 {
            return EditorCommandResult::Handled("Usage: .s /old/new/ (use any delimiter)\n".to_string());
        }
        let old_str = parts[0];
        let new_str = parts[1];
        if old_str.is_empty() {
            return EditorCommandResult::Handled("Error: Search string cannot be empty.\n".to_string());
        }
        *undo_buffer = Some(buffer.clone());
        let mut count = 0;
        for line in buffer.iter_mut() {
            if line.contains(old_str) {
                count += line.matches(old_str).count();
                *line = line.replace(old_str, new_str);
            }
        }
        if count > 0 {
            return EditorCommandResult::Handled(format!("Replaced {} occurrence(s).\n", count));
        } else {
            return EditorCommandResult::Handled("No matches found.\n".to_string());
        }
    }

    // Save
    if trimmed == "." {
        let content = buffer.join("\n");
        return EditorCommandResult::Save(content);
    }

    // Cancel
    if trimmed == "@" {
        return EditorCommandResult::Cancel;
    }

    // List with line numbers
    if trimmed_lower == ".l" {
        if buffer.is_empty() {
            return EditorCommandResult::Handled("(empty)\n".to_string());
        }
        let mut output = String::new();
        for (i, line) in buffer.iter().enumerate() {
            output.push_str(&format!("{:3}: {}\n", i + 1, line));
        }
        return EditorCommandResult::Handled(output);
    }

    // Preview without line numbers
    if trimmed_lower == ".p" {
        if buffer.is_empty() {
            return EditorCommandResult::Handled("(empty)\n".to_string());
        }
        return EditorCommandResult::Handled(buffer.join("\n") + "\n");
    }

    // Clear buffer
    if trimmed_lower == ".c" {
        *undo_buffer = Some(buffer.clone());
        buffer.clear();
        return EditorCommandResult::Handled("Buffer cleared.\n".to_string());
    }

    // Undo last change
    if trimmed_lower == ".u" {
        if let Some(undo) = undo_buffer.take() {
            *buffer = undo;
            return EditorCommandResult::Handled("Undo successful.\n".to_string());
        } else {
            return EditorCommandResult::Handled("Nothing to undo.\n".to_string());
        }
    }

    // Delete line N
    if trimmed_lower.starts_with(".d ") {
        let line_num: Option<usize> = trimmed[3..].trim().parse().ok();
        if let Some(n) = line_num {
            if n >= 1 && n <= buffer.len() {
                *undo_buffer = Some(buffer.clone());
                buffer.remove(n - 1);
                return EditorCommandResult::Handled(format!("Line {} deleted.\n", n));
            } else {
                return EditorCommandResult::Handled(format!("Line {} out of range (1-{}).\n", n, buffer.len()));
            }
        } else {
            return EditorCommandResult::Handled("Usage: .d <line_number>\n".to_string());
        }
    }

    // Insert before line N
    if trimmed_lower.starts_with(".i ") {
        let rest = &trimmed[3..];
        let parts: Vec<&str> = rest.splitn(2, ' ').collect();
        if parts.len() >= 2 {
            let line_num: Option<usize> = parts[0].trim().parse().ok();
            let text = parts[1].to_string();
            if let Some(n) = line_num {
                if n >= 1 && n <= buffer.len() + 1 {
                    *undo_buffer = Some(buffer.clone());
                    buffer.insert(n - 1, text);
                    return EditorCommandResult::Handled(format!("Line {} inserted.\n", n));
                } else {
                    return EditorCommandResult::Handled(format!("Line {} out of range (1-{}).\n", n, buffer.len() + 1));
                }
            } else {
                return EditorCommandResult::Handled("Usage: .i <line_number> <text>\n".to_string());
            }
        } else {
            return EditorCommandResult::Handled("Usage: .i <line_number> <text>\n".to_string());
        }
    }

    // Replace line N
    if trimmed_lower.starts_with(".r ") {
        let rest = &trimmed[3..];
        let parts: Vec<&str> = rest.splitn(2, ' ').collect();
        if parts.len() >= 2 {
            let line_num: Option<usize> = parts[0].trim().parse().ok();
            let text = parts[1].to_string();
            if let Some(n) = line_num {
                if n >= 1 && n <= buffer.len() {
                    *undo_buffer = Some(buffer.clone());
                    buffer[n - 1] = text;
                    return EditorCommandResult::Handled(format!("Line {} replaced.\n", n));
                } else {
                    return EditorCommandResult::Handled(format!("Line {} out of range (1-{}).\n", n, buffer.len()));
                }
            } else {
                return EditorCommandResult::Handled("Usage: .r <line_number> <text>\n".to_string());
            }
        } else {
            return EditorCommandResult::Handled("Usage: .r <line_number> <text>\n".to_string());
        }
    }

    // Not an editor command - treat as text to append
    EditorCommandResult::AppendText(trimmed.to_string())
}

/// Build the prompt string for a connection, respecting prompt_mode setting.
/// Returns simple "> " for guests or when prompt_mode is "simple".
/// Returns verbose "[HP:current/max] >" with color coding when prompt_mode is "verbose".
fn build_prompt(
    connection_id: &ConnectionId,
    connections: &SharedConnections,
    state: &SharedState,
) -> String {
    let (prompt_mode, hp, max_hp, stamina, max_stamina, colors_enabled, char_name) = {
        let conns = connections.lock().unwrap();
        let session = match conns.get(connection_id) {
            Some(s) => s,
            None => return "> ".to_string(),
        };

        let colors = session.colors_enabled;

        match &session.character {
            Some(c) => {
                let mode = if c.prompt_mode.is_empty() { "simple" } else { &c.prompt_mode };
                (mode.to_string(), c.hp, c.max_hp, c.stamina, c.max_stamina, colors, c.name.clone())
            }
            None => return "> ".to_string(),  // Not logged in = simple prompt
        }
    };

    // Get equipped items from database (source of truth is ItemLocation::Equipped)
    let equipped_items: Vec<Uuid> = {
        let world = state.lock().unwrap();
        world.db.get_equipped_items(&char_name)
            .unwrap_or_default()
            .into_iter()
            .map(|item| item.id)
            .collect()
    };

    if prompt_mode == "simple" {
        return "> ".to_string();
    }

    // Verbose prompt
    let hp_percent = if max_hp > 0 { (hp * 100) / max_hp } else { 100 };

    // Color based on health percentage
    let (hp_color, reset) = if colors_enabled {
        let color = if hp_percent >= 70 {
            "\x1b[32m"  // Green: healthy
        } else if hp_percent >= 30 {
            "\x1b[33m"  // Yellow: wounded
        } else {
            "\x1b[31m"  // Red: critical
        };
        (color, "\x1b[0m")
    } else {
        ("", "")
    };

    // Stamina percentage and color
    let stamina_percent = if max_stamina > 0 { (stamina * 100) / max_stamina } else { 100 };
    let st_color = if colors_enabled {
        if stamina_percent >= 70 {
            "\x1b[36m"  // Cyan: energized
        } else if stamina_percent >= 30 {
            "\x1b[34m"  // Blue: tired
        } else {
            "\x1b[35m"  // Magenta: exhausted
        }
    } else {
        ""
    };

    let base_prompt = format!("[{}HP:{}/{}{}] [{}ST:{}/{}{}] ", hp_color, hp, max_hp, reset, st_color, stamina, max_stamina, reset);

    // Collect on_prompt trigger contributions from equipped items
    let extra = collect_on_prompt_contributions(connection_id, connections, state, &equipped_items);

    format!("{}{}> ", base_prompt, extra)
}

/// Collect prompt contributions from equipped items with on_prompt triggers
fn collect_on_prompt_contributions(
    connection_id: &ConnectionId,
    connections: &SharedConnections,
    state: &SharedState,
    equipped_item_ids: &[Uuid],
) -> String {
    let mut contributions = String::new();

    let world = state.lock().unwrap();

    for item_id in equipped_item_ids {
        let item = match world.db.get_item_data(item_id) {
            Ok(Some(i)) => i,
            _ => continue,
        };

        // Find enabled on_prompt triggers
        let prompt_triggers: Vec<_> = item.triggers.iter()
            .filter(|t| t.trigger_type == ItemTriggerType::OnPrompt && t.enabled)
            .collect();

        if prompt_triggers.is_empty() {
            continue;
        }

        for trigger in prompt_triggers {
            // Check chance
            if trigger.chance < 100 {
                use rand::Rng;
                let roll = rand::thread_rng().gen_range(1..=100);
                if roll > trigger.chance {
                    continue;
                }
            }

            // Load and execute trigger script
            let script_path = format!("scripts/triggers/{}.rhai", trigger.script_name);
            let script_content = match std::fs::read_to_string(&script_path) {
                Ok(c) => c,
                Err(_) => continue,
            };

            // Create a minimal engine for trigger execution
            let mut trigger_engine = rhai::Engine::new();

            // Register get_game_time for watch triggers
            let db_for_time = world.db.clone();
            trigger_engine.register_fn("get_game_time", move || -> rhai::Map {
                let game_time = db_for_time.get_game_time().unwrap_or_default();
                let mut map = rhai::Map::new();
                map.insert("hour".into(), rhai::Dynamic::from(game_time.hour as i64));
                map.insert("day".into(), rhai::Dynamic::from(game_time.day as i64));
                map.insert("month".into(), rhai::Dynamic::from(game_time.month as i64));
                map.insert("year".into(), rhai::Dynamic::from(game_time.year as i64));
                map.insert("season".into(), rhai::Dynamic::from(game_time.get_season().to_string().to_lowercase()));
                map
            });

            // Compile and run
            match trigger_engine.compile(&script_content) {
                Ok(ast) => {
                    let item_id_str = item_id.to_string();
                    let conn_id_str = connection_id.to_string();
                    let context = rhai::Map::new();

                    match trigger_engine.call_fn::<rhai::Dynamic>(
                        &mut rhai::Scope::new(),
                        &ast,
                        "run_trigger",
                        (item_id_str, conn_id_str, context)
                    ) {
                        Ok(result) => {
                            let result_str = result.to_string();
                            if !result_str.is_empty() && result_str != "()" {
                                contributions.push_str(&result_str);
                            }
                        }
                        Err(e) => {
                            tracing::error!("on_prompt trigger runtime error: {}", e);
                        }
                    }
                }
                Err(e) => {
                    tracing::error!("on_prompt trigger compile error: {}", e);
                }
            }
        }
    }

    contributions
}

pub async fn handle_connection(
    socket: tokio::net::TcpStream,
    addr: std::net::SocketAddr,
    state: SharedState,
    connection_id: ConnectionId,
) {
    let (reader, writer) = socket.into_split();

    let (tx_client, rx_client) = mpsc::unbounded_channel::<String>();
    let (tx_input, mut rx_input) = mpsc::unbounded_channel::<InputEvent>();
    let (tx_raw, rx_raw) = mpsc::unbounded_channel::<Vec<u8>>();

    // Get the connections map from World and store the PlayerSession
    let connections = {
        let world = state.lock().unwrap();
        world.connections.clone()
    };

    {
        let mut conns = connections.lock().unwrap();
        conns.insert(
            connection_id,
            PlayerSession {
                character: None,
                sender: tx_client.clone(),
                addr,
                olc_mode: None,
                olc_buffer: Vec::new(),
                olc_edit_room: None,
                olc_extra_keywords: Vec::new(),
                olc_undo_buffer: None,
                wizard_data: None,
                mxp_enabled: false,
                colors_enabled: true,
                show_room_flags: false,
                telnet_state: telnet::TelnetState::new(),
                input_buffer: String::new(),
                cursor_pos: 0,
                command_history: VecDeque::new(),
                history_index: None,
                saved_input: String::new(),
                escape_state: telnet::EscapeState::Normal,
                pending_ai_request: None,
                pending_ai_response: None,
                pending_ai_target: None,
                fishing_state: None,
                afk: false,
                last_activity_time: std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_secs() as i64,
            },
        );
    }

    // Send welcome banner
    if let Ok(banner) = std::fs::read_to_string("assets/banner.txt") {
        let _ = tx_client.send(banner);
    }

    // Spawn character-mode read task with telnet protocol support
    tokio::spawn(handle_read_char_mode(
        reader,
        addr,
        connection_id,
        tx_input,
        connections.clone(),
        tx_raw,
    ));

    // Spawn write task with raw byte support for telnet negotiation
    tokio::spawn(handle_write_with_raw(writer, addr, rx_client, rx_raw));

    // Main loop for processing client input and sending responses
    loop {
        // Check if connection still exists. If not, it means it was disconnected by a script.
        let is_connected = {
            let conns = connections.lock().unwrap();
            conns.contains_key(&connection_id)
        };
        if !is_connected {
            info!("Connection {} removed by script, terminating handle_connection.", addr);
            break;
        }

        // Only send prompt in line mode (char mode echoes as you type)
        let is_char_mode = {
            let conns = connections.lock().unwrap();
            conns.get(&connection_id)
                .map(|s| s.telnet_state.char_mode)
                .unwrap_or(false)
        };
        if !is_char_mode {
            let prompt = build_prompt(&connection_id, &connections, &state);
            if let Err(e) = tx_client.send(prompt) {
                error!("Failed to send prompt to socket {}: {}", addr, e);
                break;
            }
        }

        let event = match rx_input.recv().await {
            Some(event) => event,
            None => break, // Read task disconnected
        };

        // Handle Tab completion
        if matches!(event, InputEvent::Tab) {
            // Get current input buffer and cursor position
            let (current_input, cursor_pos, window_width) = {
                let conns = connections.lock().unwrap();
                conns.get(&connection_id)
                    .map(|s| (s.input_buffer.clone(), s.cursor_pos, s.telnet_state.window_width))
                    .unwrap_or_default()
            };

            // Gather completion data
            let (available_commands, room_vnums, item_vnums, mobile_vnums, area_prefixes, recipe_vnums, transport_vnums, online_players, has_builder_access) = {
                let world = state.lock().unwrap();

                // Get commands the user can access
                let is_logged_in = {
                    let conns = connections.lock().unwrap();
                    conns.get(&connection_id)
                        .and_then(|s| s.character.as_ref())
                        .is_some()
                };
                let (is_builder, is_admin) = {
                    let conns = connections.lock().unwrap();
                    conns.get(&connection_id)
                        .and_then(|s| s.character.as_ref())
                        .map(|c| (c.is_builder, c.is_admin))
                        .unwrap_or((false, false))
                };

                let available_commands: Vec<String> = world.command_metadata
                    .iter()
                    .filter(|(_, meta)| {
                        match meta.access.as_str() {
                            "guest" => true,
                            "user" => is_logged_in,
                            "builder" => is_builder || is_admin,
                            "admin" => is_admin,
                            _ => true,
                        }
                    })
                    .map(|(name, _)| name.clone())
                    .collect();

                // Get vnums from database
                let room_vnums: Vec<String> = world.db.list_all_rooms()
                    .unwrap_or_default()
                    .iter()
                    .filter_map(|r| r.vnum.clone())
                    .collect();

                let item_vnums: Vec<String> = world.db.list_all_items()
                    .unwrap_or_default()
                    .iter()
                    .filter(|i| i.is_prototype)
                    .filter_map(|i| i.vnum.clone())
                    .collect();

                let mobile_vnums: Vec<String> = world.db.list_all_mobiles()
                    .unwrap_or_default()
                    .iter()
                    .filter(|m| m.is_prototype)
                    .filter_map(|m| Some(m.vnum.clone()))
                    .filter(|v| !v.is_empty())
                    .collect();

                let area_prefixes: Vec<String> = world.db.list_all_areas()
                    .unwrap_or_default()
                    .iter()
                    .map(|a| a.prefix.clone())
                    .collect();

                let recipe_vnums: Vec<String> = world.recipes
                    .keys()
                    .cloned()
                    .collect();

                let transport_vnums: Vec<String> = world.db.list_all_transports()
                    .unwrap_or_default()
                    .iter()
                    .filter_map(|t| t.vnum.clone())
                    .collect();

                // Get online player names
                let online_players: Vec<String> = {
                    let conns = connections.lock().unwrap();
                    conns.values()
                        .filter_map(|s| s.character.as_ref())
                        .map(|c| c.name.clone())
                        .collect()
                };

                let has_builder_access = is_builder || is_admin;

                (available_commands, room_vnums, item_vnums, mobile_vnums, area_prefixes, recipe_vnums, transport_vnums, online_players, has_builder_access)
            };

            // Perform completion
            let result = completion::complete(
                &current_input,
                cursor_pos,
                &available_commands,
                &room_vnums,
                &item_vnums,
                &mobile_vnums,
                &area_prefixes,
                &recipe_vnums,
                &transport_vnums,
                &online_players,
                has_builder_access,
            );

            if result.is_empty() {
                // No completions - just beep or do nothing
                continue;
            }

            if result.is_unique() {
                // Single match - auto-complete
                let completed = &result.completions[0];
                let to_add = &completed[result.partial.len()..];

                // Update input buffer
                {
                    let mut conns = connections.lock().unwrap();
                    if let Some(session) = conns.get_mut(&connection_id) {
                        session.input_buffer.push_str(to_add);
                        session.input_buffer.push(' '); // Add space after completion
                        session.cursor_pos = session.input_buffer.chars().count();
                    }
                }

                // Echo the completion to the client
                let _ = tx_client.send(format!("{} ", to_add));
            } else {
                // Multiple matches - show list and complete common prefix
                let display = completion::format_completions(&result, window_width);

                // Complete to common prefix if it's longer than what we have
                let to_add = if result.common_prefix.len() > result.partial.len() {
                    &result.common_prefix[result.partial.len()..]
                } else {
                    ""
                };

                if !to_add.is_empty() {
                    // Update input buffer with common prefix
                    let mut conns = connections.lock().unwrap();
                    if let Some(session) = conns.get_mut(&connection_id) {
                        session.input_buffer.push_str(to_add);
                        session.cursor_pos = session.input_buffer.chars().count();
                    }
                }

                // Display completions and redraw line
                let new_input = {
                    let conns = connections.lock().unwrap();
                    conns.get(&connection_id)
                        .map(|s| s.input_buffer.clone())
                        .unwrap_or_default()
                };

                // ANSI: clear line, show completions, redraw prompt and input
                let output = format!("\r\n{}\r\n> {}", display, new_input);
                let _ = tx_client.send(output);
            }
            continue;
        }

        // Extract input string from event
        let input = match event {
            InputEvent::Line(s) | InputEvent::RawLine(s) => s,
            InputEvent::Tab => continue, // Already handled above
        };

        // Update last activity time for idle tracking
        {
            let mut conns = connections.lock().unwrap();
            if let Some(session) = conns.get_mut(&connection_id) {
                session.last_activity_time = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_secs() as i64;
            }
        }

        // Check for OLC description collection mode
        let olc_mode = {
            let conns = connections.lock().unwrap();
            conns.get(&connection_id)
                .and_then(|s| s.olc_mode.clone())
        };

        if olc_mode.as_deref() == Some("collecting_desc") {
            // Use shared editor command handler
            let result = {
                let mut conns = connections.lock().unwrap();
                if let Some(session) = conns.get_mut(&connection_id) {
                    handle_editor_command(&input, &mut session.olc_buffer, &mut session.olc_undo_buffer)
                } else {
                    EditorCommandResult::Cancel
                }
            };

            match result {
                EditorCommandResult::Handled(msg) => {
                    let _ = tx_client.send(msg);
                }
                EditorCommandResult::Save(content) => {
                    // Save buffer to room description
                    let edit_room_id = {
                        let conns = connections.lock().unwrap();
                        conns.get(&connection_id).and_then(|s| s.olc_edit_room)
                    };

                    if let Some(room_id) = edit_room_id {
                        let world = state.lock().unwrap();
                        if let Ok(Some(mut room)) = world.db.get_room_data(&room_id) {
                            room.description = content;
                            let _ = world.db.save_room_data(room);
                        }
                        drop(world);
                        let _ = tx_client.send("Description saved.\n".to_string());
                    } else {
                        let _ = tx_client.send("Error: No room being edited.\n".to_string());
                    }

                    // Clear OLC state
                    {
                        let mut conns = connections.lock().unwrap();
                        if let Some(session) = conns.get_mut(&connection_id) {
                            session.olc_mode = None;
                            session.olc_buffer.clear();
                            session.olc_edit_room = None;
                            session.olc_undo_buffer = None;
                        }
                    }
                    let prompt = build_prompt(&connection_id, &connections, &state);
                    let _ = tx_client.send(prompt);
                }
                EditorCommandResult::Cancel => {
                    // Clear OLC state
                    {
                        let mut conns = connections.lock().unwrap();
                        if let Some(session) = conns.get_mut(&connection_id) {
                            session.olc_mode = None;
                            session.olc_buffer.clear();
                            session.olc_edit_room = None;
                            session.olc_undo_buffer = None;
                        }
                    }
                    let _ = tx_client.send("Description editing cancelled.\n".to_string());
                    let prompt = build_prompt(&connection_id, &connections, &state);
                    let _ = tx_client.send(prompt);
                }
                EditorCommandResult::AppendText(text) => {
                    let mut conns = connections.lock().unwrap();
                    if let Some(session) = conns.get_mut(&connection_id) {
                        session.olc_undo_buffer = Some(session.olc_buffer.clone());
                        session.olc_buffer.push(text);
                    }
                }
            }
            continue;
        }

        // Check for OLC extra description collection mode
        if olc_mode.as_deref() == Some("collecting_extra_desc") {
            // Use shared editor command handler
            let result = {
                let mut conns = connections.lock().unwrap();
                if let Some(session) = conns.get_mut(&connection_id) {
                    handle_editor_command(&input, &mut session.olc_buffer, &mut session.olc_undo_buffer)
                } else {
                    EditorCommandResult::Cancel
                }
            };

            match result {
                EditorCommandResult::Handled(msg) => {
                    let _ = tx_client.send(msg);
                }
                EditorCommandResult::Save(content) => {
                    // Mode-specific save: add extra description to room
                    let (edit_room_id, keywords) = {
                        let conns = connections.lock().unwrap();
                        if let Some(session) = conns.get(&connection_id) {
                            (session.olc_edit_room, session.olc_extra_keywords.clone())
                        } else {
                            (None, Vec::new())
                        }
                    };

                    if let Some(room_id) = edit_room_id {
                        let world = state.lock().unwrap();
                        if let Ok(Some(mut room)) = world.db.get_room_data(&room_id) {
                            room.extra_descs.push(ExtraDesc {
                                keywords,
                                description: content,
                            });
                            let _ = world.db.save_room_data(room);
                        }
                        drop(world);
                        let _ = tx_client.send("Extra description saved.\n".to_string());
                    } else {
                        let _ = tx_client.send("Error: No room being edited.\n".to_string());
                    }

                    // Clear OLC mode and buffer
                    {
                        let mut conns = connections.lock().unwrap();
                        if let Some(session) = conns.get_mut(&connection_id) {
                            session.olc_mode = None;
                            session.olc_buffer.clear();
                            session.olc_edit_room = None;
                            session.olc_extra_keywords.clear();
                            session.olc_undo_buffer = None;
                        }
                    }
                }
                EditorCommandResult::Cancel => {
                    // Clear OLC mode and buffer
                    {
                        let mut conns = connections.lock().unwrap();
                        if let Some(session) = conns.get_mut(&connection_id) {
                            session.olc_mode = None;
                            session.olc_buffer.clear();
                            session.olc_edit_room = None;
                            session.olc_extra_keywords.clear();
                            session.olc_undo_buffer = None;
                        }
                    }
                    let _ = tx_client.send("Extra description editing cancelled.\n".to_string());
                }
                EditorCommandResult::AppendText(text) => {
                    // Append line to buffer (save undo first)
                    {
                        let mut conns = connections.lock().unwrap();
                        if let Some(session) = conns.get_mut(&connection_id) {
                            session.olc_undo_buffer = Some(session.olc_buffer.clone());
                            session.olc_buffer.push(text);
                        }
                    }
                    let _ = tx_client.send("Line added.\n".to_string());
                }
            }
            continue;
        }

        // Handle AI description confirmation mode
        if olc_mode.as_deref() == Some("ai_confirm") {
            let trimmed = input.trim().to_lowercase();

            if trimmed == "y" || trimmed == "yes" {
                // Accept the AI description
                let (response, target) = {
                    let mut conns = connections.lock().unwrap();
                    if let Some(session) = conns.get_mut(&connection_id) {
                        let response = session.pending_ai_response.take();
                        let target = session.pending_ai_target.take();
                        session.olc_mode = None;
                        session.pending_ai_request = None;
                        (response, target)
                    } else {
                        (None, None)
                    }
                };

                if let (Some(response), Some(target)) = (response, target) {
                    if response.success {
                        // Apply the description based on target type
                        let world = state.lock().unwrap();
                        let engine_ptr = &world.engine as *const Engine;
                        drop(world);

                        let engine = unsafe { &*engine_ptr };
                        let mut scope = rhai::Scope::new();
                        scope.push("connection_id", connection_id.to_string());

                        // Apply main description
                        if let Some(ref desc) = response.description {
                            match target.target_type {
                                claude::AiTargetType::Room => {
                                    scope.push("room_id", target.entity_id.to_string());
                                    scope.push("new_desc", desc.clone());
                                    let _ = engine.eval_with_scope::<()>(&mut scope,
                                        "set_room_description(room_id, new_desc);");
                                }
                                claude::AiTargetType::Mobile => {
                                    scope.push("mobile_id", target.entity_id.to_string());
                                    scope.push("new_desc", desc.clone());
                                    if target.field == "short_desc" {
                                        let _ = engine.eval_with_scope::<()>(&mut scope,
                                            "set_mobile_short_desc(mobile_id, new_desc);");
                                    } else {
                                        let _ = engine.eval_with_scope::<()>(&mut scope,
                                            "set_mobile_long_desc(mobile_id, new_desc);");
                                    }
                                }
                                claude::AiTargetType::Item => {
                                    scope.push("item_id", target.entity_id.to_string());
                                    scope.push("new_desc", desc.clone());
                                    if target.field == "short_desc" {
                                        let _ = engine.eval_with_scope::<()>(&mut scope,
                                            "set_item_short_desc(item_id, new_desc);");
                                    } else {
                                        let _ = engine.eval_with_scope::<()>(&mut scope,
                                            "set_item_long_desc(item_id, new_desc);");
                                    }
                                }
                            }
                        }

                        // Apply extra descriptions for rooms
                        let extra_count = response.extra_descs.len();
                        if matches!(target.target_type, claude::AiTargetType::Room) && extra_count > 0 {
                            for extra in &response.extra_descs {
                                let keywords_str = extra.keywords.join(" ");
                                scope.push("room_id", target.entity_id.to_string());
                                scope.push("keywords", keywords_str);
                                scope.push("extra_desc", extra.description.clone());
                                let _ = engine.eval_with_scope::<()>(&mut scope,
                                    "add_room_extra_desc(room_id, keywords, extra_desc);");
                            }
                            let _ = tx_client.send(format!("Description updated. {} extra description(s) added.\n", extra_count));
                        } else {
                            let _ = tx_client.send("Description updated.\n".to_string());
                        }
                    }
                }
                continue;
            } else if trimmed == "n" || trimmed == "no" {
                // Reject the AI description
                {
                    let mut conns = connections.lock().unwrap();
                    if let Some(session) = conns.get_mut(&connection_id) {
                        session.pending_ai_response = None;
                        session.pending_ai_target = None;
                        session.pending_ai_request = None;
                        session.olc_mode = None;
                    }
                }
                let _ = tx_client.send("Description rejected.\n".to_string());
                continue;
            } else {
                let _ = tx_client.send("Please enter 'y' to accept or 'n' to reject.\n".to_string());
                continue;
            }
        }

        // Handle character wizard modes (from create.rhai, login.rhai, or traits.rhai)
        debug!("OLC mode check: {:?}", olc_mode);
        if let Some(ref mode) = olc_mode {
            let script_path = if mode.starts_with("chargen_") || mode == "migration_prompt" {
                // Check wizard_data to determine which script started the wizard
                let is_migration = {
                    let conns = connections.lock().unwrap();
                    conns.get(&connection_id)
                        .and_then(|s| s.wizard_data.as_ref())
                        .map(|d| d.contains("migration=true"))
                        .unwrap_or(false)
                };
                if is_migration || mode == "migration_prompt" {
                    Some("scripts/commands/login.rhai".to_string())
                } else {
                    Some("scripts/commands/create.rhai".to_string())
                }
            } else if mode == "traits_select" {
                Some("scripts/commands/traits.rhai".to_string())
            } else {
                None
            };

            if let Some(script) = script_path {
                // Clone the AST and engine reference
                let (ast_opt, engine_ptr) = {
                    let world = state.lock().unwrap();
                    let ast = world.scripts.get(&script).cloned();
                    let engine_ptr = &world.engine as *const Engine;
                    (ast, engine_ptr)
                };

                if let Some(ast) = ast_opt {
                    let mut scope = rhai::Scope::new();
                    scope.set_value("args", input.clone());
                    scope.set_value("connection_id", connection_id.to_string());

                    let engine = unsafe { &*engine_ptr };
                    match engine.call_fn::<rhai::Dynamic>(
                        &mut scope,
                        &ast,
                        "run_command",
                        (input.clone(), connection_id.to_string(),),
                    ) {
                        Ok(output) => {
                            if output.is_string() {
                                let msg = output.into_string().unwrap();
                                if !msg.is_empty() {
                                    let _ = tx_client.send(msg);
                                }
                            }
                        }
                        Err(e) => {
                            let _ = tx_client.send(format!("Error: {}\n", e));
                        }
                    }
                    // Send prompt after wizard command execution
                    let prompt = build_prompt(&connection_id, &connections, &state);
                    let _ = tx_client.send(prompt);
                }
                continue;
            }
        }

        // Parse initial input
        let parts: Vec<&str> = input.splitn(2, ' ').collect();
        let raw_command = parts[0];
        let raw_args = parts.get(1).map_or("", |s| *s);

        // Empty input - just redisplay prompt (useful for checking stats while resting)
        if raw_command.is_empty() {
            let prompt = build_prompt(&connection_id, &connections, &state);
            let _ = tx_client.send(prompt);
            continue;
        }

        // Expand alias (may return semicolon-separated commands)
        let expanded = expand_alias(&connections, connection_id, raw_command, raw_args);

        // Split by semicolon and execute each command
        for single_cmd in expanded.split(';') {
            let single_cmd = single_cmd.trim();
            if single_cmd.is_empty() {
                continue;
            }

            let cmd_parts: Vec<&str> = single_cmd.splitn(2, ' ').collect();
            let command_name = cmd_parts[0];
            let args = cmd_parts.get(1).map_or("", |s| *s);

            // Check if user is logged in
            let is_logged_in = {
                let conns = connections.lock().unwrap();
                conns.get(&connection_id)
                    .map(|s| s.character.is_some())
                    .unwrap_or(false)
            };

            // Check access control
            // First, get command metadata access requirement
            let access_requirement = {
                let world = state.lock().unwrap();
                world.command_metadata.get(command_name).map(|m| m.access.clone())
            };

            // Then check permissions (separate lock to avoid deadlock)
            let access_allowed = if let Some(ref access) = access_requirement {
                let conns = connections.lock().unwrap();
                let (is_builder, is_admin) = conns.get(&connection_id)
                    .and_then(|s| s.character.as_ref())
                    .map(|c| (c.is_builder || c.is_admin, c.is_admin))  // Admin has builder access
                    .unwrap_or((false, false));
                drop(conns);

                match access.as_str() {
                    "guest" => !is_logged_in,
                    "any" => true,
                    "user" => is_logged_in,
                    "builder" => is_builder,  // Now includes admins
                    "admin" => is_admin,      // Only admins
                    _ => is_logged_in, // Default to requiring login
                }
            } else {
                is_logged_in // Unknown commands require login
            };

            if !access_allowed {
                let msg = match access_requirement.as_deref() {
                    Some("guest") => format!("Command '{}' is only available before logging in.\n", command_name),
                    Some("builder") => format!("Command '{}' requires builder access.\n", command_name),
                    Some("admin") => format!("Command '{}' requires admin access.\n", command_name),
                    _ if !is_logged_in => "You must log in first. Use 'login' or 'create'.\n".to_string(),
                    _ => format!("You don't have access to command '{}'.\n", command_name),
                };
                let _ = tx_client.send(msg);
                continue;
            }

            let script_path = format!("scripts/commands/{}.rhai", command_name);

            // Clone the AST and engine reference outside the lock to avoid deadlock
            // Rhai functions will need to lock state themselves
            let (ast_opt, engine_ptr) = {
                let world = state.lock().unwrap();
                let ast = world.scripts.get(&script_path).cloned();
                // SAFETY: The engine lives as long as World, and we only use it while state exists
                let engine_ptr = &world.engine as *const Engine;
                (ast, engine_ptr)
            };

            let result_message = if let Some(ast) = ast_opt {
                let mut scope = rhai::Scope::new();
                scope.set_value("args", args.to_string());
                scope.set_value("connection_id", connection_id.to_string());

                // SAFETY: Engine pointer is valid because state (and World) still exists
                let engine = unsafe { &*engine_ptr };
                match engine.call_fn::<rhai::Dynamic>(
                    &mut scope,
                    &ast,
                    "run_command",
                    (args.to_string(), connection_id.to_string(),),
                ) {
                    Ok(output) => {
                        if output.is_string() {
                            output.into_string().unwrap()
                        } else {
                            String::new()
                        }
                    }
                    Err(e) => format!("Error executing command {}: {}\n", command_name, e),
                }
            } else {
                format!("Unknown command: {}\n", command_name)
            };

            if !result_message.is_empty() {
                if let Err(e) = tx_client.send(result_message) {
                    error!("Failed to send error message to socket {}: {}", addr, e);
                    break;
                }
            }

            // Send prompt after command execution
            let prompt = build_prompt(&connection_id, &connections, &state);
            if let Err(e) = tx_client.send(prompt) {
                error!("Failed to send prompt to socket {}: {}", addr, e);
                break;
            }
        }
    }
    info!("Connection closed: {}", addr);

    // Clean up character on unexpected disconnect (TCP close without logout/quit)
    let cleanup_info = {
        let conns = connections.lock().unwrap();
        if let Some(session) = conns.get(&connection_id) {
            if let Some(ref character) = session.character {
                Some((character.clone(), character.current_room_id))
            } else {
                None
            }
        } else {
            None
        }
    };

    if let Some((character, room_id)) = cleanup_info {
        let char_name = character.name.clone();

        // Save character to database
        {
            let world = state.lock().unwrap();
            if let Err(e) = world.db.save_character_data(character) {
                error!("Failed to save {} on disconnect: {}", char_name, e);
            } else {
                info!("Saved character {} on disconnect", char_name);
            }
        }

        // Broadcast disconnect message to room
        broadcast_to_room(
            &connections,
            room_id,
            format!("{} has lost their connection.", char_name),
            Some(&char_name),
        );

        // Notify Matrix
        {
            let world = state.lock().unwrap();
            if let Some(ref matrix_tx) = world.matrix_sender {
                let _ = matrix_tx.send(matrix::MatrixMessage::PlayerLogout(char_name.clone()));
            }
        }

        info!("Cleaned up disconnected player: {}", char_name);
    }

    // Remove connection from map
    {
        let mut conns = connections.lock().unwrap();
        conns.remove(&connection_id);
    }
}

/// Character-mode read handler with telnet protocol support
///
/// This handler processes input byte-by-byte, handles telnet protocol
/// negotiation, and supports TAB completion. Falls back to line mode
/// if the client doesn't support character mode.
async fn handle_read_char_mode(
    mut reader: tokio::net::tcp::OwnedReadHalf,
    addr: std::net::SocketAddr,
    connection_id: ConnectionId,
    tx_input: mpsc::UnboundedSender<InputEvent>,
    connections: SharedConnections,
    tx_raw: mpsc::UnboundedSender<Vec<u8>>,
) {
    use crate::telnet::*;

    let mut parser = TelnetParser::new();
    let mut buf = [0u8; 256];
    let mut line_buffer = String::new();

    // Send initial telnet negotiations
    let negotiations = build_initial_negotiations();
    let _ = tx_raw.send(negotiations);

    // Set a timeout for negotiation response (500ms for quick fallback to line mode)
    let negotiation_deadline = tokio::time::Instant::now() + tokio::time::Duration::from_millis(500);
    let mut negotiation_complete = false;
    let mut char_mode_enabled = false;

    loop {
        // Check if connection was removed by script (e.g., quit command)
        let is_connected = {
            let conns = connections.lock().unwrap();
            conns.contains_key(&connection_id)
        };
        if !is_connected {
            info!("Read task: connection {} removed, exiting.", addr);
            break;
        }

        // Use timeout for initial negotiation period, then periodic timeout to check disconnect
        let read_result = if !negotiation_complete && tokio::time::Instant::now() < negotiation_deadline {
            match tokio::time::timeout(
                negotiation_deadline - tokio::time::Instant::now(),
                reader.read(&mut buf)
            ).await {
                Ok(result) => result,
                Err(_) => {
                    // Negotiation timeout - check if we got char mode
                    negotiation_complete = true;
                    let is_char_mode = {
                        let conns = connections.lock().unwrap();
                        conns.get(&connection_id)
                            .map(|s| s.telnet_state.char_mode)
                            .unwrap_or(false)
                    };
                    char_mode_enabled = is_char_mode;
                    if !char_mode_enabled {
                        info!("Client {} using line mode (no telnet negotiation response)", addr);
                    }
                    continue;
                }
            }
        } else {
            // Use timeout to periodically check if connection was removed
            match tokio::time::timeout(
                tokio::time::Duration::from_millis(100),
                reader.read(&mut buf)
            ).await {
                Ok(result) => result,
                Err(_) => continue, // Timeout - loop back to check if still connected
            }
        };

        match read_result {
            Ok(0) => break, // Connection closed
            Ok(n) => {
                let (data, events) = parser.process_bytes(&buf[..n]);
                let had_events = !events.is_empty();

                // Handle telnet events
                for event in events {
                    match event {
                        TelnetEvent::Will(opt) => {
                            // Track negotiation state
                            let mut conns = connections.lock().unwrap();
                            if let Some(session) = conns.get_mut(&connection_id) {
                                match opt {
                                    OPT_SGA => {
                                        // Send DO response for SGA
                                        let _ = tx_raw.send(respond_to_will(opt));
                                        session.telnet_state.suppress_go_ahead = true;
                                        // Both sides agreeing to SGA enables char mode
                                        if session.telnet_state.echo {
                                            session.telnet_state.char_mode = true;
                                            char_mode_enabled = true;
                                        }
                                    }
                                    OPT_MXP => {
                                        // Client supports MXP - auto-enable it
                                        // Don't send DO MXP response - we already sent it in initial negotiation
                                        // Sending it again would cause an infinite loop
                                        if !session.telnet_state.mxp_supported {
                                            session.telnet_state.mxp_supported = true;
                                            session.mxp_enabled = true;
                                            // Send MXP activation sequence
                                            let _ = tx_raw.send(build_mxp_activation());
                                            debug!("MXP auto-enabled for connection {}", connection_id);
                                        }
                                    }
                                    OPT_TTYPE => {
                                        // Client supports TTYPE - start MTTS 3-stage negotiation
                                        // We already sent DO TTYPE in initial negotiation
                                        if session.telnet_state.ttype_stage == 0 {
                                            session.telnet_state.ttype_stage = 1;
                                            let _ = tx_raw.send(build_ttype_send());
                                        }
                                    }
                                    _ => {
                                        // Send standard response for other options
                                        let _ = tx_raw.send(respond_to_will(opt));
                                    }
                                }
                            }
                        }
                        TelnetEvent::Wont(opt) => {
                            // Client refused option
                            let _ = tx_raw.send(build_negotiation(DONT, opt));
                        }
                        TelnetEvent::Do(opt) => {
                            let response = respond_to_do(opt);
                            let _ = tx_raw.send(response);

                            let mut conns = connections.lock().unwrap();
                            if let Some(session) = conns.get_mut(&connection_id) {
                                match opt {
                                    OPT_ECHO => {
                                        session.telnet_state.echo = true;
                                        if session.telnet_state.suppress_go_ahead {
                                            session.telnet_state.char_mode = true;
                                            char_mode_enabled = true;
                                        }
                                    }
                                    OPT_SGA => {
                                        session.telnet_state.suppress_go_ahead = true;
                                    }
                                    _ => {}
                                }
                            }
                        }
                        TelnetEvent::Dont(opt) => {
                            // Client refused our option
                            let _ = tx_raw.send(build_negotiation(WONT, opt));
                        }
                        TelnetEvent::Subnegotiation(opt, subneg_data) => {
                            match opt {
                                OPT_NAWS => {
                                    if let Some((width, height)) = parse_naws(&subneg_data) {
                                        let mut conns = connections.lock().unwrap();
                                        if let Some(session) = conns.get_mut(&connection_id) {
                                            session.telnet_state.window_width = width;
                                            session.telnet_state.window_height = height;
                                        }
                                    }
                                }
                                OPT_TTYPE => {
                                    // Handle TTYPE IS response (MTTS 3-stage negotiation)
                                    if let Some(ttype_str) = parse_ttype_is(&subneg_data) {
                                        let mut conns = connections.lock().unwrap();
                                        if let Some(session) = conns.get_mut(&connection_id) {
                                            let stage = session.telnet_state.ttype_stage;
                                            match stage {
                                                1 => {
                                                    // Stage 1: Client name (e.g., "MUDLET")
                                                    session.telnet_state.client_name = Some(ttype_str);
                                                    session.telnet_state.ttype_stage = 2;
                                                    let _ = tx_raw.send(build_ttype_send());
                                                }
                                                2 => {
                                                    // Stage 2: Terminal type (e.g., "XTERM-256COLOR")
                                                    session.telnet_state.terminal_type = Some(ttype_str);
                                                    session.telnet_state.ttype_stage = 3;
                                                    let _ = tx_raw.send(build_ttype_send());
                                                }
                                                3 => {
                                                    // Stage 3: MTTS bitvector or repeated value
                                                    if let Some(flags) = parse_mtts_flags(&ttype_str) {
                                                        session.telnet_state.mtts_flags = flags;
                                                        session.telnet_state.utf8_supported = (flags & MTTS_UTF8) != 0;
                                                    }
                                                    session.telnet_state.ttype_stage = 4; // Complete

                                                    // Log client capabilities
                                                    let ts = &session.telnet_state;
                                                    info!(
                                                        "Client {} capabilities - name: {:?}, type: {:?}, MTTS: {} (UTF-8: {}, ANSI: {}, 256color: {})",
                                                        connection_id,
                                                        ts.client_name,
                                                        ts.terminal_type,
                                                        ts.mtts_flags,
                                                        ts.utf8_supported,
                                                        (ts.mtts_flags & MTTS_ANSI) != 0,
                                                        (ts.mtts_flags & MTTS_256_COLORS) != 0,
                                                    );
                                                }
                                                _ => {}
                                            }
                                        }
                                    }
                                }
                                _ => {}
                            }
                        }
                        _ => {}
                    }
                }

                // Mark negotiation complete after first data or if we got responses
                if !negotiation_complete && (!data.is_empty() || had_events) {
                    let is_char_mode = {
                        let conns = connections.lock().unwrap();
                        conns.get(&connection_id)
                            .map(|s| s.telnet_state.char_mode)
                            .unwrap_or(false)
                    };
                    char_mode_enabled = is_char_mode;
                    negotiation_complete = true;
                }

                // Process data bytes
                for byte in data {
                    if char_mode_enabled {
                        // Character-by-character mode with escape sequence parsing
                        // Parse byte through escape sequence state machine
                        let key_event = {
                            let mut conns = connections.lock().unwrap();
                            if let Some(session) = conns.get_mut(&connection_id) {
                                let (new_state, event) = telnet::parse_key_byte(
                                    session.escape_state.clone(),
                                    byte,
                                );
                                session.escape_state = new_state;
                                event
                            } else {
                                None
                            }
                        };

                        // Handle the key event
                        if let Some(key) = key_event {
                            use telnet::KeyEvent;
                            match key {
                                KeyEvent::Tab => {
                                    let _ = tx_input.send(InputEvent::Tab);
                                }
                                KeyEvent::Enter => {
                                    // Submit line and add to history
                                    let line = {
                                        let mut conns = connections.lock().unwrap();
                                        if let Some(session) = conns.get_mut(&connection_id) {
                                            let line = session.input_buffer.trim().to_string();
                                            // Add to history if non-empty and different from last
                                            if !line.is_empty() {
                                                let should_add = session.command_history
                                                    .front()
                                                    .map(|last| last != &line)
                                                    .unwrap_or(true);
                                                if should_add {
                                                    session.command_history.push_front(line.clone());
                                                    if session.command_history.len() > telnet::MAX_HISTORY_SIZE {
                                                        session.command_history.pop_back();
                                                    }
                                                }
                                            }
                                            session.input_buffer.clear();
                                            session.cursor_pos = 0;
                                            session.history_index = None;
                                            session.saved_input.clear();
                                            line
                                        } else {
                                            line_buffer.trim().to_string()
                                        }
                                    };
                                    line_buffer.clear();
                                    let _ = tx_raw.send(b"\r\n".to_vec());
                                    let _ = tx_input.send(InputEvent::Line(line));
                                }
                                KeyEvent::Backspace => {
                                    handle_readline_backspace(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::Delete => {
                                    handle_readline_delete(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::ArrowUp => {
                                    handle_readline_history_up(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::ArrowDown => {
                                    handle_readline_history_down(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::ArrowLeft => {
                                    handle_readline_cursor_left(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::ArrowRight => {
                                    handle_readline_cursor_right(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::Home | KeyEvent::CtrlA => {
                                    handle_readline_cursor_home(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::End | KeyEvent::CtrlE => {
                                    handle_readline_cursor_end(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::CtrlW => {
                                    handle_readline_delete_word(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::CtrlU => {
                                    handle_readline_delete_to_start(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::CtrlK => {
                                    handle_readline_delete_to_end(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::CtrlC => {
                                    handle_readline_cancel_line(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::CtrlL => {
                                    handle_readline_redraw_screen(&connections, connection_id, &tx_raw);
                                }
                                KeyEvent::CtrlD => {
                                    // Logout on empty line
                                    let should_logout = {
                                        let conns = connections.lock().unwrap();
                                        conns.get(&connection_id)
                                            .map(|s| s.input_buffer.is_empty())
                                            .unwrap_or(false)
                                    };
                                    if should_logout {
                                        let _ = tx_input.send(InputEvent::Line("quit".to_string()));
                                    }
                                }
                                KeyEvent::Char(c) => {
                                    handle_readline_insert_char(&connections, connection_id, c, &tx_raw);
                                    line_buffer.push(c);
                                }
                                KeyEvent::Unknown => {
                                    // Ignore unknown keys
                                }
                            }
                        }
                    } else {
                        // Line mode - accumulate until newline
                        match byte {
                            CHAR_CR => {}
                            CHAR_LF => {
                                let line = line_buffer.trim().to_string();
                                line_buffer.clear();
                                let _ = tx_input.send(InputEvent::RawLine(line));
                            }
                            _ => {
                                if let Some(c) = char::from_u32(byte as u32) {
                                    line_buffer.push(c);
                                }
                            }
                        }
                    }
                }
            }
            Err(e) => {
                error!("Failed to read from socket {}: {}", addr, e);
                break;
            }
        }
    }

    info!("Client {} disconnected (char mode read handler).", addr);
}

// New helper function to handle writing to client
// Accepts both String messages and raw byte arrays for telnet negotiation
async fn handle_write_with_raw(
    mut writer: tokio::net::tcp::OwnedWriteHalf,
    addr: std::net::SocketAddr,
    mut rx_client: mpsc::UnboundedReceiver<String>,
    mut rx_raw: mpsc::UnboundedReceiver<Vec<u8>>,
) {
    loop {
        tokio::select! {
            Some(msg) = rx_client.recv() => {
                // Convert \n to \r\n for proper telnet line endings
                // First normalize any existing \r\n to \n, then convert all \n to \r\n
                let telnet_msg = msg.replace("\r\n", "\n").replace("\n", "\r\n");
                if let Err(e) = writer.write_all(telnet_msg.as_bytes()).await {
                    error!("Failed to write to socket {}: {}", addr, e);
                    break;
                }
            }
            Some(raw) = rx_raw.recv() => {
                if let Err(e) = writer.write_all(&raw).await {
                    error!("Failed to write raw bytes to socket {}: {}", addr, e);
                    break;
                }
            }
            else => break,
        }
    }
    info!("Client {} disconnected (write handler).", addr);
}

// ============================================================================
// Readline-like input handling helper functions
// ============================================================================

fn handle_readline_backspace(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        if session.cursor_pos > 0 {
            let char_count = session.input_buffer.chars().count();

            if session.cursor_pos >= char_count {
                // Cursor at end - simple case, but handle variable width chars
                if let Some(ch) = session.input_buffer.pop() {
                    let char_width = telnet::display_width(&ch.to_string());
                    session.cursor_pos -= 1;
                    // Move left, overwrite with spaces, move left again
                    let mut output = Vec::new();
                    output.extend(telnet::ansi::cursor_left(char_width));
                    output.extend(vec![b' '; char_width]);
                    output.extend(telnet::ansi::cursor_left(char_width));
                    let _ = tx_raw.send(output);
                }
            } else {
                // Cursor in middle - need to redraw
                let chars: Vec<char> = session.input_buffer.chars().collect();
                let remove_idx = session.cursor_pos - 1;
                let mut new_buffer = String::new();
                for (i, c) in chars.iter().enumerate() {
                    if i != remove_idx {
                        new_buffer.push(*c);
                    }
                }
                session.input_buffer = new_buffer;
                session.cursor_pos -= 1;

                // Redraw from cursor position
                let output = telnet::redraw_input_line("> ", &session.input_buffer, session.cursor_pos);
                let _ = tx_raw.send(output);
            }
            // Reset history navigation on edit
            session.history_index = None;
        }
    }
}

fn handle_readline_delete(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        let char_count = session.input_buffer.chars().count();
        if session.cursor_pos < char_count {
            // Remove character at cursor position
            let chars: Vec<char> = session.input_buffer.chars().collect();
            let mut new_buffer = String::new();
            for (i, c) in chars.iter().enumerate() {
                if i != session.cursor_pos {
                    new_buffer.push(*c);
                }
            }
            session.input_buffer = new_buffer;

            // Redraw from cursor position
            let output = telnet::redraw_input_line("> ", &session.input_buffer, session.cursor_pos);
            let _ = tx_raw.send(output);

            // Reset history navigation on edit
            session.history_index = None;
        }
    }
}

fn handle_readline_cursor_left(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        if session.cursor_pos > 0 {
            // Get the character we're moving over and its display width
            if let Some(ch) = session.input_buffer.chars().nth(session.cursor_pos - 1) {
                let char_width = telnet::display_width(&ch.to_string());
                session.cursor_pos -= 1;
                let _ = tx_raw.send(telnet::ansi::cursor_left(char_width));
            }
        }
    }
}

fn handle_readline_cursor_right(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        let char_count = session.input_buffer.chars().count();
        if session.cursor_pos < char_count {
            // Get the character we're moving over and its display width
            if let Some(ch) = session.input_buffer.chars().nth(session.cursor_pos) {
                let char_width = telnet::display_width(&ch.to_string());
                session.cursor_pos += 1;
                let _ = tx_raw.send(telnet::ansi::cursor_right(char_width));
            }
        }
    }
}

fn handle_readline_cursor_home(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        if session.cursor_pos > 0 {
            // Calculate display width of characters from start to cursor
            let cols_to_move = telnet::display_width_up_to(&session.input_buffer, session.cursor_pos);
            let _ = tx_raw.send(telnet::ansi::cursor_left(cols_to_move));
            session.cursor_pos = 0;
        }
    }
}

fn handle_readline_cursor_end(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        let char_count = session.input_buffer.chars().count();
        if session.cursor_pos < char_count {
            // Calculate display width of characters from cursor to end
            let chars_after: String = session.input_buffer.chars().skip(session.cursor_pos).collect();
            let cols_to_move = telnet::display_width(&chars_after);
            let _ = tx_raw.send(telnet::ansi::cursor_right(cols_to_move));
            session.cursor_pos = char_count;
        }
    }
}

fn handle_readline_history_up(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        if session.command_history.is_empty() {
            return;
        }

        let new_index = match session.history_index {
            None => {
                // Save current input before navigating
                session.saved_input = session.input_buffer.clone();
                Some(0)
            }
            Some(idx) if idx + 1 < session.command_history.len() => Some(idx + 1),
            Some(_) => return, // Already at oldest
        };

        if let Some(idx) = new_index {
            session.history_index = Some(idx);
            let history_line = session.command_history[idx].clone();

            // Clear current line and display history entry
            let output = telnet::redraw_input_line("> ", &history_line, history_line.chars().count());
            session.input_buffer = history_line;
            session.cursor_pos = session.input_buffer.chars().count();
            let _ = tx_raw.send(output);
        }
    }
}

fn handle_readline_history_down(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        match session.history_index {
            None => return, // Already at newest
            Some(0) => {
                // Return to saved input
                session.history_index = None;
                let restored = session.saved_input.clone();
                let output = telnet::redraw_input_line("> ", &restored, restored.chars().count());
                session.input_buffer = restored;
                session.cursor_pos = session.input_buffer.chars().count();
                let _ = tx_raw.send(output);
            }
            Some(idx) => {
                session.history_index = Some(idx - 1);
                let history_line = session.command_history[idx - 1].clone();
                let output = telnet::redraw_input_line("> ", &history_line, history_line.chars().count());
                session.input_buffer = history_line;
                session.cursor_pos = session.input_buffer.chars().count();
                let _ = tx_raw.send(output);
            }
        }
    }
}

fn handle_readline_delete_word(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        if session.cursor_pos == 0 {
            return;
        }

        // Find word boundary (skip trailing spaces, then skip word chars)
        let chars: Vec<char> = session.input_buffer.chars().collect();
        let mut new_pos = session.cursor_pos;

        // Skip spaces backward
        while new_pos > 0 && chars[new_pos - 1].is_whitespace() {
            new_pos -= 1;
        }
        // Skip word backward
        while new_pos > 0 && !chars[new_pos - 1].is_whitespace() {
            new_pos -= 1;
        }

        if new_pos < session.cursor_pos {
            // Remove characters from new_pos to cursor_pos
            let mut new_buffer = String::new();
            for (i, c) in chars.iter().enumerate() {
                if i < new_pos || i >= session.cursor_pos {
                    new_buffer.push(*c);
                }
            }
            session.input_buffer = new_buffer;
            session.cursor_pos = new_pos;

            // Redraw line
            let output = telnet::redraw_input_line("> ", &session.input_buffer, session.cursor_pos);
            let _ = tx_raw.send(output);

            // Reset history navigation on edit
            session.history_index = None;
        }
    }
}

fn handle_readline_delete_to_start(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        if session.cursor_pos > 0 {
            let chars: Vec<char> = session.input_buffer.chars().collect();
            session.input_buffer = chars[session.cursor_pos..].iter().collect();
            session.cursor_pos = 0;

            let output = telnet::redraw_input_line("> ", &session.input_buffer, 0);
            let _ = tx_raw.send(output);

            // Reset history navigation on edit
            session.history_index = None;
        }
    }
}

fn handle_readline_delete_to_end(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        let char_count = session.input_buffer.chars().count();
        if session.cursor_pos < char_count {
            let chars: Vec<char> = session.input_buffer.chars().collect();
            session.input_buffer = chars[..session.cursor_pos].iter().collect();

            // Clear to end of line
            let _ = tx_raw.send(telnet::ansi::clear_to_eol());

            // Reset history navigation on edit
            session.history_index = None;
        }
    }
}

fn handle_readline_cancel_line(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        // Display ^C and start new line
        let _ = tx_raw.send(b"^C\r\n> ".to_vec());
        session.input_buffer.clear();
        session.cursor_pos = 0;
        session.history_index = None;
        session.saved_input.clear();
    }
}

fn handle_readline_redraw_screen(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let conns = connections.lock().unwrap();
    if let Some(session) = conns.get(&connection_id) {
        // Clear screen and redraw
        let mut output = b"\x1b[2J\x1b[H".to_vec(); // Clear screen, home cursor
        output.extend(telnet::redraw_input_line("> ", &session.input_buffer, session.cursor_pos));
        let _ = tx_raw.send(output);
    }
}

fn handle_readline_insert_char(
    connections: &SharedConnections,
    connection_id: ConnectionId,
    c: char,
    tx_raw: &mpsc::UnboundedSender<Vec<u8>>,
) {
    let mut conns = connections.lock().unwrap();
    if let Some(session) = conns.get_mut(&connection_id) {
        let char_count = session.input_buffer.chars().count();

        if session.cursor_pos >= char_count {
            // Append at end (simple case)
            session.input_buffer.push(c);
            session.cursor_pos += 1;
            let mut buf = [0u8; 4];
            let bytes = c.encode_utf8(&mut buf);
            let _ = tx_raw.send(bytes.as_bytes().to_vec());
        } else {
            // Insert in middle
            let chars: Vec<char> = session.input_buffer.chars().collect();
            let mut new_buffer = String::new();
            for (i, ch) in chars.iter().enumerate() {
                if i == session.cursor_pos {
                    new_buffer.push(c);
                }
                new_buffer.push(*ch);
            }
            session.input_buffer = new_buffer;
            session.cursor_pos += 1;

            // Redraw from insertion point
            let output = telnet::redraw_input_line("> ", &session.input_buffer, session.cursor_pos);
            let _ = tx_raw.send(output);
        }

        // Reset history navigation on edit
        session.history_index = None;
    }
}

pub async fn run_server(
    state: SharedState,
    listener: TcpListener,
    shutdown_rx: tokio::sync::oneshot::Receiver<()>,
) {
    tokio::select! {
        _ = async {
            loop {
                let (socket, addr) = listener.accept().await.unwrap();
                info!("New connection: {}", addr);
                let state = state.clone();
                let connection_id = Uuid::new_v4();
                tokio::spawn(async move {
                    handle_connection(socket, addr, state, connection_id).await;
                });
            }
        } => {},
        _ = shutdown_rx => {
            info!("Shutting down server...");
        }
    }
}



pub fn load_command_metadata() -> Result<HashMap<String, CommandMeta>> {
    let content = std::fs::read_to_string("scripts/commands.json")?;
    let metadata: HashMap<String, CommandMeta> = serde_json::from_str(&content)?;
    Ok(metadata)
}

/// Load game data (classes, traits, race suggestions) from scripts/data/*.json
pub fn load_game_data(state: SharedState) -> Result<()> {
    let mut world = state.lock().unwrap();

    // Load class definitions
    match std::fs::read_to_string("scripts/data/classes.json") {
        Ok(content) => {
            match serde_json::from_str(&content) {
                Ok(classes) => {
                    world.class_definitions = classes;
                    info!("Loaded {} class definitions", world.class_definitions.len());
                }
                Err(e) => {
                    error!("Failed to parse classes.json: {}", e);
                }
            }
        }
        Err(_) => {
            info!("No classes.json found, using default 'unemployed' class");
            // Insert default "unemployed" class
            world.class_definitions.insert("unemployed".to_string(), ClassDefinition {
                id: "unemployed".to_string(),
                name: "Unemployed".to_string(),
                description: "No particular profession.".to_string(),
                starting_skills: vec![],
                stat_bonuses: HashMap::new(),
                available: true,
            });
        }
    }

    // Load trait definitions
    match std::fs::read_to_string("scripts/data/traits.json") {
        Ok(content) => {
            match serde_json::from_str(&content) {
                Ok(traits) => {
                    world.trait_definitions = traits;
                    info!("Loaded {} trait definitions", world.trait_definitions.len());
                }
                Err(e) => {
                    error!("Failed to parse traits.json: {}", e);
                }
            }
        }
        Err(_) => {
            info!("No traits.json found, starting with no traits");
        }
    }

    // Load race suggestions
    match std::fs::read_to_string("scripts/data/race_suggestions.json") {
        Ok(content) => {
            match serde_json::from_str::<serde_json::Value>(&content) {
                Ok(data) => {
                    if let Some(races) = data.get("races").and_then(|r| r.as_array()) {
                        world.race_suggestions = races.iter()
                            .filter_map(|r| serde_json::from_value(r.clone()).ok())
                            .collect();
                        info!("Loaded {} race suggestions", world.race_suggestions.len());
                    }
                }
                Err(e) => {
                    error!("Failed to parse race_suggestions.json: {}", e);
                }
            }
        }
        Err(_) => {
            info!("No race_suggestions.json found, using defaults");
            // Add some default race suggestions
            world.race_suggestions = vec![
                RaceSuggestion { name: "Human".to_string(), description: "Versatile and adaptable.".to_string() },
            ];
        }
    }

    // Load recipes from database (created via recedit command)
    match world.db.list_all_recipes() {
        Ok(recipes) => {
            for recipe in recipes {
                world.recipes.insert(recipe.id.clone(), recipe);
            }
            info!("Loaded {} recipes from database", world.recipes.len());
        }
        Err(e) => {
            error!("Failed to load recipes from database: {}", e);
        }
    }

    Ok(())
}

pub fn load_scripts(state: SharedState) -> Result<()> {
    let mut world = state.lock().unwrap();

    for entry in glob("scripts/**/*.rhai")? {
        match entry {
            Ok(path) => {
                let path_str = path.to_string_lossy().to_string();
                match world.engine.compile_file(path.clone()) {
                    Ok(ast) => {
                        info!("Loaded script: {}", path_str);
                        world.scripts.insert(path_str, ast);
                    }
                    Err(e) => {
                        error!("Failed to compile script {}: {}", path_str, e);
                    }
                }
            }
            Err(e) => {
                error!("Glob error: {}", e);
            }
        }
    }

    Ok(())
}

pub fn watch_scripts(state: SharedState) {
    let (tx, mut rx) = mpsc::channel(1);

    tokio::spawn(async move {
        let mut watcher = notify::recommended_watcher(move |res| {
            tx.blocking_send(res).unwrap();
        })
        .unwrap();

        watcher
            .watch(Path::new("scripts/"), RecursiveMode::Recursive)
            .unwrap();

        info!("Watching scripts directory for changes...");

        while let Some(res) = rx.recv().await {
            match res {
                Ok(event) => {
                    if let notify::EventKind::Modify(_) = event.kind {
                        for path in event.paths {
                            // Normalize to relative path to match how scripts are loaded and looked up
                            let path_str = path
                                .strip_prefix(std::env::current_dir().unwrap_or_default())
                                .unwrap_or(&path)
                                .to_string_lossy()
                                .to_string();
                            if path_str.ends_with(".rhai") {
                                info!("Script changed: {}, recompiling.", path_str);
                                let mut world = state.lock().unwrap();
                                match world.engine.compile_file(path.clone()) {
                                    Ok(ast) => {
                                        world.scripts.insert(path_str.to_string(), ast);
                                        info!("Script recompiled successfully: {}", path_str);
                                    }
                                    Err(e) => {
                                        error!("Failed to recompile script {}: {}", path_str, e);
                                    }
                                }
                            }
                        }
                    }
                }
                Err(e) => error!("Watch error: {:?}", e),
            }
        }
    });
}