// src/script/mobiles.rs
// Mobile/NPC system functions

use rhai::Engine;
use std::sync::Arc;
use crate::db::Db;
use crate::{MobileData, MobileFlags, DamageType};

/// Register mobile-related functions
pub fn register(engine: &mut Engine, db: Arc<Db>) {
    // ========== Mobile/NPC System ==========

    // Register MobileFlags type with getters/setters
    engine.register_type_with_name::<MobileFlags>("MobileFlags")
        .register_get("aggressive", |f: &mut MobileFlags| f.aggressive)
        .register_set("aggressive", |f: &mut MobileFlags, v: bool| f.aggressive = v)
        .register_get("sentinel", |f: &mut MobileFlags| f.sentinel)
        .register_set("sentinel", |f: &mut MobileFlags, v: bool| f.sentinel = v)
        .register_get("scavenger", |f: &mut MobileFlags| f.scavenger)
        .register_set("scavenger", |f: &mut MobileFlags, v: bool| f.scavenger = v)
        .register_get("shopkeeper", |f: &mut MobileFlags| f.shopkeeper)
        .register_set("shopkeeper", |f: &mut MobileFlags, v: bool| f.shopkeeper = v)
        .register_get("no_attack", |f: &mut MobileFlags| f.no_attack)
        .register_set("no_attack", |f: &mut MobileFlags, v: bool| f.no_attack = v)
        .register_get("healer", |f: &mut MobileFlags| f.healer)
        .register_set("healer", |f: &mut MobileFlags, v: bool| f.healer = v);

    // Register MobileData type with getters
    engine.register_type_with_name::<MobileData>("MobileData")
        .register_get("id", |m: &mut MobileData| m.id.to_string())
        .register_get("name", |m: &mut MobileData| m.name.clone())
        .register_set("name", |m: &mut MobileData, v: String| m.name = v)
        .register_get("short_desc", |m: &mut MobileData| m.short_desc.clone())
        .register_set("short_desc", |m: &mut MobileData, v: String| m.short_desc = v)
        .register_get("long_desc", |m: &mut MobileData| m.long_desc.clone())
        .register_set("long_desc", |m: &mut MobileData, v: String| m.long_desc = v)
        .register_get("keywords", |m: &mut MobileData| {
            m.keywords.iter().map(|s| rhai::Dynamic::from(s.clone())).collect::<Vec<_>>()
        })
        .register_get("current_room_id", |m: &mut MobileData| {
            m.current_room_id.map(|u| u.to_string()).unwrap_or_default()
        })
        .register_get("is_prototype", |m: &mut MobileData| m.is_prototype)
        .register_get("vnum", |m: &mut MobileData| m.vnum.clone())
        .register_get("level", |m: &mut MobileData| m.level)
        .register_get("max_hp", |m: &mut MobileData| m.max_hp as i64)
        .register_get("current_hp", |m: &mut MobileData| m.current_hp as i64)
        .register_get("hp", |m: &mut MobileData| m.current_hp as i64)
        .register_set("hp", |m: &mut MobileData, val: i64| m.current_hp = val as i32)
        .register_get("max_stamina", |m: &mut MobileData| m.max_stamina as i64)
        .register_get("current_stamina", |m: &mut MobileData| m.current_stamina as i64)
        .register_get("stamina", |m: &mut MobileData| m.current_stamina as i64)
        .register_set("stamina", |m: &mut MobileData, val: i64| m.current_stamina = val as i32)
        .register_get("damage_dice", |m: &mut MobileData| m.damage_dice.clone())
        .register_get("damage_type", |m: &mut MobileData| m.damage_type.to_display_string().to_string())
        .register_get("armor_class", |m: &mut MobileData| m.armor_class as i64)
        .register_get("stat_str", |m: &mut MobileData| m.stat_str as i64)
        .register_get("stat_dex", |m: &mut MobileData| m.stat_dex as i64)
        .register_get("stat_con", |m: &mut MobileData| m.stat_con as i64)
        .register_get("stat_int", |m: &mut MobileData| m.stat_int as i64)
        .register_get("stat_wis", |m: &mut MobileData| m.stat_wis as i64)
        .register_get("stat_cha", |m: &mut MobileData| m.stat_cha as i64)
        .register_get("flags", |m: &mut MobileData| m.flags.clone())
        .register_get("shop_stock", |m: &mut MobileData| {
            m.shop_stock.iter().map(|s| rhai::Dynamic::from(s.clone())).collect::<Vec<_>>()
        })
        .register_get("shop_buy_rate", |m: &mut MobileData| m.shop_buy_rate as i64)
        .register_get("shop_sell_rate", |m: &mut MobileData| m.shop_sell_rate as i64)
        .register_get("healer_type", |m: &mut MobileData| m.healer_type.clone())
        .register_get("healing_free", |m: &mut MobileData| m.healing_free)
        .register_get("healing_cost_multiplier", |m: &mut MobileData| m.healing_cost_multiplier as i64);

    // new_mobile(name) -> MobileData
    engine.register_fn("new_mobile", |name: String| {
        MobileData::new(name)
    });

    // get_mobile_data(mobile_id) -> MobileData or ()
    let cloned_db = db.clone();
    engine.register_fn("get_mobile_data", move |mobile_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.get_mobile_data(&uuid) {
                Ok(Some(mobile)) => rhai::Dynamic::from(mobile),
                _ => rhai::Dynamic::UNIT,
            }
        } else {
            rhai::Dynamic::UNIT
        }
    });

    // save_mobile_data(mobile) -> bool
    let cloned_db = db.clone();
    engine.register_fn("save_mobile_data", move |mobile: MobileData| {
        cloned_db.save_mobile_data(mobile).is_ok()
    });

    // delete_mobile(mobile_id) -> bool
    let cloned_db = db.clone();
    engine.register_fn("delete_mobile", move |mobile_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            cloned_db.delete_mobile(&uuid).unwrap_or(false)
        } else {
            false
        }
    });

    // list_all_mobiles() -> Array of MobileData
    let cloned_db = db.clone();
    engine.register_fn("list_all_mobiles", move || {
        cloned_db.list_all_mobiles()
            .unwrap_or_default()
            .into_iter()
            .map(rhai::Dynamic::from)
            .collect::<Vec<_>>()
    });

    // get_mobiles_in_room(room_id) -> Array of MobileData
    let cloned_db = db.clone();
    engine.register_fn("get_mobiles_in_room", move |room_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&room_id) {
            cloned_db.get_mobiles_in_room(&uuid)
                .unwrap_or_default()
                .into_iter()
                .map(rhai::Dynamic::from)
                .collect::<Vec<_>>()
        } else {
            vec![]
        }
    });

    // get_mobile_by_vnum(vnum) -> MobileData or ()
    let cloned_db = db.clone();
    engine.register_fn("get_mobile_by_vnum", move |vnum: String| {
        match cloned_db.get_mobile_by_vnum(&vnum) {
            Ok(Some(mobile)) => rhai::Dynamic::from(mobile),
            _ => rhai::Dynamic::UNIT,
        }
    });

    // search_mobiles(keyword) -> Array of MobileData
    let cloned_db = db.clone();
    engine.register_fn("search_mobiles", move |keyword: String| {
        cloned_db.search_mobiles(&keyword)
            .unwrap_or_default()
            .into_iter()
            .map(rhai::Dynamic::from)
            .collect::<Vec<_>>()
    });

    // move_mobile_to_room(mobile_id, room_id) -> bool
    let cloned_db = db.clone();
    engine.register_fn("move_mobile_to_room", move |mobile_id: String, room_id: String| {
        let mobile_uuid = uuid::Uuid::parse_str(&mobile_id).ok();
        let room_uuid = uuid::Uuid::parse_str(&room_id).ok();
        match (mobile_uuid, room_uuid) {
            (Some(mid), Some(rid)) => cloned_db.move_mobile_to_room(&mid, &rid).unwrap_or(false),
            _ => false,
        }
    });

    // spawn_mobile_from_prototype(vnum) -> MobileData or ()
    let cloned_db = db.clone();
    engine.register_fn("spawn_mobile_from_prototype", move |vnum: String| -> rhai::Dynamic {
        match cloned_db.spawn_mobile_from_prototype(&vnum) {
            Ok(Some(mobile)) => rhai::Dynamic::from(mobile),
            _ => rhai::Dynamic::UNIT,
        }
    });

    // refresh_mobile_from_prototype(mobile_id) -> MobileData or ()
    let cloned_db = db.clone();
    engine.register_fn("refresh_mobile_from_prototype", move |mobile_id: String| -> rhai::Dynamic {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.refresh_mobile_from_prototype(&uuid) {
                Ok(Some(mobile)) => rhai::Dynamic::from(mobile),
                _ => rhai::Dynamic::UNIT,
            }
        } else {
            rhai::Dynamic::UNIT
        }
    });

    // get_mobile_instances_by_vnum(vnum) -> Array of MobileData
    let cloned_db = db.clone();
    engine.register_fn("get_mobile_instances_by_vnum", move |vnum: String| {
        cloned_db.get_mobile_instances_by_vnum(&vnum)
            .unwrap_or_default()
            .into_iter()
            .map(rhai::Dynamic::from)
            .collect::<Vec<_>>()
    });

    // set_mobile_short_desc(mobile_id, desc) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_short_desc", move |mobile_id: String, desc: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.short_desc = desc;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_long_desc(mobile_id, desc) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_long_desc", move |mobile_id: String, desc: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.long_desc = desc;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_keywords(mobile_id, keywords_array) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_keywords", move |mobile_id: String, keywords: rhai::Array| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.keywords = keywords.into_iter()
                    .filter_map(|d| d.try_cast::<String>())
                    .map(|s| s.to_lowercase())
                    .collect();
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_stat(mobile_id, stat_name, value) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_stat", move |mobile_id: String, stat_name: String, value: i64| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                match stat_name.to_lowercase().as_str() {
                    "str" | "strength" => mobile.stat_str = value as i32,
                    "dex" | "dexterity" => mobile.stat_dex = value as i32,
                    "con" | "constitution" => mobile.stat_con = value as i32,
                    "int" | "intelligence" => mobile.stat_int = value as i32,
                    "wis" | "wisdom" => mobile.stat_wis = value as i32,
                    "cha" | "charisma" => mobile.stat_cha = value as i32,
                    _ => return false,
                }
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_level(mobile_id, level) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_level", move |mobile_id: String, level: i64| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.level = level as i32;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_hp(mobile_id, max_hp) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_hp", move |mobile_id: String, max_hp: i64| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.max_hp = max_hp as i32;
                mobile.current_hp = max_hp as i32; // Set current HP to max
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_damage(mobile_id, damage_dice) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_damage", move |mobile_id: String, damage_dice: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.damage_dice = damage_dice;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_damage_type(mobile_id, damage_type_str) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_damage_type", move |mobile_id: String, damage_type_str: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                if let Some(dt) = DamageType::from_str(&damage_type_str) {
                    mobile.damage_type = dt;
                    return cloned_db.save_mobile_data(mobile).is_ok();
                }
            }
        }
        false
    });

    // set_mobile_ac(mobile_id, armor_class) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_ac", move |mobile_id: String, armor_class: i64| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.armor_class = armor_class as i32;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_flag(mobile_id, flag_name, value) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_flag", move |mobile_id: String, flag_name: String, value: bool| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                match flag_name.to_lowercase().as_str() {
                    "aggressive" => mobile.flags.aggressive = value,
                    "sentinel" => mobile.flags.sentinel = value,
                    "scavenger" => mobile.flags.scavenger = value,
                    "shopkeeper" => mobile.flags.shopkeeper = value,
                    "no_attack" | "noattack" => mobile.flags.no_attack = value,
                    "healer" => mobile.flags.healer = value,
                    _ => return false,
                }
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_vnum(mobile_id, vnum) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_vnum", move |mobile_id: String, vnum: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.vnum = vnum;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // set_mobile_prototype(mobile_id, is_prototype) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_prototype", move |mobile_id: String, is_prototype: bool| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.is_prototype = is_prototype;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // get_mobile_dialogue(mobile_id, keyword) -> String (response or empty)
    let cloned_db = db.clone();
    engine.register_fn("get_mobile_dialogue", move |mobile_id: String, keyword: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mobile)) = cloned_db.get_mobile_data(&uuid) {
                let kw_lower = keyword.to_lowercase();
                if let Some(response) = mobile.dialogue.get(&kw_lower) {
                    return response.clone();
                }
            }
        }
        String::new()
    });

    // set_mobile_dialogue(mobile_id, keyword, response) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_dialogue", move |mobile_id: String, keyword: String, response: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.dialogue.insert(keyword.to_lowercase(), response);
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // remove_mobile_dialogue(mobile_id, keyword) -> bool
    let cloned_db = db.clone();
    engine.register_fn("remove_mobile_dialogue", move |mobile_id: String, keyword: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                if mobile.dialogue.remove(&keyword.to_lowercase()).is_some() {
                    return cloned_db.save_mobile_data(mobile).is_ok();
                }
            }
        }
        false
    });

    // get_all_mobile_dialogues(mobile_id) -> Map (keyword -> response)
    let cloned_db = db.clone();
    engine.register_fn("get_all_mobile_dialogues", move |mobile_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mobile)) = cloned_db.get_mobile_data(&uuid) {
                let mut map = rhai::Map::new();
                for (k, v) in mobile.dialogue {
                    map.insert(k.into(), rhai::Dynamic::from(v));
                }
                return rhai::Dynamic::from(map);
            }
        }
        rhai::Dynamic::from(rhai::Map::new())
    });

    // find_mobile_by_keyword(keyword, mobiles_array) -> MobileData or ()
    engine.register_fn("find_mobile_by_keyword", |keyword: String, mobiles: rhai::Array| {
        let kw_lower = keyword.to_lowercase();
        for mob_dyn in mobiles {
            if let Some(mobile) = mob_dyn.clone().try_cast::<MobileData>() {
                // Check name
                if mobile.name.to_lowercase().contains(&kw_lower) {
                    return rhai::Dynamic::from(mobile);
                }
                // Check keywords
                for mob_kw in &mobile.keywords {
                    if mob_kw.to_lowercase() == kw_lower || mob_kw.to_lowercase().contains(&kw_lower) {
                        return rhai::Dynamic::from(mobile);
                    }
                }
            }
        }
        rhai::Dynamic::UNIT
    });

    // === NPC Transport Route Functions ===

    // set_mobile_transport_route(mobile_id, transport_id, home_stop, dest_stop, schedule_type, schedule_arg1, schedule_arg2)
    // schedule_type: "fixed" (arg1=depart_hour, arg2=return_hour), "random" (arg1=chance), "permanent" (no args)
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_transport_route", move |mobile_id: String, transport_id: String, home_stop: i64, dest_stop: i64, schedule_type: String, arg1: i64, arg2: i64| {
        let mobile_uuid = match uuid::Uuid::parse_str(&mobile_id) {
            Ok(u) => u,
            Err(_) => return false,
        };
        let transport_uuid = match uuid::Uuid::parse_str(&transport_id) {
            Ok(u) => u,
            Err(_) => return false,
        };

        let schedule = match schedule_type.to_lowercase().as_str() {
            "fixed" => crate::NPCTravelSchedule::FixedHours {
                depart_hour: arg1 as u8,
                return_hour: arg2 as u8,
            },
            "random" => crate::NPCTravelSchedule::Random {
                chance_per_hour: arg1 as i32,
            },
            "permanent" => crate::NPCTravelSchedule::Permanent,
            _ => return false,
        };

        if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&mobile_uuid) {
            mobile.transport_route = Some(crate::TransportRoute {
                transport_id: transport_uuid,
                home_stop_index: home_stop as usize,
                destination_stop_index: dest_stop as usize,
                schedule,
                is_at_destination: false,
                is_on_transport: false,
            });
            return cloned_db.save_mobile_data(mobile).is_ok();
        }
        false
    });

    // clear_mobile_transport_route(mobile_id) -> bool
    let cloned_db = db.clone();
    engine.register_fn("clear_mobile_transport_route", move |mobile_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                mobile.transport_route = None;
                return cloned_db.save_mobile_data(mobile).is_ok();
            }
        }
        false
    });

    // get_mobile_transport_route(mobile_id) -> Map or ()
    // Returns: { transport_id, home_stop, dest_stop, schedule_type, depart_hour, return_hour, chance, is_at_destination, is_on_transport }
    let cloned_db = db.clone();
    engine.register_fn("get_mobile_transport_route", move |mobile_id: String| -> rhai::Dynamic {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mobile)) = cloned_db.get_mobile_data(&uuid) {
                if let Some(route) = mobile.transport_route {
                    let mut map = rhai::Map::new();
                    map.insert("transport_id".into(), route.transport_id.to_string().into());
                    map.insert("home_stop".into(), (route.home_stop_index as i64).into());
                    map.insert("dest_stop".into(), (route.destination_stop_index as i64).into());
                    map.insert("is_at_destination".into(), route.is_at_destination.into());
                    map.insert("is_on_transport".into(), route.is_on_transport.into());

                    match route.schedule {
                        crate::NPCTravelSchedule::FixedHours { depart_hour, return_hour } => {
                            map.insert("schedule_type".into(), "fixed".into());
                            map.insert("depart_hour".into(), (depart_hour as i64).into());
                            map.insert("return_hour".into(), (return_hour as i64).into());
                        }
                        crate::NPCTravelSchedule::Random { chance_per_hour } => {
                            map.insert("schedule_type".into(), "random".into());
                            map.insert("chance".into(), (chance_per_hour as i64).into());
                        }
                        crate::NPCTravelSchedule::Permanent => {
                            map.insert("schedule_type".into(), "permanent".into());
                        }
                    }
                    return rhai::Dynamic::from(map);
                }
            }
        }
        rhai::Dynamic::UNIT
    });

    // has_mobile_transport_route(mobile_id) -> bool
    let cloned_db = db.clone();
    engine.register_fn("has_mobile_transport_route", move |mobile_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mobile)) = cloned_db.get_mobile_data(&uuid) {
                return mobile.transport_route.is_some();
            }
        }
        false
    });

    // set_mobile_transport_state(mobile_id, is_at_destination, is_on_transport) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_mobile_transport_state", move |mobile_id: String, is_at_dest: bool, is_on_transport: bool| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mut mobile)) = cloned_db.get_mobile_data(&uuid) {
                if let Some(ref mut route) = mobile.transport_route {
                    route.is_at_destination = is_at_dest;
                    route.is_on_transport = is_on_transport;
                    return cloned_db.save_mobile_data(mobile).is_ok();
                }
            }
        }
        false
    });
}
