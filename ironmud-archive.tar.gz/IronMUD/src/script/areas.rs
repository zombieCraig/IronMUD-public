// src/script/areas.rs
// Area system functions: CRUD, permissions, trustees, vnums, forage tables

use rhai::{Engine, EvalAltResult, Position};
use std::sync::Arc;
use crate::db::Db;
use crate::{AreaData, AreaPermission, CombatZoneType};

/// Register area-related functions
pub fn register(engine: &mut Engine, db: Arc<Db>) {
    // ========== Area Functions ==========

    // create_area(name, prefix) -> Creates a new area (no owner)
    let cloned_db = db.clone();
    engine.register_fn("create_area", move |name: String, prefix: String| {
        let area = AreaData {
            id: uuid::Uuid::new_v4(),
            name,
            prefix,
            description: String::new(),
            level_min: 0,
            level_max: 0,
            theme: String::new(),
            owner: None,
            permission_level: AreaPermission::AllBuilders,
            trusted_builders: Vec::new(),
            city_forage_table: Vec::new(),
            wilderness_forage_table: Vec::new(),
            combat_zone: CombatZoneType::Pve,
            flags: crate::AreaFlags::default(),
        };
        if let Err(e) = cloned_db.save_area_data(area.clone()) {
            tracing::error!("Failed to save new area: {}", e);
        }
        area
    });

    // create_area_with_owner(name, prefix, owner) -> Creates a new area with owner
    let cloned_db = db.clone();
    engine.register_fn(
        "create_area_with_owner",
        move |name: String, prefix: String, owner: String| {
            let area = AreaData {
                id: uuid::Uuid::new_v4(),
                name,
                prefix,
                description: String::new(),
                level_min: 0,
                level_max: 0,
                theme: String::new(),
                owner: if owner.is_empty() {
                    None
                } else {
                    Some(owner)
                },
                permission_level: AreaPermission::AllBuilders,
                trusted_builders: Vec::new(),
                city_forage_table: Vec::new(),
                wilderness_forage_table: Vec::new(),
                combat_zone: CombatZoneType::Pve,
                flags: crate::AreaFlags::default(),
            };
            if let Err(e) = cloned_db.save_area_data(area.clone()) {
                tracing::error!("Failed to save new area: {}", e);
            }
            area
        },
    );

    // get_area_data(area_id) -> Gets area by ID
    let cloned_db = db.clone();
    engine.register_fn("get_area_data", move |area_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(area)) => rhai::Dynamic::from(area),
                _ => rhai::Dynamic::UNIT,
            }
        } else {
            rhai::Dynamic::UNIT
        }
    });

    // save_area_data(area) -> Saves area data
    let cloned_db = db.clone();
    engine.register_fn("save_area_data", move |area: AreaData| {
        cloned_db.save_area_data(area)
            .map_err(|e| Box::new(EvalAltResult::ErrorRuntime(rhai::Dynamic::from(format!("DB Error: {}", e)), Position::NONE)))
            .map(|_| rhai::Dynamic::UNIT)
    });

    // ========== Area Setter Functions ==========

    // set_area_name(area_id, name) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_area_name", move |area_id: String, name: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                area.name = name;
                return cloned_db.save_area_data(area).is_ok();
            }
        }
        false
    });

    // set_area_description(area_id, desc) -> bool
    let cloned_db = db.clone();
    engine.register_fn(
        "set_area_description",
        move |area_id: String, desc: String| {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                    area.description = desc;
                    return cloned_db.save_area_data(area).is_ok();
                }
            }
            false
        },
    );

    // set_area_prefix(area_id, prefix) -> bool
    let cloned_db = db.clone();
    engine.register_fn(
        "set_area_prefix",
        move |area_id: String, prefix: String| {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                    area.prefix = prefix;
                    return cloned_db.save_area_data(area).is_ok();
                }
            }
            false
        },
    );

    // set_area_theme(area_id, theme) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_area_theme", move |area_id: String, theme: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                area.theme = theme;
                return cloned_db.save_area_data(area).is_ok();
            }
        }
        false
    });

    // set_area_levels(area_id, min, max) -> bool
    let cloned_db = db.clone();
    engine.register_fn(
        "set_area_levels",
        move |area_id: String, min: i64, max: i64| {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                    area.level_min = min as i32;
                    area.level_max = max as i32;
                    return cloned_db.save_area_data(area).is_ok();
                }
            }
            false
        },
    );

    // set_area_owner(area_id, owner_name) -> bool (empty string clears owner)
    let cloned_db = db.clone();
    engine.register_fn("set_area_owner", move |area_id: String, owner: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                area.owner = if owner.is_empty() { None } else { Some(owner) };
                return cloned_db.save_area_data(area).is_ok();
            }
        }
        false
    });

    // set_area_permission(area_id, level_str) -> bool
    let cloned_db = db.clone();
    engine.register_fn(
        "set_area_permission",
        move |area_id: String, level: String| {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                    area.permission_level = match level.to_lowercase().as_str() {
                        "owner_only" | "owner" => AreaPermission::OwnerOnly,
                        "trusted" => AreaPermission::Trusted,
                        "all_builders" | "all" | "builders" => AreaPermission::AllBuilders,
                        _ => return false,
                    };
                    return cloned_db.save_area_data(area).is_ok();
                }
            }
            false
        },
    );

    // add_area_trustee(area_id, character_name) -> bool
    let cloned_db = db.clone();
    engine.register_fn(
        "add_area_trustee",
        move |area_id: String, name: String| {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                    // Check if already in list (case-insensitive)
                    if !area
                        .trusted_builders
                        .iter()
                        .any(|t| t.eq_ignore_ascii_case(&name))
                    {
                        area.trusted_builders.push(name);
                        return cloned_db.save_area_data(area).is_ok();
                    }
                }
            }
            false
        },
    );

    // remove_area_trustee(area_id, character_name) -> bool
    let cloned_db = db.clone();
    engine.register_fn(
        "remove_area_trustee",
        move |area_id: String, name: String| {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                    let before_len = area.trusted_builders.len();
                    area.trusted_builders
                        .retain(|t| !t.eq_ignore_ascii_case(&name));
                    if area.trusted_builders.len() < before_len {
                        return cloned_db.save_area_data(area).is_ok();
                    }
                }
            }
            false
        },
    );

    // can_edit_area(area_id, character_name) -> bool
    // Checks if a character has permission to edit the area
    let cloned_db = db.clone();
    engine.register_fn(
        "can_edit_area",
        move |area_id: String, char_name: String| {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(area)) = cloned_db.get_area_data(&uuid) {
                    // No owner = any builder can edit (caller should check is_builder)
                    if area.owner.is_none() {
                        return true;
                    }

                    let owner = area.owner.as_ref().unwrap();

                    match area.permission_level {
                        AreaPermission::OwnerOnly => owner.eq_ignore_ascii_case(&char_name),
                        AreaPermission::Trusted => {
                            owner.eq_ignore_ascii_case(&char_name)
                                || area
                                    .trusted_builders
                                    .iter()
                                    .any(|t| t.eq_ignore_ascii_case(&char_name))
                        }
                        AreaPermission::AllBuilders => true,
                    }
                } else {
                    true // Area not found = allow (let other checks handle it)
                }
            } else {
                true // Invalid ID = allow
            }
        },
    );

    // delete_area(area_id) -> Deletes an area (unassigns rooms, doesn't delete them)
    let cloned_db = db.clone();
    engine.register_fn("delete_area", move |area_id: String| {
        let area_uuid = match uuid::Uuid::parse_str(&area_id) {
            Ok(u) => u,
            Err(_) => return false,
        };
        cloned_db.delete_area(&area_uuid).unwrap_or(false)
    });

    // list_all_areas() -> Returns array of all AreaData
    let cloned_db = db.clone();
    engine.register_fn("list_all_areas", move || {
        cloned_db.list_all_areas()
            .unwrap_or_default()
            .into_iter()
            .map(rhai::Dynamic::from)
            .collect::<Vec<_>>()
    });

    // get_area_by_prefix(prefix) -> Gets area by prefix (case-insensitive)
    let cloned_db = db.clone();
    engine.register_fn("get_area_by_prefix", move |prefix: String| {
        let prefix_lower = prefix.to_lowercase();
        for area in cloned_db.list_all_areas().unwrap_or_default() {
            if area.prefix.to_lowercase() == prefix_lower {
                return rhai::Dynamic::from(area);
            }
        }
        rhai::Dynamic::UNIT
    });

    // ========== Unique VNUM Generation ==========

    // generate_unique_vnum(prefix, base_name) -> Generates unique vnum like "prefix:slug" or "prefix:slug_2"
    let cloned_db = db.clone();
    engine.register_fn("generate_unique_vnum", move |prefix: String, base_name: String| {
        // Slugify: lowercase, spaces/dashes -> underscores, alphanumeric only
        let mut slug = String::new();
        let mut last_was_underscore = true; // Skip leading underscores

        for c in base_name.to_lowercase().chars() {
            if c.is_ascii_alphanumeric() {
                slug.push(c);
                last_was_underscore = false;
            } else if (c == ' ' || c == '-' || c == '_') && !last_was_underscore {
                slug.push('_');
                last_was_underscore = true;
            }
        }
        // Trim trailing underscore
        while slug.ends_with('_') {
            slug.pop();
        }
        // Truncate to 24 chars max
        if slug.len() > 24 {
            slug.truncate(24);
            while slug.ends_with('_') {
                slug.pop();
            }
        }

        let prefix_lower = prefix.to_lowercase();
        let base_vnum = format!("{}:{}", prefix_lower, slug);

        // Check if available
        if cloned_db.get_room_by_vnum(&base_vnum).ok().flatten().is_none() {
            return base_vnum;
        }

        // Try numbered suffixes: _2, _3, ...
        for i in 2..=999 {
            let candidate = format!("{}_{}", base_vnum, i);
            if cloned_db.get_room_by_vnum(&candidate).ok().flatten().is_none() {
                return candidate;
            }
        }

        // Fallback with UUID fragment
        format!(
            "{}_{}",
            base_vnum,
            uuid::Uuid::new_v4().to_string().split('-').next().unwrap()
        )
    });

    // generate_unique_item_vnum(base_name) -> Generates unique item vnum like "slug" or "slug_2"
    let cloned_db = db.clone();
    engine.register_fn("generate_unique_item_vnum", move |base_name: String| {
        // Slugify: lowercase, spaces/dashes -> underscores, alphanumeric only
        let mut slug = String::new();
        let mut last_was_underscore = true; // Skip leading underscores

        for c in base_name.to_lowercase().chars() {
            if c.is_ascii_alphanumeric() {
                slug.push(c);
                last_was_underscore = false;
            } else if (c == ' ' || c == '-' || c == '_') && !last_was_underscore {
                slug.push('_');
                last_was_underscore = true;
            }
        }
        // Trim trailing underscore
        while slug.ends_with('_') {
            slug.pop();
        }
        // Truncate to 24 chars max
        if slug.len() > 24 {
            slug.truncate(24);
            while slug.ends_with('_') {
                slug.pop();
            }
        }

        // No prefix for items, just the slug
        let base_vnum = slug;

        // Check if available
        if cloned_db.get_item_by_vnum(&base_vnum).ok().flatten().is_none() {
            return base_vnum;
        }

        // Try numbered suffixes: _2, _3, ...
        for i in 2..=999 {
            let candidate = format!("{}_{}", base_vnum, i);
            if cloned_db.get_item_by_vnum(&candidate).ok().flatten().is_none() {
                return candidate;
            }
        }

        // Fallback with UUID fragment
        format!(
            "{}_{}",
            base_vnum,
            uuid::Uuid::new_v4().to_string().split('-').next().unwrap()
        )
    });

    // generate_unique_mobile_vnum(base_name) -> Generates unique mobile vnum like "slug" or "slug_2"
    let cloned_db = db.clone();
    engine.register_fn("generate_unique_mobile_vnum", move |base_name: String| {
        // Slugify: lowercase, spaces/dashes -> underscores, alphanumeric only
        let mut slug = String::new();
        let mut last_was_underscore = true; // Skip leading underscores

        for c in base_name.to_lowercase().chars() {
            if c.is_ascii_alphanumeric() {
                slug.push(c);
                last_was_underscore = false;
            } else if (c == ' ' || c == '-' || c == '_') && !last_was_underscore {
                slug.push('_');
                last_was_underscore = true;
            }
        }
        // Trim trailing underscore
        while slug.ends_with('_') {
            slug.pop();
        }
        // Truncate to 24 chars max
        if slug.len() > 24 {
            slug.truncate(24);
            while slug.ends_with('_') {
                slug.pop();
            }
        }

        // No prefix for mobiles, just the slug
        let base_vnum = slug;

        // Check if available
        if cloned_db.get_mobile_by_vnum(&base_vnum).ok().flatten().is_none() {
            return base_vnum;
        }

        // Try numbered suffixes: _2, _3, ...
        for i in 2..=999 {
            let candidate = format!("{}_{}", base_vnum, i);
            if cloned_db.get_mobile_by_vnum(&candidate).ok().flatten().is_none() {
                return candidate;
            }
        }

        // Fallback with UUID fragment
        format!(
            "{}_{}",
            base_vnum,
            uuid::Uuid::new_v4().to_string().split('-').next().unwrap()
        )
    });

    // ========== Room-Area Linking ==========

    // set_room_area(room_id, area_id) -> Assigns room to area
    let cloned_db = db.clone();
    engine.register_fn("set_room_area", move |room_id: String, area_id: String| {
        let room_uuid = match uuid::Uuid::parse_str(&room_id) {
            Ok(u) => u,
            Err(_) => return false,
        };
        let area_uuid = match uuid::Uuid::parse_str(&area_id) {
            Ok(u) => u,
            Err(_) => return false,
        };
        cloned_db.set_room_area(&room_uuid, &area_uuid).unwrap_or(false)
    });

    // clear_room_area(room_id) -> Removes room from its area
    let cloned_db = db.clone();
    engine.register_fn("clear_room_area", move |room_id: String| {
        let room_uuid = match uuid::Uuid::parse_str(&room_id) {
            Ok(u) => u,
            Err(_) => return false,
        };
        cloned_db.clear_room_area(&room_uuid).unwrap_or(false)
    });

    // get_rooms_in_area(area_id) -> Returns array of rooms in area
    let cloned_db = db.clone();
    engine.register_fn("get_rooms_in_area", move |area_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            cloned_db.get_rooms_in_area(&uuid)
                .unwrap_or_default()
                .into_iter()
                .map(rhai::Dynamic::from)
                .collect::<Vec<_>>()
        } else {
            vec![]
        }
    });

    // ========== Area Forage Table Functions ==========

    // add_area_city_forage(area_id, vnum, min_skill, rarity) -> bool
    let cloned_db = db.clone();
    engine.register_fn("add_area_city_forage", move |area_id: String, vnum: String, min_skill: i64, rarity: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(mut area)) => {
                    // Check if vnum already exists
                    if area.city_forage_table.iter().any(|e| e.vnum == vnum) {
                        return false;
                    }
                    area.city_forage_table.push(crate::ForageEntry {
                        vnum,
                        min_skill: min_skill as i32,
                        rarity,
                    });
                    cloned_db.save_area_data(area).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // remove_area_city_forage(area_id, vnum) -> bool
    let cloned_db = db.clone();
    engine.register_fn("remove_area_city_forage", move |area_id: String, vnum: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(mut area)) => {
                    let orig_len = area.city_forage_table.len();
                    area.city_forage_table.retain(|e| e.vnum != vnum);
                    if area.city_forage_table.len() < orig_len {
                        cloned_db.save_area_data(area).is_ok()
                    } else {
                        false
                    }
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // get_area_city_forage_table(area_id) -> Array of Maps
    let cloned_db = db.clone();
    engine.register_fn("get_area_city_forage_table", move |area_id: String| -> Vec<rhai::Dynamic> {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(area)) => {
                    area.city_forage_table.iter().map(|entry| {
                        let mut map = rhai::Map::new();
                        map.insert("vnum".into(), rhai::Dynamic::from(entry.vnum.clone()));
                        map.insert("min_skill".into(), rhai::Dynamic::from(entry.min_skill as i64));
                        map.insert("rarity".into(), rhai::Dynamic::from(entry.rarity.clone()));
                        rhai::Dynamic::from(map)
                    }).collect()
                }
                _ => Vec::new(),
            }
        } else {
            Vec::new()
        }
    });

    // add_area_wilderness_forage(area_id, vnum, min_skill, rarity) -> bool
    let cloned_db = db.clone();
    engine.register_fn("add_area_wilderness_forage", move |area_id: String, vnum: String, min_skill: i64, rarity: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(mut area)) => {
                    // Check if vnum already exists
                    if area.wilderness_forage_table.iter().any(|e| e.vnum == vnum) {
                        return false;
                    }
                    area.wilderness_forage_table.push(crate::ForageEntry {
                        vnum,
                        min_skill: min_skill as i32,
                        rarity,
                    });
                    cloned_db.save_area_data(area).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // remove_area_wilderness_forage(area_id, vnum) -> bool
    let cloned_db = db.clone();
    engine.register_fn("remove_area_wilderness_forage", move |area_id: String, vnum: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(mut area)) => {
                    let orig_len = area.wilderness_forage_table.len();
                    area.wilderness_forage_table.retain(|e| e.vnum != vnum);
                    if area.wilderness_forage_table.len() < orig_len {
                        cloned_db.save_area_data(area).is_ok()
                    } else {
                        false
                    }
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // get_area_wilderness_forage_table(area_id) -> Array of Maps
    let cloned_db = db.clone();
    engine.register_fn("get_area_wilderness_forage_table", move |area_id: String| -> Vec<rhai::Dynamic> {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(area)) => {
                    area.wilderness_forage_table.iter().map(|entry| {
                        let mut map = rhai::Map::new();
                        map.insert("vnum".into(), rhai::Dynamic::from(entry.vnum.clone()));
                        map.insert("min_skill".into(), rhai::Dynamic::from(entry.min_skill as i64));
                        map.insert("rarity".into(), rhai::Dynamic::from(entry.rarity.clone()));
                        rhai::Dynamic::from(map)
                    }).collect()
                }
                _ => Vec::new(),
            }
        } else {
            Vec::new()
        }
    });

    // select_area_forage(area_id, forage_type, skill_level) -> Map with vnum and rarity, or () if nothing
    // forage_type: "city" or "wilderness"
    // Uses item weight from prototype for weighted selection
    let cloned_db = db.clone();
    engine.register_fn("select_area_forage", move |area_id: String, forage_type: String, skill_level: i64| -> rhai::Dynamic {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            match cloned_db.get_area_data(&uuid) {
                Ok(Some(area)) => {
                    let forage_table = match forage_type.to_lowercase().as_str() {
                        "city" => &area.city_forage_table,
                        "wilderness" => &area.wilderness_forage_table,
                        _ => return rhai::Dynamic::UNIT,
                    };

                    // Filter by skill level
                    let available: Vec<_> = forage_table.iter()
                        .filter(|e| (e.min_skill as i64) <= skill_level)
                        .collect();

                    if available.is_empty() {
                        return rhai::Dynamic::UNIT;
                    }

                    // Get weights from item prototypes
                    let mut weighted_entries: Vec<(&crate::ForageEntry, i32)> = Vec::new();
                    for entry in &available {
                        // Try to get item weight from prototype
                        let weight = if let Ok(Some(item)) = cloned_db.get_item_by_vnum(&entry.vnum) {
                            item.weight.max(1) // Minimum weight of 1
                        } else {
                            1 // Default weight if prototype not found
                        };
                        weighted_entries.push((entry, weight));
                    }

                    let total_weight: i32 = weighted_entries.iter().map(|(_, w)| *w).sum();
                    if total_weight <= 0 {
                        return rhai::Dynamic::UNIT;
                    }

                    // Random selection
                    use std::time::{SystemTime, UNIX_EPOCH};
                    let seed = SystemTime::now()
                        .duration_since(UNIX_EPOCH)
                        .map(|d| d.as_nanos() as u64)
                        .unwrap_or(0);
                    let mut roll = (seed % total_weight as u64) as i32;

                    for (entry, weight) in weighted_entries {
                        roll -= weight;
                        if roll < 0 {
                            let mut result = rhai::Map::new();
                            result.insert("vnum".into(), rhai::Dynamic::from(entry.vnum.clone()));
                            result.insert("rarity".into(), rhai::Dynamic::from(entry.rarity.clone()));
                            result.insert("min_skill".into(), rhai::Dynamic::from(entry.min_skill as i64));
                            return rhai::Dynamic::from(result);
                        }
                    }
                    rhai::Dynamic::UNIT
                }
                _ => rhai::Dynamic::UNIT,
            }
        } else {
            rhai::Dynamic::UNIT
        }
    });

    // ========== Combat Zone Functions ==========

    // set_area_combat_zone(area_id, zone_type) -> bool
    // Sets the area's combat zone type ("pve", "safe", or "pvp")
    let cloned_db = db.clone();
    engine.register_fn("set_area_combat_zone", move |area_id: String, zone_type: String| -> bool {
        if let Some(zone) = CombatZoneType::from_str(&zone_type) {
            if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
                if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                    area.combat_zone = zone;
                    return cloned_db.save_area_data(area).is_ok();
                }
            }
        }
        false
    });

    // get_area_combat_zone(area_id) -> String
    // Gets the area's combat zone type ("pve", "safe", or "pvp")
    let cloned_db = db.clone();
    engine.register_fn("get_area_combat_zone", move |area_id: String| -> String {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            if let Ok(Some(area)) = cloned_db.get_area_data(&uuid) {
                return area.combat_zone.to_display_string().to_string();
            }
        }
        "pve".to_string() // Default
    });

    // ========== Area Flags Functions ==========

    // set_area_flag(area_id, flag_name, value) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_area_flag", move |area_id: String, flag_name: String, value: bool| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            if let Ok(Some(mut area)) = cloned_db.get_area_data(&uuid) {
                match flag_name.to_lowercase().as_str() {
                    "climate_controlled" => area.flags.climate_controlled = value,
                    _ => return false,
                }
                return cloned_db.save_area_data(area).is_ok();
            }
        }
        false
    });

    // get_area_flag(area_id, flag_name) -> bool
    let cloned_db = db.clone();
    engine.register_fn("get_area_flag", move |area_id: String, flag_name: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&area_id) {
            if let Ok(Some(area)) = cloned_db.get_area_data(&uuid) {
                return match flag_name.to_lowercase().as_str() {
                    "climate_controlled" => area.flags.climate_controlled,
                    _ => false,
                };
            }
        }
        false
    });

    // get_effective_climate_controlled(room_id) -> bool
    // Checks room flag first, then falls back to area flag
    let cloned_db = db.clone();
    engine.register_fn("get_effective_climate_controlled", move |room_id: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&room_id) {
            if let Ok(Some(room)) = cloned_db.get_room_data(&uuid) {
                // Room flag takes precedence
                if room.flags.climate_controlled {
                    return true;
                }
                // Fall back to area flag
                if let Some(area_id) = room.area_id {
                    if let Ok(Some(area)) = cloned_db.get_area_data(&area_id) {
                        return area.flags.climate_controlled;
                    }
                }
            }
        }
        false
    });
}
