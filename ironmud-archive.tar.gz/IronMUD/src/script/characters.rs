// src/script/characters.rs
// Character-related functions: creation wizard, permissions, settings, game time,
// thirst, stamina penalties, darkness/vision, gold, skills, and foraging

use rhai::Engine;
use crate::db::Db;
use crate::SharedConnections;
use crate::SharedState;
use crate::{
    broadcast_to_all_players, broadcast_to_outdoor_players,
    get_time_transition_message, get_season_transition_message,
    fire_environmental_triggers_impl,
};
use std::sync::Arc;

/// Register character-related functions
pub fn register(engine: &mut Engine, db: Arc<Db>, connections: SharedConnections, state: SharedState) {
    // ========== Character Creation Wizard Functions ==========

    // set_wizard_data(connection_id, data) -> Store wizard state (JSON string)
    let conns = connections.clone();
    engine.register_fn("set_wizard_data", move |connection_id: String, data: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let mut conns = conns.lock().unwrap();
            if let Some(session) = conns.get_mut(&uuid) {
                session.wizard_data = if data.is_empty() { None } else { Some(data) };
                return true;
            }
        }
        false
    });

    // get_wizard_data(connection_id) -> Get wizard state (empty string if none)
    let conns = connections.clone();
    engine.register_fn("get_wizard_data", move |connection_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns = conns.lock().unwrap();
            if let Some(session) = conns.get(&uuid) {
                return session.wizard_data.clone().unwrap_or_default();
            }
        }
        String::new()
    });

    // clear_wizard_data(connection_id) -> Clear wizard state
    let conns = connections.clone();
    engine.register_fn("clear_wizard_data", move |connection_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let mut conns = conns.lock().unwrap();
            if let Some(session) = conns.get_mut(&uuid) {
                session.wizard_data = None;
                return true;
            }
        }
        false
    });

    // get_class_list() -> Array of available class IDs
    let state_clone = state.clone();
    engine.register_fn("get_class_list", move || -> rhai::Array {
        let world = state_clone.lock().unwrap();
        world.class_definitions.iter()
            .filter(|(_, c)| c.available)
            .map(|(id, _)| rhai::Dynamic::from(id.clone()))
            .collect()
    });

    // get_class_info(class_id) -> Map with name, description
    let state_clone = state.clone();
    engine.register_fn("get_class_info", move |class_id: String| -> rhai::Map {
        let world = state_clone.lock().unwrap();
        let mut map = rhai::Map::new();
        if let Some(class) = world.class_definitions.get(&class_id) {
            map.insert("id".into(), rhai::Dynamic::from(class.id.clone()));
            map.insert("name".into(), rhai::Dynamic::from(class.name.clone()));
            map.insert("description".into(), rhai::Dynamic::from(class.description.clone()));
            map.insert("available".into(), rhai::Dynamic::from(class.available));
        }
        map
    });

    // get_trait_list() -> Array of available trait IDs
    let state_clone = state.clone();
    engine.register_fn("get_trait_list", move || -> rhai::Array {
        let world = state_clone.lock().unwrap();
        world.trait_definitions.iter()
            .filter(|(_, t)| t.available)
            .map(|(id, _)| rhai::Dynamic::from(id.clone()))
            .collect()
    });

    // get_trait_info(trait_id) -> Map with name, description, cost, category, effects
    let state_clone = state.clone();
    engine.register_fn("get_trait_info", move |trait_id: String| -> rhai::Map {
        let world = state_clone.lock().unwrap();
        let mut map = rhai::Map::new();
        if let Some(tr) = world.trait_definitions.get(&trait_id) {
            map.insert("id".into(), rhai::Dynamic::from(tr.id.clone()));
            map.insert("name".into(), rhai::Dynamic::from(tr.name.clone()));
            map.insert("description".into(), rhai::Dynamic::from(tr.description.clone()));
            map.insert("cost".into(), rhai::Dynamic::from(tr.cost as i64));
            map.insert("category".into(), rhai::Dynamic::from(match tr.category {
                crate::TraitCategory::Positive => "positive".to_string(),
                crate::TraitCategory::Negative => "negative".to_string(),
            }));
            map.insert("available".into(), rhai::Dynamic::from(tr.available));
            // Convert conflicts_with Vec to Array
            let conflicts: rhai::Array = tr.conflicts_with.iter()
                .map(|s| rhai::Dynamic::from(s.clone()))
                .collect();
            map.insert("conflicts_with".into(), rhai::Dynamic::from(conflicts));
            // Convert effects HashMap to Map
            let effects_map: rhai::Map = tr.effects.iter()
                .map(|(k, v)| (k.clone().into(), rhai::Dynamic::from(*v as i64)))
                .collect();
            map.insert("effects".into(), rhai::Dynamic::from(effects_map));
        }
        map
    });

    // get_random_race() -> String from race suggestions
    let state_clone = state.clone();
    engine.register_fn("get_random_race", move || -> String {
        let world = state_clone.lock().unwrap();
        if world.race_suggestions.is_empty() {
            return "Human".to_string();
        }
        use rand::seq::SliceRandom;
        world.race_suggestions.choose(&mut rand::thread_rng())
            .map(|r| r.name.clone())
            .unwrap_or_else(|| "Human".to_string())
    });

    // get_random_short_desc() -> Default description
    engine.register_fn("get_random_short_desc", || -> String {
        "A nondescript adventurer.".to_string()
    });

    // delete_character(name) -> Delete a character from the database (for cancelling creation)
    let cloned_db = db.clone();
    engine.register_fn("delete_character", move |name: String| -> bool {
        match cloned_db.delete_character_data(&name) {
            Ok(_) => true,
            Err(e) => {
                tracing::error!("Failed to delete character '{}': {}", name, e);
                false
            }
        }
    });

    // ========== Builder Permission Functions ==========

    // set_builder_flag(character_name, is_builder) -> Set builder status for a character
    // Also updates the session if the character is online
    let cloned_db = db.clone();
    let conns = connections.clone();
    engine.register_fn("set_builder_flag", move |character_name: String, is_builder: bool| {
        if let Ok(Some(mut character)) = cloned_db.get_character_data(&character_name) {
            character.is_builder = is_builder;
            if let Err(e) = cloned_db.save_character_data(character.clone()) {
                tracing::error!("Failed to save character builder flag: {}", e);
                return false;
            }

            // Also update the session if this character is logged in
            let mut conns = conns.lock().unwrap();
            for (_id, session) in conns.iter_mut() {
                if let Some(ref mut session_char) = session.character {
                    if session_char.name.eq_ignore_ascii_case(&character_name) {
                        session_char.is_builder = is_builder;
                        break;
                    }
                }
            }

            true
        } else {
            false
        }
    });

    // set_admin_flag(character_name, is_admin) -> Set admin status for a character
    // Also updates the session if the character is online
    let cloned_db = db.clone();
    let conns = connections.clone();
    engine.register_fn("set_admin_flag", move |character_name: String, is_admin: bool| {
        if let Ok(Some(mut character)) = cloned_db.get_character_data(&character_name) {
            character.is_admin = is_admin;
            if let Err(e) = cloned_db.save_character_data(character.clone()) {
                tracing::error!("Failed to save character admin flag: {}", e);
                return false;
            }

            // Also update the session if this character is logged in
            let mut conns = conns.lock().unwrap();
            for (_id, session) in conns.iter_mut() {
                if let Some(ref mut session_char) = session.character {
                    if session_char.name.eq_ignore_ascii_case(&character_name) {
                        session_char.is_admin = is_admin;
                        break;
                    }
                }
            }

            true
        } else {
            false
        }
    });

    // ========== Settings Functions ==========

    // get_setting(key) -> String (empty if not set)
    let cloned_db = db.clone();
    engine.register_fn("get_setting", move |key: String| {
        cloned_db.get_setting(&key).unwrap_or(None).unwrap_or_default()
    });

    // get_setting_or_default(key, default) -> String
    let cloned_db = db.clone();
    engine.register_fn("get_setting_or_default", move |key: String, default: String| {
        cloned_db.get_setting_or_default(&key, &default).unwrap_or(default)
    });

    // set_setting(key, value) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_setting", move |key: String, value: String| {
        cloned_db.set_setting(&key, &value).is_ok()
    });

    // count_characters() -> i64 - Count total characters in database
    let cloned_db = db.clone();
    engine.register_fn("count_characters", move || {
        cloned_db.count_characters().unwrap_or(0) as i64
    });

    // ========== Game Time Functions ==========

    // get_game_time() -> Map with time info
    let cloned_db = db.clone();
    engine.register_fn("get_game_time", move || {
        match cloned_db.get_game_time() {
            Ok(gt) => {
                let mut map = rhai::Map::new();
                map.insert("hour".into(), rhai::Dynamic::from(gt.hour as i64));
                map.insert("day".into(), rhai::Dynamic::from(gt.day as i64));
                map.insert("month".into(), rhai::Dynamic::from(gt.month as i64));
                map.insert("year".into(), rhai::Dynamic::from(gt.year as i64));
                map.insert("season".into(), rhai::Dynamic::from(gt.get_season().to_string().to_lowercase()));
                map.insert("time_of_day".into(), rhai::Dynamic::from(format!("{}", gt.get_time_of_day())));
                map.insert("weather".into(), rhai::Dynamic::from(format!("{:?}", gt.weather).to_lowercase()));
                map.insert("temperature".into(), rhai::Dynamic::from(gt.calculate_effective_temperature() as i64));
                // Human-readable descriptions
                map.insert("time_of_day_desc".into(), rhai::Dynamic::from(format!("{}", gt.get_time_of_day())));
                map.insert("weather_desc".into(), rhai::Dynamic::from(format!("{}", gt.weather)));
                map.insert("temperature_desc".into(), rhai::Dynamic::from(format!("{}", gt.get_temperature_category())));
                map.insert("is_daytime".into(), rhai::Dynamic::from(gt.is_daytime()));
                rhai::Dynamic::from(map)
            }
            Err(_) => rhai::Dynamic::UNIT,
        }
    });

    // get_current_season() -> Current season as string (spring, summer, autumn, winter)
    let cloned_db = db.clone();
    engine.register_fn("get_current_season", move || -> String {
        match cloned_db.get_game_time() {
            Ok(gt) => gt.get_season().to_string().to_lowercase(),
            Err(_) => "spring".to_string(),
        }
    });

    // admin_set_time(hour, day, month, year) -> Map with changes and status
    // Sets the game time and returns what changed (for triggering purposes)
    let cloned_db = db.clone();
    let conns = connections.clone();
    engine.register_fn("admin_set_time", move |hour: i64, day: i64, month: i64, year: i64| {
        let mut result = rhai::Map::new();
        result.insert("success".into(), rhai::Dynamic::from(false));

        // Validate inputs
        if hour < 0 || hour > 23 {
            result.insert("error".into(), rhai::Dynamic::from("Hour must be 0-23"));
            return rhai::Dynamic::from(result);
        }
        if day < 1 || day > 30 {
            result.insert("error".into(), rhai::Dynamic::from("Day must be 1-30"));
            return rhai::Dynamic::from(result);
        }
        if month < 1 || month > 12 {
            result.insert("error".into(), rhai::Dynamic::from("Month must be 1-12"));
            return rhai::Dynamic::from(result);
        }
        if year < 1 {
            result.insert("error".into(), rhai::Dynamic::from("Year must be >= 1"));
            return rhai::Dynamic::from(result);
        }

        // Get current time for comparison
        let old_time = match cloned_db.get_game_time() {
            Ok(t) => t,
            Err(e) => {
                result.insert("error".into(), rhai::Dynamic::from(format!("Failed to get time: {}", e)));
                return rhai::Dynamic::from(result);
            }
        };

        let old_time_of_day = old_time.get_time_of_day();
        let old_season = old_time.get_season();
        let old_month = old_time.month;

        // Create new time
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map(|d| d.as_secs() as i64)
            .unwrap_or(0);

        let mut new_time = old_time.clone();
        new_time.hour = hour as u8;
        new_time.day = day as u8;
        new_time.month = month as u8;
        new_time.year = year as u32;
        new_time.last_time_tick = now;

        let new_time_of_day = new_time.get_time_of_day();
        let new_season = new_time.get_season();

        // Save new time
        if let Err(e) = cloned_db.save_game_time(&new_time) {
            result.insert("error".into(), rhai::Dynamic::from(format!("Failed to save time: {}", e)));
            return rhai::Dynamic::from(result);
        }

        // Determine what changed
        let time_changed = old_time_of_day != new_time_of_day;
        let season_changed = old_season != new_season;
        let month_changed = old_month != new_time.month;

        result.insert("success".into(), rhai::Dynamic::from(true));
        result.insert("time_changed".into(), rhai::Dynamic::from(time_changed));
        result.insert("season_changed".into(), rhai::Dynamic::from(season_changed));
        result.insert("month_changed".into(), rhai::Dynamic::from(month_changed));
        result.insert("old_time_of_day".into(), rhai::Dynamic::from(format!("{}", old_time_of_day)));
        result.insert("new_time_of_day".into(), rhai::Dynamic::from(format!("{}", new_time_of_day)));
        result.insert("old_season".into(), rhai::Dynamic::from(old_season.to_string().to_lowercase()));
        result.insert("new_season".into(), rhai::Dynamic::from(new_season.to_string().to_lowercase()));
        result.insert("old_month".into(), rhai::Dynamic::from(old_month as i64));
        result.insert("new_month".into(), rhai::Dynamic::from(new_time.month as i64));

        // Broadcast messages for changes
        if time_changed {
            let msg = get_time_transition_message(&new_time_of_day);
            broadcast_to_outdoor_players(&cloned_db, &conns, &format!("\n{}\n", msg));
        }
        if season_changed {
            let msg = get_season_transition_message(&new_season);
            broadcast_to_all_players(&conns, &format!("\n{}\n", msg));
        }

        rhai::Dynamic::from(result)
    });

    // fire_time_triggers(trigger_type, context_map) -> fires environmental triggers
    // trigger_type: "time_change", "season_change", "month_change", "weather_change"
    let cloned_db = db.clone();
    let conns = connections.clone();
    engine.register_fn("fire_time_triggers", move |trigger_type: String, context: rhai::Map| {
        use crate::TriggerType;

        let tt = match trigger_type.as_str() {
            "time_change" => TriggerType::OnTimeChange,
            "season_change" => TriggerType::OnSeasonChange,
            "month_change" => TriggerType::OnMonthChange,
            "weather_change" => TriggerType::OnWeatherChange,
            _ => return false,
        };

        // Convert rhai::Map to HashMap<String, String>
        let mut ctx: std::collections::HashMap<String, String> = std::collections::HashMap::new();
        for (key, val) in context.iter() {
            ctx.insert(key.to_string(), val.to_string());
        }

        // Fire triggers
        fire_environmental_triggers_impl(&cloned_db, &conns, tt, &ctx)
    });

    // ========== Thirst Functions ==========

    // get_character_thirst(connection_id) -> Map with thirst/max_thirst/percent
    let conns = connections.clone();
    engine.register_fn("get_character_thirst", move |connection_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    let mut map = rhai::Map::new();
                    map.insert("thirst".into(), rhai::Dynamic::from(char.thirst as i64));
                    map.insert("max_thirst".into(), rhai::Dynamic::from(char.max_thirst as i64));
                    let pct = if char.max_thirst > 0 { (char.thirst * 100) / char.max_thirst } else { 0 };
                    map.insert("percent".into(), rhai::Dynamic::from(pct as i64));
                    return rhai::Dynamic::from(map);
                }
            }
        }
        rhai::Dynamic::UNIT
    });

    // restore_thirst(connection_id, amount) -> bool - Restore thirst (e.g., after drinking)
    let conns = connections.clone();
    let cloned_db = db.clone();
    engine.register_fn("restore_thirst", move |connection_id: String, amount: i64| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let mut conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get_mut(&uuid) {
                if let Some(ref mut char) = session.character {
                    let old_thirst = char.thirst;
                    char.thirst = (char.thirst + amount as i32).min(char.max_thirst);
                    if char.thirst != old_thirst {
                        let _ = cloned_db.save_character_data(char.clone());
                    }
                    return true;
                }
            }
        }
        false
    });

    // get_character_insulation(connection_id) -> i64 - Sum of equipped item insulation
    let conns = connections.clone();
    let cloned_db = db.clone();
    engine.register_fn("get_character_insulation", move |connection_id: String| -> i64 {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    let mut total = 0i64;
                    // Query database for equipped items (source of truth is ItemLocation::Equipped)
                    if let Ok(equipped_items) = cloned_db.get_equipped_items(&char.name) {
                        for item in equipped_items {
                            total += item.insulation as i64;
                        }
                    }
                    return total.min(100);
                }
            }
        }
        0
    });

    // set_item_insulation(item_id, value) -> bool - Set item insulation (for oedit)
    let cloned_db = db.clone();
    engine.register_fn("set_item_insulation", move |item_id: String, insulation: i64| {
        let item_uuid = match uuid::Uuid::parse_str(&item_id) {
            Ok(u) => u,
            Err(_) => return false,
        };
        let mut item = match cloned_db.get_item_data(&item_uuid) {
            Ok(Some(i)) => i,
            _ => return false,
        };
        item.insulation = insulation as i32;
        cloned_db.save_item_data(item).is_ok()
    });

    // has_trait(connection_id, trait_id) -> bool - Check if character has a specific trait
    let conns = connections.clone();
    engine.register_fn("has_trait", move |connection_id: String, trait_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    return char.traits.iter().any(|t| t == &trait_id);
                }
            }
        }
        false
    });

    // ========== Heat/Thirst Stamina Penalty Functions ==========

    // get_heat_stamina_penalty(connection_id) -> i64 - Returns 0, 1, or 2 based on heat
    let conns = connections.clone();
    let cloned_db = db.clone();
    engine.register_fn("get_heat_stamina_penalty", move |connection_id: String| -> i64 {
        let conn_uuid = match uuid::Uuid::parse_str(&connection_id) {
            Ok(u) => u,
            Err(_) => return 0,
        };

        let conns_guard = conns.lock().unwrap();
        let session = match conns_guard.get(&conn_uuid) {
            Some(s) => s,
            None => return 0,
        };
        let char = match &session.character {
            Some(c) => c,
            None => return 0,
        };

        // God mode bypasses all stamina penalties
        if char.god_mode {
            return 0;
        }

        // Check for desert_born trait (immune to heat penalty)
        if char.traits.iter().any(|t| t == "desert_born") {
            return 0;
        }

        // Get room data
        let room = match cloned_db.get_room_data(&char.current_room_id) {
            Ok(Some(r)) => r,
            _ => return 0,
        };

        // Climate controlled rooms have no heat penalty (check area inheritance)
        let is_climate_controlled = room.flags.climate_controlled ||
            room.area_id.and_then(|aid| cloned_db.get_area_data(&aid).ok().flatten())
                .map(|area| area.flags.climate_controlled)
                .unwrap_or(false);
        if is_climate_controlled {
            return 0;
        }

        // Get base temperature
        let game_time = match cloned_db.get_game_time() {
            Ok(gt) => gt,
            Err(_) => return 0,
        };

        let mut effective_temp = game_time.calculate_effective_temperature();

        // Room overrides
        if room.flags.always_hot {
            effective_temp = 35; // Sweltering
        } else if room.flags.always_cold {
            return 0; // No heat penalty in cold rooms
        } else if room.flags.indoors {
            // Indoors caps at 25°C (no heat penalty normally)
            effective_temp = effective_temp.min(25);
        }

        // High insulation adds one heat tier
        let mut insulation_bonus = 0i32;
        if let Ok(equipped) = cloned_db.get_equipped_items(&char.name) {
            let total_insulation: i32 = equipped.iter().map(|i| i.insulation).sum();
            if total_insulation >= 75 {
                insulation_bonus = 10; // Adds one tier (effectively +10°C)
            }
        }
        effective_temp += insulation_bonus;

        // Calculate base penalty
        let mut penalty: i64 = if effective_temp >= 35 {
            2 // Sweltering
        } else if effective_temp >= 25 {
            1 // Hot
        } else {
            0
        };

        // Apply trait modifiers
        if char.traits.iter().any(|t| t == "heat_sensitive") {
            penalty *= 2; // Double penalty
        }
        if char.traits.iter().any(|t| t == "thick_skinned") && penalty > 0 {
            penalty -= 1; // Reduce by 1, min 0
        }

        penalty
    });

    // get_thirst_stamina_penalty(connection_id) -> i64 - Returns 0-3 based on hydration
    let conns = connections.clone();
    engine.register_fn("get_thirst_stamina_penalty", move |connection_id: String| -> i64 {
        let conn_uuid = match uuid::Uuid::parse_str(&connection_id) {
            Ok(u) => u,
            Err(_) => return 0,
        };

        let conns_guard = conns.lock().unwrap();
        let session = match conns_guard.get(&conn_uuid) {
            Some(s) => s,
            None => return 0,
        };
        let char = match &session.character {
            Some(c) => c,
            None => return 0,
        };

        // God mode bypasses all stamina penalties
        if char.god_mode {
            return 0;
        }

        // Calculate thirst percentage
        if char.max_thirst == 0 {
            return 0;
        }
        let percent = (char.thirst * 100) / char.max_thirst;

        // Return penalty based on hydration level
        if percent < 10 {
            3 // Dehydrated
        } else if percent < 25 {
            2 // Very thirsty
        } else if percent < 50 {
            1 // Thirsty
        } else {
            0 // Well hydrated
        }
    });

    // get_activity_stamina_penalty(connection_id) -> i64 - Combined heat + thirst penalty
    let conns = connections.clone();
    let cloned_db = db.clone();
    engine.register_fn("get_activity_stamina_penalty", move |connection_id: String| -> i64 {
        let conn_uuid = match uuid::Uuid::parse_str(&connection_id) {
            Ok(u) => u,
            Err(_) => return 0,
        };

        let conns_guard = conns.lock().unwrap();
        let session = match conns_guard.get(&conn_uuid) {
            Some(s) => s,
            None => return 0,
        };
        let char = match &session.character {
            Some(c) => c,
            None => return 0,
        };

        // God mode bypasses all stamina penalties
        if char.god_mode {
            return 0;
        }

        let mut total_penalty: i64 = 0;

        // Calculate heat penalty
        if !char.traits.iter().any(|t| t == "desert_born") {
            if let Ok(Some(room)) = cloned_db.get_room_data(&char.current_room_id) {
                // Check area inheritance for climate_controlled
                let is_climate_controlled = room.flags.climate_controlled ||
                    room.area_id.and_then(|aid| cloned_db.get_area_data(&aid).ok().flatten())
                        .map(|area| area.flags.climate_controlled)
                        .unwrap_or(false);
                if !is_climate_controlled {
                    if let Ok(game_time) = cloned_db.get_game_time() {
                        let mut effective_temp = game_time.calculate_effective_temperature();

                        if room.flags.always_hot {
                            effective_temp = 35;
                        } else if room.flags.always_cold {
                            effective_temp = 0;
                        } else if room.flags.indoors {
                            effective_temp = effective_temp.min(25);
                        }

                        // High insulation adds heat
                        if let Ok(equipped) = cloned_db.get_equipped_items(&char.name) {
                            let total_insulation: i32 = equipped.iter().map(|i| i.insulation).sum();
                            if total_insulation >= 75 {
                                effective_temp += 10;
                            }
                        }

                        let mut heat_penalty: i64 = if effective_temp >= 35 {
                            2
                        } else if effective_temp >= 25 {
                            1
                        } else {
                            0
                        };

                        if char.traits.iter().any(|t| t == "heat_sensitive") {
                            heat_penalty *= 2;
                        }
                        if char.traits.iter().any(|t| t == "thick_skinned") && heat_penalty > 0 {
                            heat_penalty -= 1;
                        }

                        total_penalty += heat_penalty;
                    }
                }
            }
        }

        // Calculate thirst penalty
        if char.max_thirst > 0 {
            let percent = (char.thirst * 100) / char.max_thirst;
            let thirst_penalty = if percent < 10 {
                3
            } else if percent < 25 {
                2
            } else if percent < 50 {
                1
            } else {
                0
            };
            total_penalty += thirst_penalty;
        }

        total_penalty
    });

    // ========== Darkness/Vision Functions ==========

    // has_light_source(connection_id) -> bool - Check if character has an equipped light source
    let conns = connections.clone();
    let cloned_db = db.clone();
    engine.register_fn("has_light_source", move |connection_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    if let Ok(equipped) = cloned_db.get_equipped_items(&char.name) {
                        return equipped.iter().any(|item| item.flags.provides_light);
                    }
                }
            }
        }
        false
    });

    // can_see(connection_id) -> bool - Check if character is not blind
    let conns = connections.clone();
    engine.register_fn("can_see", move |connection_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    // Check if they have the blindness trait
                    return !char.traits.iter().any(|t| t == "blindness");
                }
            }
        }
        true // Default to can see if no character found
    });

    // is_room_dark(room_id, connection_id) -> bool - Check if room is effectively dark for character
    // Takes into account: room dark flag, time of day, city flag, night_vision, light sources
    let conns = connections.clone();
    let cloned_db = db.clone();
    engine.register_fn("is_room_dark", move |room_id: String, connection_id: String| {
        let room_uuid = match uuid::Uuid::parse_str(&room_id) {
            Ok(u) => u,
            Err(_) => return false,
        };

        let room = match cloned_db.get_room_data(&room_uuid) {
            Ok(Some(r)) => r,
            _ => return false,
        };

        // Determine if room is inherently dark
        let is_dark = if room.flags.dark {
            true // Always dark rooms (caves, dungeons)
        } else if !room.flags.indoors && !room.flags.city {
            // Outdoor non-city: dark at night
            cloned_db.get_game_time()
                .map(|gt| !gt.is_daytime())
                .unwrap_or(false)
        } else {
            false // Indoor or city rooms are lit
        };

        if !is_dark {
            return false;
        }

        // Check character's ability to see in darkness
        if let Ok(conn_uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&conn_uuid) {
                if let Some(ref char) = session.character {
                    // God mode can see in darkness
                    if char.god_mode {
                        return false;
                    }

                    // Check for night vision trait
                    if char.traits.iter().any(|t| t == "night_vision") {
                        return false;
                    }

                    // Check for light source
                    if let Ok(equipped) = cloned_db.get_equipped_items(&char.name) {
                        if equipped.iter().any(|item| item.flags.provides_light) {
                            return false;
                        }
                    }
                }
            }
        }

        true // Room is dark for this character
    });

    // ========== Gold Functions ==========

    // get_character_gold(char_name) -> i64
    let cloned_db = db.clone();
    engine.register_fn("get_character_gold", move |char_name: String| -> i64 {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(char)) => char.gold as i64,
            _ => 0,
        }
    });

    // set_character_gold(char_name, gold) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_character_gold", move |char_name: String, gold: i64| -> bool {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(mut char)) => {
                char.gold = gold as i32;
                cloned_db.save_character_data(char).is_ok()
            }
            _ => false,
        }
    });

    // add_character_gold(char_name, amount) -> bool (returns false if would go negative)
    let cloned_db = db.clone();
    engine.register_fn("add_character_gold", move |char_name: String, amount: i64| -> bool {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(mut char)) => {
                let new_gold = char.gold as i64 + amount;
                if new_gold < 0 {
                    return false;
                }
                char.gold = new_gold as i32;
                cloned_db.save_character_data(char).is_ok()
            }
            _ => false,
        }
    });

    // ========== Skill System Functions ==========

    // Helper function to get XP required for a level
    fn xp_for_level(level: i32) -> i32 {
        match level {
            0 => 100,    // 0->1
            1 => 200,    // 1->2
            2 => 350,    // 2->3
            3 => 550,    // 3->4
            4 => 800,    // 4->5
            5 => 1100,   // 5->6
            6 => 1500,   // 6->7
            7 => 2000,   // 7->8
            8 => 2600,   // 8->9
            9 => 3300,   // 9->10
            _ => 0,      // Max level
        }
    }

    // get_xp_for_level(level) -> i64
    engine.register_fn("get_xp_for_level", move |level: i64| -> i64 {
        xp_for_level(level as i32) as i64
    });

    // get_skill_level(char_name, skill_name) -> i64
    let cloned_db = db.clone();
    engine.register_fn("get_skill_level", move |char_name: String, skill_name: String| -> i64 {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(char)) => {
                char.skills.get(&skill_name.to_lowercase())
                    .map(|s| s.level as i64)
                    .unwrap_or(0)
            }
            _ => 0,
        }
    });

    // get_skill_experience(char_name, skill_name) -> i64
    let cloned_db = db.clone();
    engine.register_fn("get_skill_experience", move |char_name: String, skill_name: String| -> i64 {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(char)) => {
                char.skills.get(&skill_name.to_lowercase())
                    .map(|s| s.experience as i64)
                    .unwrap_or(0)
            }
            _ => 0,
        }
    });

    // get_all_skills(char_name) -> Map of skill_name -> {level, experience}
    let cloned_db = db.clone();
    engine.register_fn("get_all_skills", move |char_name: String| -> rhai::Map {
        let mut result = rhai::Map::new();
        if let Ok(Some(char)) = cloned_db.get_character_data(&char_name.to_lowercase()) {
            for (name, progress) in &char.skills {
                let mut skill_map = rhai::Map::new();
                skill_map.insert("level".into(), rhai::Dynamic::from(progress.level as i64));
                skill_map.insert("experience".into(), rhai::Dynamic::from(progress.experience as i64));
                skill_map.insert("xp_to_level".into(), rhai::Dynamic::from(xp_for_level(progress.level) as i64));
                result.insert(name.clone().into(), rhai::Dynamic::from(skill_map));
            }
        }
        result
    });

    // set_skill_level(char_name, skill_name, level) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_skill_level", move |char_name: String, skill_name: String, level: i64| -> bool {
        let level = level.clamp(0, 10) as i32;
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(mut char)) => {
                let skill_key = skill_name.to_lowercase();
                let entry = char.skills.entry(skill_key).or_insert(crate::SkillProgress::default());
                entry.level = level;
                entry.experience = 0; // Reset XP when setting level directly
                cloned_db.save_character_data(char).is_ok()
            }
            _ => false,
        }
    });

    // add_skill_experience(char_name, skill_name, amount) -> bool (returns true if leveled up)
    let cloned_db = db.clone();
    engine.register_fn("add_skill_experience", move |char_name: String, skill_name: String, amount: i64| -> bool {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(mut char)) => {
                let skill_key = skill_name.to_lowercase();
                let entry = char.skills.entry(skill_key).or_insert(crate::SkillProgress::default());

                // Don't add XP if already at max level
                if entry.level >= 10 {
                    let _ = cloned_db.save_character_data(char);
                    return false;
                }

                entry.experience += amount as i32;

                let mut leveled_up = false;
                loop {
                    let xp_needed = xp_for_level(entry.level);
                    if xp_needed == 0 || entry.experience < xp_needed || entry.level >= 10 {
                        break;
                    }
                    entry.experience -= xp_needed;
                    entry.level += 1;
                    leveled_up = true;
                    if entry.level >= 10 {
                        entry.experience = 0; // No XP overflow at max
                        break;
                    }
                }

                let _ = cloned_db.save_character_data(char);
                leveled_up
            }
            _ => false,
        }
    });

    // ========== Forage Cooldown Functions ==========

    // get_forage_cooldown(char_name, room_id) -> i64 (seconds remaining, 0 = can forage)
    let cloned_db = db.clone();
    engine.register_fn("get_forage_cooldown", move |char_name: String, room_id: String| -> i64 {
        let cooldown_duration = 60; // 60 second cooldown per room
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(char)) => {
                if let Some(timestamp) = char.foraged_rooms.get(&room_id) {
                    let now = std::time::SystemTime::now()
                        .duration_since(std::time::UNIX_EPOCH)
                        .map(|d| d.as_secs() as i64)
                        .unwrap_or(0);
                    let elapsed = now - timestamp;
                    if elapsed < cooldown_duration {
                        return cooldown_duration - elapsed;
                    }
                }
                0 // No cooldown or cooldown expired
            }
            _ => 0,
        }
    });

    // set_forage_timestamp(char_name, room_id) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_forage_timestamp", move |char_name: String, room_id: String| -> bool {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(mut char)) => {
                let now = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map(|d| d.as_secs() as i64)
                    .unwrap_or(0);
                char.foraged_rooms.insert(room_id, now);
                cloned_db.save_character_data(char).is_ok()
            }
            _ => false,
        }
    });

    // clear_forage_history(char_name) -> bool - Clear all forage timestamps
    let cloned_db = db.clone();
    engine.register_fn("clear_forage_history", move |char_name: String| -> bool {
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(mut char)) => {
                char.foraged_rooms.clear();
                cloned_db.save_character_data(char).is_ok()
            }
            _ => false,
        }
    });

    // clear_expired_forage_cooldowns(char_name) -> bool
    // Removes forage entries older than 1 hour
    let cloned_db = db.clone();
    engine.register_fn("clear_expired_forage_cooldowns", move |char_name: String| -> bool {
        let one_hour = 3600; // 1 hour in seconds
        match cloned_db.get_character_data(&char_name.to_lowercase()) {
            Ok(Some(mut char)) => {
                let now = std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .map(|d| d.as_secs() as i64)
                    .unwrap_or(0);
                let orig_len = char.foraged_rooms.len();
                char.foraged_rooms.retain(|_, timestamp| now - *timestamp < one_hour);
                if char.foraged_rooms.len() < orig_len {
                    cloned_db.save_character_data(char).is_ok()
                } else {
                    true // Nothing to clean
                }
            }
            _ => false,
        }
    });

    // ========== Character Stats Functions ==========

    // get_player_stat(connection_id, stat_name) -> i64 - Get a player's stat value
    // stat_name: str, dex, con, int, wis, cha
    let conns = connections.clone();
    engine.register_fn("get_player_stat", move |connection_id: String, stat_name: String| -> i64 {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    return match stat_name.to_lowercase().as_str() {
                        "str" | "strength" => char.stat_str as i64,
                        "dex" | "dexterity" => char.stat_dex as i64,
                        "con" | "constitution" => char.stat_con as i64,
                        "int" | "intelligence" => char.stat_int as i64,
                        "wis" | "wisdom" => char.stat_wis as i64,
                        "cha" | "charisma" => char.stat_cha as i64,
                        _ => 0,
                    };
                }
            }
        }
        0
    });

    // set_player_stat(connection_id, stat_name, value) -> bool
    // Updates both session and database
    let conns = connections.clone();
    let cloned_db = db.clone();
    engine.register_fn("set_player_stat", move |connection_id: String, stat_name: String, value: i64| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let mut conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get_mut(&uuid) {
                if let Some(ref mut char) = session.character {
                    let stat_val = value as i32;
                    match stat_name.to_lowercase().as_str() {
                        "str" | "strength" => char.stat_str = stat_val,
                        "dex" | "dexterity" => char.stat_dex = stat_val,
                        "con" | "constitution" => char.stat_con = stat_val,
                        "int" | "intelligence" => char.stat_int = stat_val,
                        "wis" | "wisdom" => char.stat_wis = stat_val,
                        "cha" | "charisma" => char.stat_cha = stat_val,
                        _ => return false,
                    };
                    return cloned_db.save_character_data(char.clone()).is_ok();
                }
            }
        }
        false
    });

    // get_player_max_carry_weight(connection_id) -> i64
    // Formula: 50 + (STR * 10)
    let conns = connections.clone();
    engine.register_fn("get_player_max_carry_weight", move |connection_id: String| -> i64 {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    return 50 + (char.stat_str as i64 * 10);
                }
            }
        }
        150 // Default for STR 10
    });

    // get_player_calculated_max_health(connection_id) -> i64
    // Formula: 20 + (CON * 5) + (level * 5)
    let conns = connections.clone();
    engine.register_fn("get_player_calculated_max_health", move |connection_id: String| -> i64 {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    return 20 + (char.stat_con as i64 * 5) + (char.level as i64 * 5);
                }
            }
        }
        75 // Default for CON 10, level 1
    });

    // get_player_calculated_max_stamina(connection_id) -> i64
    // Formula: 50 + (CON * 3) + (STR * 2)
    let conns = connections.clone();
    engine.register_fn("get_player_calculated_max_stamina", move |connection_id: String| -> i64 {
        if let Ok(uuid) = uuid::Uuid::parse_str(&connection_id) {
            let conns_guard = conns.lock().unwrap();
            if let Some(session) = conns_guard.get(&uuid) {
                if let Some(ref char) = session.character {
                    return 50 + (char.stat_con as i64 * 3) + (char.stat_str as i64 * 2);
                }
            }
        }
        100 // Default for CON 10, STR 10
    });
}
