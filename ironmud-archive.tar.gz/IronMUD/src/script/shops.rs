// src/script/shops.rs
// Shop and vending machine system functions

use rhai::Engine;
use std::sync::Arc;
use crate::db::Db;

/// Register shop-related functions
pub fn register(engine: &mut Engine, db: Arc<Db>) {
    // ========== Shopkeeper Functions ==========

    // find_shopkeeper_in_room(room_id) -> MobileData or ()
    let cloned_db = db.clone();
    engine.register_fn("find_shopkeeper_in_room", move |room_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&room_id) {
            match cloned_db.get_mobiles_in_room(&uuid) {
                Ok(mobiles) => {
                    for mobile in mobiles {
                        if mobile.flags.shopkeeper && !mobile.is_prototype {
                            return rhai::Dynamic::from(mobile);
                        }
                    }
                    rhai::Dynamic::UNIT
                }
                _ => rhai::Dynamic::UNIT,
            }
        } else {
            rhai::Dynamic::UNIT
        }
    });

    // add_shop_stock(mobile_id, vnum) -> bool
    let cloned_db = db.clone();
    engine.register_fn("add_shop_stock", move |mobile_id: String, vnum: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.get_mobile_data(&uuid) {
                Ok(Some(mut mobile)) => {
                    if !mobile.shop_stock.contains(&vnum) {
                        mobile.shop_stock.push(vnum);
                        return cloned_db.save_mobile_data(mobile).is_ok();
                    }
                    true // Already in stock
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // remove_shop_stock(mobile_id, vnum) -> bool
    let cloned_db = db.clone();
    engine.register_fn("remove_shop_stock", move |mobile_id: String, vnum: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.get_mobile_data(&uuid) {
                Ok(Some(mut mobile)) => {
                    mobile.shop_stock.retain(|v| v != &vnum);
                    cloned_db.save_mobile_data(mobile).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // get_shop_inventory(mobile_id) -> Array of ItemData
    let cloned_db = db.clone();
    engine.register_fn("get_shop_inventory", move |mobile_id: String| -> Vec<rhai::Dynamic> {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.get_mobile_data(&uuid) {
                Ok(Some(mobile)) => {
                    let mut items = Vec::new();
                    for item_id in &mobile.shop_inventory {
                        if let Ok(Some(item)) = cloned_db.get_item_data(item_id) {
                            items.push(rhai::Dynamic::from(item));
                        }
                    }
                    items
                }
                _ => Vec::new(),
            }
        } else {
            Vec::new()
        }
    });

    // add_to_shop_inventory(mobile_id, item_id) -> bool
    let cloned_db = db.clone();
    engine.register_fn("add_to_shop_inventory", move |mobile_id: String, item_id: String| -> bool {
        if let Ok(mobile_uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(item_uuid) = uuid::Uuid::parse_str(&item_id) {
                match cloned_db.get_mobile_data(&mobile_uuid) {
                    Ok(Some(mut mobile)) => {
                        if !mobile.shop_inventory.contains(&item_uuid) {
                            mobile.shop_inventory.push(item_uuid);
                            return cloned_db.save_mobile_data(mobile).is_ok();
                        }
                        true
                    }
                    _ => false,
                }
            } else {
                false
            }
        } else {
            false
        }
    });

    // remove_from_shop_inventory(mobile_id, item_id) -> bool
    let cloned_db = db.clone();
    engine.register_fn("remove_from_shop_inventory", move |mobile_id: String, item_id: String| -> bool {
        if let Ok(mobile_uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(item_uuid) = uuid::Uuid::parse_str(&item_id) {
                match cloned_db.get_mobile_data(&mobile_uuid) {
                    Ok(Some(mut mobile)) => {
                        mobile.shop_inventory.retain(|id| id != &item_uuid);
                        cloned_db.save_mobile_data(mobile).is_ok()
                    }
                    _ => false,
                }
            } else {
                false
            }
        } else {
            false
        }
    });

    // set_shop_buy_rate(mobile_id, rate) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_shop_buy_rate", move |mobile_id: String, rate: i64| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.get_mobile_data(&uuid) {
                Ok(Some(mut mobile)) => {
                    mobile.shop_buy_rate = rate as i32;
                    cloned_db.save_mobile_data(mobile).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // set_shop_sell_rate(mobile_id, rate) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_shop_sell_rate", move |mobile_id: String, rate: i64| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.get_mobile_data(&uuid) {
                Ok(Some(mut mobile)) => {
                    mobile.shop_sell_rate = rate as i32;
                    cloned_db.save_mobile_data(mobile).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // calculate_buy_price(base_value, buy_rate) -> i64
    // Price shop pays to player = base_value * buy_rate / 100
    engine.register_fn("calculate_buy_price", |base_value: i64, buy_rate: i64| -> i64 {
        base_value * buy_rate / 100
    });

    // calculate_sell_price(base_value, sell_rate) -> i64
    // Price player pays to shop = base_value * sell_rate / 100
    engine.register_fn("calculate_sell_price", |base_value: i64, sell_rate: i64| -> i64 {
        base_value * sell_rate / 100
    });

    // get_shop_buys_types(mobile_id) -> Array of strings
    let cloned_db = db.clone();
    engine.register_fn("get_shop_buys_types", move |mobile_id: String| -> rhai::Array {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mobile)) = cloned_db.get_mobile_data(&uuid) {
                return mobile.shop_buys_types.iter()
                    .map(|s| rhai::Dynamic::from(s.clone()))
                    .collect();
            }
        }
        rhai::Array::new()
    });

    // set_shop_buys_types(mobile_id, types_array) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_shop_buys_types", move |mobile_id: String, types: rhai::Array| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            match cloned_db.get_mobile_data(&uuid) {
                Ok(Some(mut mobile)) => {
                    mobile.shop_buys_types = types.iter()
                        .filter_map(|v| v.clone().into_string().ok())
                        .collect();
                    cloned_db.save_mobile_data(mobile).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // shop_will_buy_type(mobile_id, item_type_str) -> bool
    // Checks if the shopkeeper will buy items of this type
    let cloned_db = db.clone();
    engine.register_fn("shop_will_buy_type", move |mobile_id: String, item_type: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&mobile_id) {
            if let Ok(Some(mobile)) = cloned_db.get_mobile_data(&uuid) {
                // Empty list = buys nothing
                if mobile.shop_buys_types.is_empty() {
                    return false;
                }
                // Check for "all" - buys any type
                let item_type_lower = item_type.to_lowercase();
                for buy_type in &mobile.shop_buys_types {
                    if buy_type.to_lowercase() == "all" {
                        return true;
                    }
                    if buy_type.to_lowercase() == item_type_lower {
                        return true;
                    }
                }
                return false;
            }
        }
        false
    });

    // ========== Vending Machine Functions ==========

    // find_vending_machine_in_room(room_id) -> ItemData or ()
    let cloned_db = db.clone();
    engine.register_fn("find_vending_machine_in_room", move |room_id: String| {
        if let Ok(uuid) = uuid::Uuid::parse_str(&room_id) {
            match cloned_db.get_items_in_room(&uuid) {
                Ok(items) => {
                    for item in items {
                        if item.flags.vending && !item.is_prototype {
                            return rhai::Dynamic::from(item);
                        }
                    }
                    rhai::Dynamic::UNIT
                }
                _ => rhai::Dynamic::UNIT,
            }
        } else {
            rhai::Dynamic::UNIT
        }
    });

    // add_vending_stock(item_id, vnum) -> bool
    let cloned_db = db.clone();
    engine.register_fn("add_vending_stock", move |item_id: String, vnum: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&item_id) {
            match cloned_db.get_item_data(&uuid) {
                Ok(Some(mut item)) => {
                    if !item.vending_stock.contains(&vnum) {
                        item.vending_stock.push(vnum);
                        return cloned_db.save_item_data(item).is_ok();
                    }
                    true // Already in stock
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // remove_vending_stock(item_id, vnum) -> bool
    let cloned_db = db.clone();
    engine.register_fn("remove_vending_stock", move |item_id: String, vnum: String| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&item_id) {
            match cloned_db.get_item_data(&uuid) {
                Ok(Some(mut item)) => {
                    item.vending_stock.retain(|v| v != &vnum);
                    cloned_db.save_item_data(item).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });

    // set_vending_sell_rate(item_id, rate) -> bool
    let cloned_db = db.clone();
    engine.register_fn("set_vending_sell_rate", move |item_id: String, rate: i64| -> bool {
        if let Ok(uuid) = uuid::Uuid::parse_str(&item_id) {
            match cloned_db.get_item_data(&uuid) {
                Ok(Some(mut item)) => {
                    item.vending_sell_rate = rate as i32;
                    cloned_db.save_item_data(item).is_ok()
                }
                _ => false,
            }
        } else {
            false
        }
    });
}
