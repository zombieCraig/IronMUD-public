# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build and Test Commands

```bash
# Build
cargo build
cargo build --release

# Run the server (listens on TCP port 4000) - will block
cargo run

# Run all tests (preferred way to verify changes)
cargo test

# Run integration tests only
cargo test --test server

# Run a specific test
cargo test test_character_system_lifecycle
```

## Architecture Overview

IronMUD is an async MUD engine that separates the Rust core (networking, database, scripting host) from game logic (Rhai scripts). This enables hot-reloading of game content without recompilation.

### Core Components

**World State** (`src/lib.rs`): Central hub wrapped in `Arc<Mutex<World>>`. Contains the Rhai engine, database connection, script cache, and a reference to shared connections.

**SharedConnections** (`src/lib.rs`): `Arc<Mutex<HashMap<ConnectionId, PlayerSession>>>` - Separated from World to prevent deadlock when Rhai scripts call registered functions.

**Networking** (`src/lib.rs`): Tokio-based TCP server on port 4000. Each client connection spawns three tasks:
- Read task: parses input, sends to command channel
- Write task: forwards messages from channel to socket
- Main loop: executes Rhai scripts based on commands

**Database** (`src/db.rs`): Sled embedded database wrapper. Stores character data as JSON in the "characters" tree. Includes Argon2 password hashing.

**Scripting** (`src/script/`): Modular system registering Rust functions for Rhai scripts. Split into domain-based submodules:
- `mod.rs` - Type registrations, core DB/connection functions, OLC mode
- `items.rs` - Item system, containers, liquids
- `mobiles.rs` - Mobile system, dialogue
- `rooms.rs` - Room CRUD, doors, exits, display
- `triggers.rs` - All trigger systems (room, item, mobile)
- `shops.rs` - Shop/vending functions
- `areas.rs` - Area CRUD, permissions, forage tables
- `characters.rs` - Creation wizard, permissions, thirst, stamina, skills
- `crafting.rs` - Recipe system
- `fishing.rs` - Fishing state functions
- `utilities.rs` - MXP, ANSI colors, terminal
- `spawn.rs` - Spawn points
- `ai.rs` - Claude, Gemini, Matrix integration

### Critical: Avoiding Deadlock

The codebase uses `std::sync::Mutex` which is NOT reentrant. When Rhai scripts execute, registered functions may need to access connections. The solution:

1. `handle_connection` clones the AST and releases the World lock BEFORE calling `engine.call_fn`
2. Rhai functions receive `SharedConnections` directly, not `SharedState`
3. This allows scripts to lock connections independently of the World lock

### Data Flow

```
TCP Input → handle_read() → command channel → main loop
                                                 ↓
                                    scripts/commands/{cmd}.rhai
                                                 ↓
                            Rhai registered functions (db, auth, messaging)
                                                 ↓
TCP Output ← handle_write() ← message channel ← script output
```

### Script System

Game commands live in `scripts/commands/*.rhai`. Each script exports:
```rhai
fn run_command(args, connection_id)
```

Available Rhai functions (registered in `src/script/` modules):
- `get_character_data(name)` / `save_character_data(char)` - persistence
- `new_character(name, password_hash, room_id)` - create CharacterData object
- `hash_password(password)` / `verify_password(password, hash)` - auth
- `set_player_character(conn_id, char)` / `get_player_character(conn_id)` / `clear_player_character(conn_id)` - session
- `send_client_message(conn_id, message)` / `disconnect_client(conn_id)` - I/O

### Rhai Gotchas

- `trim()` is NOT a built-in Rhai string method - use `== ""` for empty checks
- Rhai maps (`#{...}`) are NOT the same as registered Rust types - use `new_character()` constructor
- Register Rhai functions BEFORE calling `load_scripts()` or scripts won't find them
- **Expression complexity limit**: Deeply nested if-else chains will fail with "Expression exceeds maximum complexity". Fix by extracting logic into helper functions using early returns:
  ```rhai
  // BAD - too many nested else-if
  if x == "a" { ... }
  else if x == "b" { ... }
  else if x == "c" { ... }
  // ... 8+ branches causes error

  // GOOD - use helper function with early returns
  fn get_value(x) {
      if x == "a" { return "result_a"; }
      if x == "b" { return "result_b"; }
      if x == "c" { return "result_c"; }
      return "default";
  }
  ```

### Key Types

- `ConnectionId`: UUID identifying a client session
- `PlayerSession`: Contains optional `CharacterData` and output channel sender
- `CharacterData`: name, password_hash, current_room_id (Uuid)
- `SharedConnections`: `Arc<Mutex<HashMap<ConnectionId, PlayerSession>>>`
- `SharedState`: `Arc<Mutex<World>>`

## Project Status

- Telnet networking: functional
- Sled database: functional
- Rhai scripting: functional
- Character system (create/login/logout): functional
- Hot-reloading: functional (watch_scripts monitors scripts/ directory)
- Web client (Axum): disabled/incomplete
- Matrix integration: on hold (outdated SDK)

## Item System Dependencies

When modifying the item system, multiple files must be updated in sync. Use these checklists to ensure complete changes.

### Adding a New Item Flag

- [ ] `src/lib.rs` - Add field to `ItemFlags` struct (~line 1177)
- [ ] `src/script/items.rs` - Add to `set_item_flag()` and `get_item_flag()` matches
- [ ] `scripts/commands/oedit.rhai`:
  - [ ] `copy_item_flags()` - Add copy logic (~line 663)
  - [ ] `build_flags_display()` - Add to inline display (~line 1001)
  - [ ] `show_item_flags()` - Add detailed display with description (~line 1212)
  - [ ] `handle_flag_subcommand()` - Add to available flags error message (~line 583)
- [ ] `scripts/commands/examine.rhai` - Add to flag display if player-visible (~line 83)
- [ ] Affected commands - Add checks where flag should block/enable behavior:
  - `drop.rhai`, `get.rhai`, `sell.rhai`, `give.rhai`, `junk.rhai`, etc.

### Adding a New Item Type

- [ ] `src/lib.rs`:
  - [ ] Add variant to `ItemType` enum (~line 858)
  - [ ] Add to `ItemType::from_str()` parser (~line 871)
  - [ ] Add to `ItemType::to_display_string()` (~line 885)
- [ ] `scripts/commands/oedit.rhai`:
  - [ ] `handle_type_subcommand()` - Add to valid_types array (~line 441)
  - [ ] `handle_spawn_subcommand()` - Add type-specific copy logic (~line 619+)
  - [ ] `show_item_properties()` - Add type-specific display section (~line 961+)
  - [ ] `build_commands_help()` - Add type-specific command help (~line 1165+)
- [ ] Type-specific commands (e.g., for containers: get.rhai, put.rhai, look.rhai)

### Adding a New Item Property

- [ ] `src/lib.rs` - Add field to `ItemData` struct (~line 1214), use `#[serde(default)]` for optional
- [ ] `src/lib.rs` - Initialize in `ItemData::new()` (~line 1313)
- [ ] `src/script/items.rs`:
  - [ ] Register getter on ItemData type
  - [ ] Register `set_item_PROPERTY()` function
- [ ] `scripts/commands/oedit.rhai`:
  - [ ] Add `handle_PROPERTY_subcommand()` function
  - [ ] Add case in `handle_subcommand()` (~line 194+)
  - [ ] Add to `handle_spawn_subcommand()` copy logic (~line 598+)
  - [ ] Add to `show_item_properties()` display (~line 921+)
  - [ ] Add to `build_commands_help()` (~line 1138+)
- [ ] `scripts/commands/examine.rhai` - Add display if player-visible

### Adding a New Trigger Type

- [ ] `src/lib.rs` - Add variant to `ItemTriggerType` enum (~line 608)
- [ ] `src/script/triggers.rs` - Add to `get_item_trigger_type()` match
- [ ] `scripts/commands/oedit.rhai`:
  - [ ] `add_trigger()` - Add to valid_types array (~line 1495)
  - [ ] `show_trigger_help()` - Update help text (~line 1433)
- [ ] Implement trigger fire point in appropriate command script

### Adding a New Liquid Type

- [ ] `src/lib.rs`:
  - [ ] Add variant to `LiquidType` enum (~line 1093)
  - [ ] Add to `LiquidType::from_str()` (~line 1111)
  - [ ] Add to `LiquidType::to_display_string()` (~line 1130)
- [ ] `src/script/items.rs` - Add to `get_all_liquid_types()` list

### Adding a New Effect Type

- [ ] `src/lib.rs`:
  - [ ] Add variant to `EffectType` enum (~line 1007)
  - [ ] Add to `EffectType::from_str()` (~line 1031)
  - [ ] Add to `EffectType::to_display_string()` (~line 1056)
- [ ] `src/script/items.rs` - Add to `get_all_effect_types()` list
- [ ] `scripts/commands/eat.rhai` and/or `drink.rhai` - Implement effect behavior

### Adding a New Wear Location

- [ ] `src/lib.rs`:
  - [ ] Add variant to `WearLocation` enum (~line 759)
  - [ ] Add to `WearLocation::from_str()` (~line 781)
  - [ ] Add to `WearLocation::to_display_string()` (~line 807)
- [ ] `src/script/items.rs` - Add to `get_all_wear_locations()` list
- [ ] `scripts/commands/wear.rhai` - Handle new slot if special logic needed

### Modifying Vending Machine System

- [ ] `scripts/commands/oedit.rhai`:
  - [ ] `show_vending_config()` - Update display (~line 1618)
  - [ ] `handle_spawn_subcommand()` - Update copy logic (~line 651)
- [ ] `scripts/commands/buy.rhai` - Update purchase logic (~line 101)
- [ ] `scripts/commands/list.rhai` - Update listing (~line 64)

### Key File Locations

| Component | Rust Definition | Rhai Functions | Editor | Consumer Commands |
|-----------|----------------|----------------|--------|-------------------|
| Item Flags | lib.rs:1177 | script/items.rs | oedit.rhai | drop, get, sell, examine |
| Item Types | lib.rs:858 | script/items.rs | oedit.rhai | examine, sell |
| Triggers | lib.rs:608 | script/triggers.rs | oedit.rhai | get, drop, examine |
| Containers | lib.rs:1244 | script/items.rs | oedit.rhai | get, put, look |
| Liquids | lib.rs:1257 | script/items.rs | oedit.rhai | drink, fill |
| Food | lib.rs:1268 | script/items.rs | oedit.rhai | eat |
| Vending | lib.rs:1305 | script/shops.rs | oedit.rhai | buy, list |

### Related Editors

- `medit.rhai` - Mobile/NPC editor (similar patterns, different types)
- `redit.rhai` - Room editor (room flags, exits, triggers)
- `spedit.rhai` - Spawn point editor (references vnums)

Note: Shop editing is done through `medit.rhai` shop subcommands, not a separate sedit.rhai.

## Mobile System Dependencies

When modifying the mobile/NPC system, multiple files must be updated in sync. Use these checklists to ensure complete changes.

### Adding a New Mobile Flag

- [ ] `src/lib.rs` - Add field to `MobileFlags` struct (~line 1371)
- [ ] `src/script/mobiles.rs` - Add case in `set_mobile_flag()`
- [ ] `scripts/commands/medit.rhai`:
  - [ ] `get_mobile_flag_value()` - Add case (~line 479)
  - [ ] `build_flag_line()` - Add display with description (~line 707)
  - [ ] Error message - Add to available flags list (~line 454)
- [ ] Affected commands - Implement flag behavior where needed

### Adding a New Mobile Property

- [ ] `src/lib.rs` - Add field to `MobileData` struct (~line 1385), use `#[serde(default)]`
- [ ] `src/lib.rs` - Initialize in `MobileData::new()` (~line 1480)
- [ ] `src/script/mobiles.rs`:
  - [ ] Register getter on MobileData type
  - [ ] Register `set_mobile_PROPERTY()` function
- [ ] `scripts/commands/medit.rhai`:
  - [ ] Add `handle_PROPERTY_subcommand()` function
  - [ ] Add case in `handle_subcommand()` (~line 190+)
  - [ ] Add to `show_mobile_properties()` display (~line 567)
  - [ ] Add to `build_commands_help()` (~line 642)

### Adding a New Mobile Trigger Type

- [ ] `src/lib.rs` - Add variant to `MobileTriggerType` enum (~line 649)
- [ ] `src/script/triggers.rs`:
  - [ ] Add case in `get_mobile_trigger_type()`
  - [ ] Add fire logic in `fire_mobile_trigger()`
- [ ] `scripts/commands/medit.rhai`:
  - [ ] `is_valid_mobile_trigger_type()` - Add to valid types (~line 1284)
  - [ ] `show_trigger_help()` - Update help text (~line 1180)
- [ ] Implement trigger fire point in appropriate command script (say.rhai, go.rhai, etc.)

### Modifying Shop System

- [ ] `scripts/commands/medit.rhai`:
  - [ ] `show_shop_config()` - Update display (~line 814)
  - [ ] `handle_shop_subcommand()` - Add handler (~line 772)
- [ ] `scripts/commands/buy.rhai` - Update purchase logic
- [ ] `scripts/commands/sell.rhai` - Update sell logic
- [ ] `scripts/commands/list.rhai` - Update listing if needed

### Adding a New Mobile Stat

- [ ] `src/lib.rs` - Add `stat_XXX` field to `MobileData` (~line 1417)
- [ ] `src/script/mobiles.rs` - Add case in `set_mobile_stat()`
- [ ] `scripts/commands/medit.rhai`:
  - [ ] `handle_stat_subcommand()` - Add to valid stats (~line 405)
  - [ ] `show_mobile_properties()` - Add display (~line 567)

### Modifying Dialogue System

- [ ] `src/script/mobiles.rs`:
  - [ ] `set_mobile_dialogue()`
  - [ ] `get_mobile_dialogue()`
  - [ ] `remove_mobile_dialogue()`
- [ ] `scripts/commands/medit.rhai` - Dialogue handlers (~line 524)
- [ ] `scripts/commands/say.rhai` - Keyword matching logic (~line 45)

### Key File Locations

| Component | Rust Definition | Rhai Functions | Editor | Consumer Commands |
|-----------|----------------|----------------|--------|-------------------|
| Mobile Flags | lib.rs:1371 | script/mobiles.rs | medit.rhai | combat, AI |
| Mobile Stats | lib.rs:1417 | script/mobiles.rs | medit.rhai | combat |
| Triggers | lib.rs:649 | script/triggers.rs | medit.rhai | say, go |
| Shop System | lib.rs:1438 | script/shops.rs | medit.rhai | buy, sell, list |
| Dialogue | lib.rs:1435 | script/mobiles.rs | medit.rhai | say |
| Prototype | lib.rs:1403 | script/mobiles.rs | medit.rhai | mspawn |

### Related Commands

- `mspawn.rhai` - Spawn mobile from prototype
- `mlist.rhai` - List all mobiles
- `mfind.rhai` - Search mobiles
- `mdelete.rhai` - Delete mobile
- `mrefresh.rhai` - Refresh instance from prototype

## Room System Dependencies

When modifying the room system, multiple files must be updated in sync. Use these checklists to ensure complete changes.

### Adding a New Room Flag

- [ ] `src/lib.rs` - Add field to `RoomFlags` struct (~line 233)
- [ ] `src/script/rooms.rs`:
  - [ ] Add case in `set_room_flag()`
  - [ ] Add case in `get_room_flag()`
- [ ] `scripts/commands/redit.rhai`:
  - [ ] Quick display - Add to flag string building (~line 620)
  - [ ] Detailed display - Add toggle in `redit flags` (~line 728-775)
  - [ ] Add to `valid_flags` array (~line 785)
- [ ] Affected commands - Implement flag behavior:
  - `go.rhai` if affects movement (e.g., `difficult_terrain`)
  - `look.rhai` if affects visibility (e.g., `dark`)

### Adding a New Room Trigger Type

- [ ] `src/lib.rs` - Add variant to `TriggerType` enum (~line 268)
- [ ] `src/script/triggers.rs`:
  - [ ] Add case in `get_trigger_type()`
  - [ ] Add case in `add_room_trigger()`
  - [ ] Add case in `add_room_trigger_with_args()`
  - [ ] Add case in `add_room_trigger_with_args_from()`
  - [ ] Add case in `fire_room_trigger()`
- [ ] `scripts/commands/redit.rhai`:
  - [ ] Add to `valid_types` array (~line 279)
  - [ ] Add to help text (~line 244, 268, 288)
- [ ] Implement trigger fire point in appropriate command (go.rhai, look.rhai, etc.)

### Adding a New Door Property

- [ ] `src/lib.rs` - Add field to `DoorState` struct (~line 222)
- [ ] `src/script/rooms.rs` - Add `set_door_PROPERTY()` function
- [ ] `scripts/commands/redit.rhai`:
  - [ ] Add to `build_door_list()` display (~line 1024)
  - [ ] Add subcommand handler in `handle_door_subcommand()` (~line 1250)
  - [ ] Add to `show_door_help()` (~line 1232)
- [ ] `scripts/commands/go.rhai` - If affects movement blocking
- [ ] `scripts/commands/look.rhai` - If affects door display

### Modifying Exit System

- [ ] `src/lib.rs` - `RoomExits` struct (~line 212)
- [ ] `src/script/rooms.rs`:
  - [ ] `set_room_exit()`
  - [ ] `clear_room_exit()`
  - [ ] `get_exit_target()`
- [ ] `scripts/commands/redit.rhai` - Exit display (~line 583)
- [ ] `scripts/commands/go.rhai` - `get_exit_for_direction()` (~line 23)
- [ ] `scripts/commands/dig.rhai` - Room creation with exits
- [ ] `scripts/commands/exits.rhai` - Exit listing

### Adding Extra Description Features

- [ ] `src/lib.rs` - `ExtraDesc` struct (~line 260)
- [ ] `src/script/rooms.rs`:
  - [ ] `add_room_extra_desc()`
  - [ ] `get_room_extra_desc()`
  - [ ] `remove_room_extra_desc()`
- [ ] `scripts/commands/redit.rhai` - Extra desc editor (~line 854)
- [ ] `scripts/commands/look.rhai` - Keyword lookup (~line 139)

### Key File Locations

| Component | Rust Definition | Rhai Functions | Editor | Consumer Commands |
|-----------|----------------|----------------|--------|-------------------|
| Room Flags | lib.rs:233 | script/rooms.rs | redit.rhai | go, look |
| Exits | lib.rs:212 | script/rooms.rs | redit.rhai | go, exits, dig |
| Doors | lib.rs:222 | script/rooms.rs | redit.rhai | go, look, open/close |
| Extra Descs | lib.rs:260 | script/rooms.rs | redit.rhai | look |
| Triggers | lib.rs:268 | script/triggers.rs | redit.rhai | go, look |
| Areas | lib.rs:323 | script/areas.rs | redit.rhai | dig |

### Related Commands

- `dig.rhai` - Create rooms and exits
- `link.rhai` / `unlink.rhai` - Manual exit management
- `exits.rhai` - Display room exits
- `open.rhai` / `close.rhai` - Door state commands
- `lock.rhai` / `unlock.rhai` - Door lock commands
- `rcopy.rhai` - Copy room attributes between rooms

### Copying Room Attributes (rcopy.rhai)

The `rcopy` command copies properties from a source room to the current room. Useful for syncing fishing stock across a lake or applying the same triggers to multiple rooms.

**Usage:** `rcopy <source_vnum> [category]`

**Categories:** all, flags, desc, seasonal, triggers, water, doors, extra

| Category | What Gets Copied | Notes |
|----------|------------------|-------|
| flags | All 12 room flags | Overwrites target flags |
| desc | Main description | Single field |
| seasonal | spring/summer/autumn/winter_desc | All 4 seasons |
| triggers | All triggers with args/interval/chance | Appends to existing |
| water | water_type + catch_table | Replaces existing catch table |
| doors | Door configs (name, desc, key, state) | Only where exits exist |
| extra | Extra descriptions | Appends to existing |

**NOT copied:** title, vnum, area_id, exits (room-specific properties)

**Tab completion:** Requires `src/completion.rs` - see `complete_rcopy()` and `RCOPY_CATEGORIES`

### Room Trigger Types

Room triggers fire automatically based on events. Add triggers with `redit trigger add <type> <script>`.

| Trigger Type | Fires When | Context Values |
|--------------|------------|----------------|
| on_enter | Player enters room | direction, source_room |
| on_exit | Player leaves room | direction, target_room |
| on_look | Player looks at room | (none) |
| periodic | Every N seconds (configurable) | (none) |
| on_time_change | Time of day changes | old_time, new_time, is_dawn, is_dusk, is_night, is_day |
| on_weather_change | Weather changes | old_weather, new_weather, is_raining, is_snowing, is_clear |
| on_season_change | Season changes | old_season, new_season, is_spring, is_summer, is_autumn, is_winter |
| on_month_change | Month changes (1-12) | old_month, new_month, new_day, new_year, is_festival |

**Note:** `is_festival` is true for months 4, 8, and 12 (quarterly festivals).

### Trigger Engine Functions

These functions are available to room trigger scripts:

| Function | Description |
|----------|-------------|
| `send_client_message(conn_id, msg)` | Send message to player |
| `broadcast_to_room(room_id, msg, exclude)` | Send message to all in room |
| `get_player_character(conn_id)` | Get CharacterData |
| `get_room_data(room_id)` | Get RoomData |
| `set_room_flag(room_id, flag, value)` | Modify room flag (e.g., "city", "dark") |
| `set_room_dynamic_desc(room_id, desc)` | Set temporary room description |
| `clear_room_dynamic_desc(room_id)` | Remove dynamic description |

**Example:** Festival bonfire trigger (`scripts/triggers/festival_bonfire.rhai`)
```rhai
fn run_trigger(room_id, connection_id, context) {
    let month = parse_int(context.get("new_month"));
    let is_festival = (month == 4 || month == 8 || month == 12);

    if is_festival {
        set_room_flag(room_id, "city", true);  // Bonfire lights area
        set_room_dynamic_desc(room_id, "A massive bonfire blazes...");
    } else {
        set_room_flag(room_id, "city", false);
        clear_room_dynamic_desc(room_id);
    }
    return "continue";
}
```

## Shop System Dependencies

Shop functionality is split between two systems: **shopkeeper mobiles** (edited via `medit.rhai`) and **vending machine items** (edited via `oedit.rhai`). There is no separate sedit.rhai file.

### Shopkeeper System (medit.rhai)

Shopkeepers are mobiles with the `shopkeeper` flag enabled. They have:
- `shop_stock` - Base item vnums always available (prototype pool)
- `shop_inventory` - Item IDs bought from players (secondary pool)
- `shop_buy_rate` - Rate paid when buying from players (0.0-1.0)
- `shop_sell_rate` - Markup when selling to players (1.0+)
- `shop_buys_types` - Item types the shop will purchase

### Adding a New Shop Property

- [ ] `src/lib.rs` - Add field to `MobileData` struct (~line 1438)
- [ ] `src/script/shops.rs`:
  - [ ] Register getter on MobileData type
  - [ ] Register setter function (e.g., `set_shop_PROPERTY()`)
- [ ] `scripts/commands/medit.rhai`:
  - [ ] `show_shop_config()` - Add to display (~line 814)
  - [ ] `handle_shop_subcommand()` - Add handler (~line 772)
- [ ] `scripts/commands/buy.rhai` - If affects purchase logic
- [ ] `scripts/commands/sell.rhai` - If affects selling logic
- [ ] `scripts/commands/list.rhai` - If affects listing display

### Adding a New Shop Item Type Filter

- [ ] `src/lib.rs` - Add variant to `ItemType` enum (~line 858)
- [ ] `src/script/shops.rs`:
  - [ ] `add_shop_buys_type()` - Ensure type is recognized
  - [ ] `shop_will_buy_type()` - Add to type matching
- [ ] `scripts/commands/medit.rhai`:
  - [ ] `handle_shop_subcommand()` - Add to valid types list (~line 772)
  - [ ] `show_shop_config()` - Types display automatically updates
- [ ] `scripts/commands/sell.rhai` - Type checking via `shop_will_buy_type()`

### Modifying Shop Pricing

- [ ] `src/script/shops.rs`:
  - [ ] `calculate_sell_price()` - Shop selling to player
  - [ ] `calculate_buy_price()` - Shop buying from player
- [ ] `scripts/commands/buy.rhai` - Uses `calculate_sell_price()` (~line 115)
- [ ] `scripts/commands/sell.rhai` - Uses `calculate_buy_price()` (~line 62)
- [ ] `scripts/commands/list.rhai` - Displays calculated prices (~line 72)

### Modifying Shop Stock System

- [ ] `src/script/shops.rs`:
  - [ ] `add_shop_stock()` - Add prototype vnum to base stock
  - [ ] `remove_shop_stock()` - Remove from base stock
  - [ ] `add_to_shop_inventory()` - Add sold item to inventory
  - [ ] `remove_from_shop_inventory()` - Remove on purchase
- [ ] `scripts/commands/medit.rhai`:
  - [ ] Stock management via shop subcommand (~line 772)
  - [ ] `show_shop_config()` - Stock display (~line 814)
- [ ] `scripts/commands/buy.rhai`:
  - [ ] `find_item_in_shop()` - Searches both pools (~line 132)
  - [ ] Prototype spawning for base stock items (~line 147)
- [ ] `scripts/commands/list.rhai` - Displays both stock pools (~line 72)

### Vending Machine System (oedit.rhai)

Vending machines are items with the `vending` flag. They have:
- `vending_stock` - Array of item vnums to sell
- `vending_sell_rate` - Price multiplier (1.0+)

See "Modifying Vending Machine System" in Item System Dependencies above.

### Key File Locations

| Component | Rust Definition | Rhai Functions | Editor | Consumer Commands |
|-----------|----------------|----------------|--------|-------------------|
| Shopkeeper Flag | lib.rs:1371 | script/mobiles.rs | medit.rhai | buy, sell, list |
| Shop Stock | lib.rs:1438 | script/shops.rs | medit.rhai | buy, list |
| Shop Inventory | lib.rs:1441 | script/shops.rs | medit.rhai | buy, sell, list |
| Buy/Sell Rates | lib.rs:1443 | script/shops.rs | medit.rhai | buy, sell, list |
| Buys Types | lib.rs:1447 | script/shops.rs | medit.rhai | sell |
| Vending Items | lib.rs:1305 | script/shops.rs | oedit.rhai | buy, list |

### Shop vs Vending Comparison

| Feature | Shopkeeper (Mobile) | Vending Machine (Item) |
|---------|--------------------|-----------------------|
| Editor | `medit <name> shop` | `oedit <name> vending` |
| Stock Source | vnums + bought items | vnums only |
| Buys from Players | Yes (with type filter) | No |
| Price Rates | buy_rate + sell_rate | sell_rate only |
| Location | Mobile in room | Item in room |
| Finding | `find_shopkeeper_in_room()` | `find_vending_machine_in_room()` |

### Related Commands

- `buy.rhai` - Purchase from shopkeeper or vending machine
- `sell.rhai` - Sell to shopkeeper (not vending machines)
- `list.rhai` - View shop/vending inventory and prices
- `appraise.rhai` - Check what shopkeeper would pay for item

## Area System Dependencies

Areas group rooms together and control builder permissions. Each area has an owner and permission levels controlling who can edit rooms within it.

### Area Properties

- `id` - Unique UUID identifier
- `name` - Display name for the area
- `prefix` - Short identifier for room vnums (e.g., "forest" for "forest:entrance")
- `description` - Area description text
- `level_min` / `level_max` - Suggested level range
- `theme` - Optional thematic category
- `owner` - Character name who owns the area (None = any builder)
- `permission_level` - Access control (owner_only, trusted, all_builders)
- `trusted_builders` - List of character names with edit access
- `flags` - AreaFlags struct with inheritable flags (climate_controlled)

### Adding a New Area Flag

- [ ] `src/lib.rs` - Add field to `AreaFlags` struct (~line 1248)
- [ ] `src/script/mod.rs` - Add getter to AreaFlags type registration
- [ ] `src/script/areas.rs`:
  - [ ] Add case in `set_area_flag()`
  - [ ] Add case in `get_area_flag()`
  - [ ] Add `get_effective_FLAGNAME()` if inheritable
- [ ] `scripts/commands/aedit.rhai`:
  - [ ] Add to flags display (~line 188)
  - [ ] Add to `handle_flags_subcommand()` (~line 638)
- [ ] Update consumers - code checking the room flag should also consider area inheritance

### Adding a New Area Property

- [ ] `src/lib.rs` - Add field to `AreaData` struct (~line 707), use `#[serde(default)]`
- [ ] `src/script/areas.rs`:
  - [ ] Register getter on AreaData type
  - [ ] Register `set_area_PROPERTY()` function
- [ ] `scripts/commands/aedit.rhai`:
  - [ ] Add to properties display (~line 72)
  - [ ] Add subcommand handler (~line 140+)
  - [ ] Add to commands help list (~line 116)

### Modifying Permission System

- [ ] `src/lib.rs` - `AreaPermission` enum (~line 696)
- [ ] `src/script/areas.rs`:
  - [ ] `set_area_permission()` - Add case for new level
  - [ ] `can_edit_area()` - Implement permission check logic
- [ ] `scripts/commands/aedit.rhai`:
  - [ ] `permission` subcommand help text (~line 244)
  - [ ] Permission display (~line 97)

### Adding Area Trustee Features

- [ ] `src/script/areas.rs`:
  - [ ] `add_area_trustee()`
  - [ ] `remove_area_trustee()`
- [ ] `scripts/commands/aedit.rhai`:
  - [ ] `trust` subcommand (~line 260)
  - [ ] `untrust` subcommand (~line 274)
  - [ ] `trustees` subcommand (~line 288)

### Modifying Spawn Point System

Spawn points belong to areas and auto-populate rooms with mobiles/items.

- [ ] `src/lib.rs` - `SpawnPointData` struct (~line 740)
- [ ] `src/script/spawn.rs`:
  - [ ] `create_spawn_point()`
  - [ ] `list_spawn_points_in_area()`
  - [ ] `trigger_area_reset()`
- [ ] `scripts/commands/spedit.rhai` - Spawn point editor
- [ ] `scripts/commands/areset.rhai` - Manual area reset

### Connecting Rooms to Areas

- [ ] `src/script/areas.rs`:
  - [ ] `set_room_area()`
  - [ ] `clear_room_area()`
  - [ ] `get_rooms_in_area()`
- [ ] `scripts/commands/redit.rhai` - `area` subcommand
- [ ] `scripts/commands/dig.rhai` - Auto-assigns area from current room

### Key File Locations

| Component | Rust Definition | Rhai Functions | Editor | Related Commands |
|-----------|----------------|----------------|--------|------------------|
| Area Data | lib.rs:1269 | script/areas.rs | aedit.rhai | acreate, adelete, alist |
| Area Flags | lib.rs:1248 | script/areas.rs | aedit.rhai | weather |
| Permissions | lib.rs:1257 | script/areas.rs | aedit.rhai | (permission checks) |
| Trustees | lib.rs:1281 | script/areas.rs | aedit.rhai | (trust/untrust) |
| Spawn Points | lib.rs:1338 | script/spawn.rs | spedit.rhai | areset |
| Room-Area Link | lib.rs:343 | script/areas.rs | redit.rhai | dig |

### Related Commands

- `acreate.rhai` - Create a new area (sets creator as owner)
- `adelete.rhai` - Delete an area (unassigns rooms, doesn't delete them)
- `alist.rhai` - List all areas
- `areset.rhai` - Manually trigger spawn points in an area
- `spedit.rhai` - Edit spawn points within an area
- `redit.rhai area` - Assign/unassign rooms to areas
