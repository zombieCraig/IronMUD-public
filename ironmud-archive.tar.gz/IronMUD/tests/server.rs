use anyhow::Result;
use ironmud::{load_command_metadata, load_game_data, load_scripts, run_server, script, watch_scripts, World};
use rhai::Engine;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpListener;
use tokio::time::{sleep, timeout};
use tokio::net::tcp::{OwnedReadHalf, OwnedWriteHalf};

// Telnet protocol constants
const IAC: u8 = 255;
const DONT: u8 = 254;
const DO: u8 = 253;
const WONT: u8 = 252;
const WILL: u8 = 251;
const SB: u8 = 250;
const SE: u8 = 240;

/// Telnet-aware test client helper
struct TelnetTestClient {
    reader: OwnedReadHalf,
    writer: OwnedWriteHalf,
}

impl TelnetTestClient {
    fn new(reader: OwnedReadHalf, writer: OwnedWriteHalf) -> Self {
        Self { reader, writer }
    }

    /// Read bytes and handle telnet negotiation, returning clean text
    async fn read_until_prompt(&mut self) -> Result<String> {
        let mut buf = [0u8; 1024];
        let mut data = Vec::new();

        // Read with timeout to avoid hanging
        loop {
            match timeout(Duration::from_secs(5), self.reader.read(&mut buf)).await {
                Ok(Ok(0)) => break, // Connection closed
                Ok(Ok(n)) => {
                    let bytes = &buf[..n];

                    // Process bytes, respond to telnet and collect text
                    let (text_bytes, responses) = self.process_telnet_bytes(bytes);
                    data.extend(text_bytes);

                    // Send any telnet responses
                    for response in responses {
                        let _ = self.writer.write_all(&response).await;
                    }

                    // Check if we have a prompt
                    if data.contains(&b'>') {
                        break;
                    }
                }
                Ok(Err(e)) => return Err(e.into()),
                Err(_) => break, // Timeout
            }
        }

        Ok(String::from_utf8_lossy(&data).to_string())
    }

    /// Process telnet bytes, stripping IAC sequences and generating responses
    fn process_telnet_bytes(&self, input: &[u8]) -> (Vec<u8>, Vec<Vec<u8>>) {
        let mut text = Vec::new();
        let mut responses = Vec::new();
        let mut i = 0;

        while i < input.len() {
            if input[i] == IAC && i + 1 < input.len() {
                match input[i + 1] {
                    IAC => {
                        // Escaped IAC -> literal 0xFF
                        text.push(IAC);
                        i += 2;
                    }
                    WILL => {
                        // Server offers option, we refuse with DONT
                        if i + 2 < input.len() {
                            responses.push(vec![IAC, DONT, input[i + 2]]);
                            i += 3;
                        } else {
                            i += 2;
                        }
                    }
                    WONT => {
                        // Server refuses, acknowledge
                        if i + 2 < input.len() {
                            i += 3;
                        } else {
                            i += 2;
                        }
                    }
                    DO => {
                        // Server requests option, we refuse with WONT
                        if i + 2 < input.len() {
                            responses.push(vec![IAC, WONT, input[i + 2]]);
                            i += 3;
                        } else {
                            i += 2;
                        }
                    }
                    DONT => {
                        // Server tells us not to, acknowledge
                        if i + 2 < input.len() {
                            i += 3;
                        } else {
                            i += 2;
                        }
                    }
                    SB => {
                        // Subnegotiation - skip until SE
                        i += 2;
                        while i < input.len() {
                            if input[i] == IAC && i + 1 < input.len() && input[i + 1] == SE {
                                i += 2;
                                break;
                            }
                            i += 1;
                        }
                    }
                    _ => {
                        // Other IAC command, skip
                        i += 2;
                    }
                }
            } else {
                text.push(input[i]);
                i += 1;
            }
        }

        (text, responses)
    }

    /// Send a command (adds newline)
    async fn send(&mut self, cmd: &str) -> Result<()> {
        self.writer.write_all(format!("{}\n", cmd).as_bytes()).await?;
        Ok(())
    }
}

/*
#[tokio::test]
async fn test_server_hot_reload() -> Result<()> {
    tracing_subscriber::fmt::init();
    // Clean up any previous test database
    std::fs::remove_dir_all("test.db").ok();

    // 1. Initialize the server state
    let engine = Engine::new();
    let db = ironmud::db::Db::open("test.db")?;
    let scripts = HashMap::new();
    let state = Arc::new(Mutex::new(World {
        engine,
        db,
        scripts,
        connections: HashMap::new(),
    }));

    {
        let mut world = state.lock().unwrap();
        world
            .engine
            .register_type_with_name::<Entity>("Entity")
            .register_get("id", |entity: &mut Entity| entity.id.to_string())
            .register_get("name", |entity: &mut Entity| entity.name.clone())
            .register_get("description", |entity: &mut Entity| {
                entity.description.clone()
            });
    }

    load_scripts(state.clone())?;
    watch_scripts(state.clone());

    // Create a dummy entity (COMMENTED OUT)
    /*
    let entity_id = Uuid::new_v4();
    let entity = Entity {
        id: entity_id,
        name: "The Test Void".to_string(),
        description: "A vast, empty test void.".to_string(),
    };
    {
        let world = state.lock().unwrap();
        world
            .db
            .insert(entity_id.as_bytes(), serde_json::to_vec(&entity)?)?;
    }
    */

    // 2. Start the server in a background task
    let listener = TcpListener::bind("127.0.0.1:0").await?;
    let addr = listener.local_addr()?;
    let (shutdown_tx, shutdown_rx) = tokio::sync::oneshot::channel();
    let server_handle = tokio::spawn(run_server(state, listener, shutdown_rx));
    sleep(Duration::from_millis(100)).await;

    // 3. Connect to the server and send the first 'look' command
    let mut stream = tokio::net::TcpStream::connect(addr).await?;
    let (reader, mut writer) = stream.split();
    let mut reader = BufReader::new(reader);
    let mut response_bytes = Vec::new();

    // Read the initial prompt
    reader.read_until(b'>', &mut response_bytes).await?;
    response_bytes.clear();

    writer.write_all(b"look\n").await?;
    reader.read_until(b'>', &mut response_bytes).await?;
    let response = String::from_utf8_lossy(&response_bytes);
    assert!(response.contains("A vast, empty test void."));

    // 4. Modify the look.rhai script
    let new_content = r#" 
fn look(entity) {
    `You see ${entity.name}.
${entity.description}
It is now a bustling test void.`
}
"#;
    tokio::fs::write("scripts/commands/look.rhai", new_content).await?;
    sleep(Duration::from_secs(2)).await; // Give time for the watcher to pick up the change

    // 5. Send the 'look' command again on the same connection
    response_bytes.clear();
    writer.write_all(b"look\n").await?;
    reader.read_until(b'>', &mut response_bytes).await?;
    let response2 = String::from_utf8_lossy(&response_bytes);
    assert!(response2.contains("a bustling test void"));

    // 6. Shutdown the server
    shutdown_tx.send(()).unwrap();
    server_handle.await?;

    Ok(())
}
*/

#[tokio::test]
async fn test_character_system_lifecycle() -> Result<()> {
    let _ = tracing_subscriber::fmt::try_init();
    // Clean up any previous test database
    std::fs::remove_dir_all("test.db").ok();

    // 1. Initialize the server state
    let engine = Engine::new();
    let db = ironmud::db::Db::open("test.db")?;
    let scripts = HashMap::new();
    let connections = Arc::new(Mutex::new(HashMap::new()));
    let command_metadata = load_command_metadata()?;

    let state = Arc::new(Mutex::new(World {
        engine,
        db,
        scripts,
        connections: connections.clone(),
        command_metadata,
        class_definitions: std::collections::HashMap::new(),
        trait_definitions: std::collections::HashMap::new(),
        race_suggestions: Vec::new(),
        recipes: std::collections::HashMap::new(),
        transports: std::collections::HashMap::new(),
        matrix_sender: None,
        shutdown_sender: None,
        shutdown_cancel_sender: None,
    }));

    // Register Rhai functions for character system
    {
        let mut world = state.lock().unwrap();
        let db_clone = world.db.clone();
        script::register_rhai_functions(&mut world.engine, Arc::new(db_clone), connections.clone(), state.clone());
        // Register a no-op matrix_broadcast for tests (Matrix not configured in test environment)
        world.engine.register_fn("matrix_broadcast", |_message: String| {});
    }

    load_scripts(state.clone())?;
    load_game_data(state.clone())?;
    watch_scripts(state.clone());

    // 2. Start the server in a background task
    let listener = TcpListener::bind("127.0.0.1:0").await?;
    let addr = listener.local_addr()?;
    let (shutdown_tx, shutdown_rx) = tokio::sync::oneshot::channel();
    let server_handle = tokio::spawn(run_server(state.clone(), listener, shutdown_rx));
    sleep(Duration::from_millis(100)).await;

    // 3. Connect to the server with telnet-aware client
    let stream = tokio::net::TcpStream::connect(addr).await?;
    let (reader, writer) = stream.into_split();
    let mut client = TelnetTestClient::new(reader, writer);

    // Read initial prompt (handles telnet negotiation)
    let _ = client.read_until_prompt().await?;

    let char_name = "TestChar";
    let password = "testpassword";
    let wrong_password = "wrongpassword";
    let non_existent_char = "NonExistent";

    // --- Test 1: Character Creation (with wizard) ---
    client.send(&format!("create {} {}", char_name, password)).await?;
    let response = client.read_until_prompt().await?;
    println!("[TEST] Response from create: {}", response);
    // New wizard flow: should show the character creation menu
    assert!(response.contains("=== Character Creation:"), "Did not enter character wizard: {}", response);

    // Complete the wizard by pressing "d" (Done) - this now auto-logs in
    client.send("d").await?;
    let response = client.read_until_prompt().await?;
    println!("[TEST] Response from 'd': {}", response);
    let expected_creation_msg = format!("Character '{}' created successfully!", char_name);
    assert!(response.contains(&expected_creation_msg), "Failed to complete character creation wizard: {}", response);
    // Should also see welcome message since auto-login
    let expected_welcome_msg = format!("Welcome, {}!", char_name);
    assert!(response.contains(&expected_welcome_msg), "Auto-login after creation failed: {}", response);

    // --- Test 2: Logout and Disconnect ---
    client.send("quit").await?;
    let response = client.read_until_prompt().await?;
    let expected_goodbye_msg = format!("Goodbye, {}.", char_name);
    assert!(response.contains(&expected_goodbye_msg), "Failed to quit: {}", response);

    // --- Test 3: Attempt Login with Wrong Password (new connection) ---
    let stream2 = tokio::net::TcpStream::connect(addr).await?;
    let (reader2, writer2) = stream2.into_split();
    let mut client2 = TelnetTestClient::new(reader2, writer2);

    let _ = client2.read_until_prompt().await?;

    client2.send(&format!("login {} {}", char_name, wrong_password)).await?;
    let response2 = client2.read_until_prompt().await?;
    assert!(response2.contains("Incorrect password."), "Login with wrong password unexpectedly succeeded or gave wrong message: {}", response2);

    client2.send("quit").await?;
    let _ = client2.read_until_prompt().await?;

    // --- Test 4: Attempt Login with Non-Existent Character (new connection) ---
    let stream3 = tokio::net::TcpStream::connect(addr).await?;
    let (reader3, writer3) = stream3.into_split();
    let mut client3 = TelnetTestClient::new(reader3, writer3);

    let _ = client3.read_until_prompt().await?;

    client3.send(&format!("login {} {}", non_existent_char, password)).await?;
    let response3 = client3.read_until_prompt().await?;
    let expected_not_found_msg = format!("Character '{}' not found.", non_existent_char);
    assert!(response3.contains(&expected_not_found_msg), "Login with non-existent character unexpectedly succeeded or gave wrong message: {}", response3);

    client3.send("quit").await?;
    let _ = client3.read_until_prompt().await?;

    // 6. Shutdown the server
    shutdown_tx.send(()).unwrap();
    server_handle.await?;

    Ok(())
}

/// Test that all Rhai scripts compile without syntax errors.
/// This catches issues like missing functions, syntax errors, etc.
#[test]
fn test_all_scripts_compile() {
    use glob::glob;

    let engine = Engine::new();
    let mut failures = Vec::new();

    for entry in glob("scripts/**/*.rhai").expect("Failed to read glob pattern") {
        match entry {
            Ok(path) => {
                let path_str = path.display().to_string();
                match engine.compile_file(path.clone()) {
                    Ok(_) => {
                        // Script compiled successfully
                    }
                    Err(e) => {
                        failures.push(format!("{}: {}", path_str, e));
                    }
                }
            }
            Err(e) => {
                failures.push(format!("Glob error: {}", e));
            }
        }
    }

    if !failures.is_empty() {
        panic!(
            "Script compilation failures:\n{}",
            failures.join("\n")
        );
    }
}

/// Test that all Rhai scripts only call functions that are registered.
/// This catches issues like typos in function names (e.g., get_inventory_items vs get_items_in_inventory).
#[test]
fn test_scripts_call_registered_functions() {
    use glob::glob;
    use regex::Regex;
    use std::collections::HashSet;
    use std::fs;

    // Step 1: Extract all registered function names from Rust source code
    let mut registered_functions: HashSet<String> = HashSet::new();

    // Pattern to match: register_fn("function_name", ...)
    let register_fn_pattern = Regex::new(r#"register_fn\s*\(\s*"([^"]+)""#).unwrap();

    // Scan all Rust files in src/script/
    for entry in glob("src/script/**/*.rs").expect("Failed to glob src/script") {
        if let Ok(path) = entry {
            if let Ok(content) = fs::read_to_string(&path) {
                for cap in register_fn_pattern.captures_iter(&content) {
                    registered_functions.insert(cap[1].to_string());
                }
            }
        }
    }

    // Also scan src/lib.rs and src/main.rs for any additional registrations
    for path in &["src/lib.rs", "src/main.rs"] {
        if let Ok(content) = fs::read_to_string(path) {
            for cap in register_fn_pattern.captures_iter(&content) {
                registered_functions.insert(cap[1].to_string());
            }
        }
    }

    // Step 2: Add Rhai built-in functions and common patterns
    let builtins = [
        // String methods
        "len", "is_empty", "to_upper", "to_lower", "trim", "contains", "starts_with",
        "ends_with", "sub_string", "split", "replace", "index_of", "pad",
        // Array methods
        "push", "pop", "shift", "insert", "remove", "clear", "reverse", "sort",
        "filter", "map", "reduce", "all", "any", "find", "index_of",
        // Map methods
        "keys", "values", "get", "set", "remove", "contains", "clear",
        // Type conversion
        "to_string", "to_int", "to_float", "to_bool", "parse_int", "parse_float",
        "type_of", "is_string", "is_int", "is_float", "is_bool", "is_array", "is_map",
        // Math
        "abs", "floor", "ceiling", "round", "sqrt", "sin", "cos", "tan", "log", "exp",
        "min", "max", "clamp",
        // Utility
        "print", "debug", "timestamp", "elapsed",
        // Range
        "range",
    ];
    for builtin in builtins {
        registered_functions.insert(builtin.to_string());
    }

    // Step 3: Scan all Rhai scripts for function calls
    // Pattern to match function calls: identifier followed by (
    // But NOT after . (method calls are fine, they're on registered types)
    // And NOT function definitions (fn name(...))
    let fn_call_pattern = Regex::new(r"(?:^|[^.\w])([a-z_][a-z0-9_]*)\s*\(").unwrap();
    let fn_def_pattern = Regex::new(r"fn\s+([a-z_][a-z0-9_]*)\s*\(").unwrap();
    // Pattern to remove string literals (both single and double quoted)
    let string_pattern = Regex::new(r#""(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*'"#).unwrap();

    let mut failures: Vec<String> = Vec::new();

    for entry in glob("scripts/**/*.rhai").expect("Failed to glob scripts") {
        if let Ok(path) = entry {
            let path_str = path.display().to_string();
            if let Ok(content) = fs::read_to_string(&path) {
                // Extract functions defined in this script
                let mut local_functions: HashSet<String> = HashSet::new();
                for cap in fn_def_pattern.captures_iter(&content) {
                    local_functions.insert(cap[1].to_string());
                }

                // Find all function calls
                for (line_num, line) in content.lines().enumerate() {
                    // Skip comments
                    let line_trimmed = line.trim();
                    if line_trimmed.starts_with("//") {
                        continue;
                    }
                    // Remove inline comments
                    let line_no_comment = if let Some(idx) = line.find("//") {
                        &line[..idx]
                    } else {
                        line
                    };

                    // Remove string literals to avoid false positives
                    let line_no_strings = string_pattern.replace_all(line_no_comment, "\"\"");

                    for cap in fn_call_pattern.captures_iter(&line_no_strings) {
                        let fn_name = &cap[1];

                        // Skip if it's a control flow keyword
                        if matches!(fn_name, "if" | "else" | "while" | "for" | "loop" | "return" | "let" | "fn" | "in" | "switch" | "throw" | "try" | "catch") {
                            continue;
                        }

                        // Check if the function is registered, built-in, or locally defined
                        if !registered_functions.contains(fn_name) && !local_functions.contains(fn_name) {
                            failures.push(format!(
                                "{}:{}: unknown function '{}' (not registered)",
                                path_str, line_num + 1, fn_name
                            ));
                        }
                    }
                }
            }
        }
    }

    if !failures.is_empty() {
        // Deduplicate and sort failures
        let mut unique_failures: Vec<String> = failures.into_iter().collect::<HashSet<_>>().into_iter().collect();
        unique_failures.sort();
        panic!(
            "Scripts call unregistered functions:\n{}",
            unique_failures.join("\n")
        );
    }
}