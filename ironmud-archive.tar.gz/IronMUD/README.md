# IronMUD (Rust MUD Engine)

IronMUD is an asynchronous, event-driven Multi-User Dungeon (MUD) engine written in Rust. It emphasizes hot-reloading of game logic through scripting, providing a dynamic development environment for MUD administrators and content creators.

## Requirements

*   **Rust**: 2024 Edition (1.85+)
*   **Operating System**: Linux, macOS, or Windows

## Installation

1.  **Install Rust** (if not already installed):
    ```bash
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
    ```

2.  **Clone the repository**:
    ```bash
    git clone <repository-url>
    cd IronMUD
    ```

3.  **Build the project**:
    ```bash
    cargo build --release
    ```

4.  **Run the server**:
    ```bash
    cargo run --release --bin ironmud
    ```
    The server listens on TCP port 4000 by default.

### Server Installation (Ubuntu/Debian)

For production deployment on Ubuntu/Debian systems, use the included installation script:

```bash
sudo ./install.sh
```

This script:
- Installs build dependencies and Rust toolchain
- Creates a dedicated `ironmud` system user
- Builds and installs to `/opt/ironmud`
- Sets up a systemd service with security hardening
- Starts the server automatically

After installation:
```bash
sudo systemctl status ironmud      # Check status
sudo journalctl -u ironmud -f      # View logs
telnet localhost 4000              # Connect
```

### Upgrading (systemd installation)

To upgrade an existing systemd installation:

```bash
cd /path/to/IronMUD
git pull
sudo ./install.sh
```

The install script automatically detects existing installations and:
- Stops the service gracefully (saving all active players)
- Backs up the database to `data.backup-TIMESTAMP/`
- Updates binaries and scripts (backing up modified scripts to `.backup` files)
- Preserves your systemd service configuration
- Restarts the service

## Upgrading (Manual)

For development or manual installations:

1.  **Pull latest changes**:
    ```bash
    git pull
    ```

2.  **Rebuild**:
    ```bash
    cargo build --release
    ```

3.  **Restart the server**. Database migrations run automatically on startup.

For systemd installations, see [Upgrading (systemd installation)](#upgrading-systemd-installation) above.

## Basic Usage

1.  **Connect via Telnet**:
    ```bash
    telnet localhost 4000
    ```

2.  **Create a character**:
    ```
    create <name> <password>
    ```

3.  **Log in** (on subsequent connections):
    ```
    login <name> <password>
    ```

4.  **Explore**: Use commands like `look`, `go north`, `say hello`, `who`, and `help`.

## High-Level Architecture

The engine separates core functionalities (networking, database, protocol parsing, VM host) implemented in Rust from game logic (room behavior, item interactions, command logic) handled by a scripting engine. This allows for live updates and changes to game mechanics without recompiling the main binary.

## Technical Stack

*   **Language**: Rust (2024 Edition)
*   **Async Runtime**: Tokio
*   **Scripting Engine**: Rhai (pure Rust, embeddable, thread-safe)
*   **Database**: Sled (embedded, pure Rust)
*   **Password Hashing**: Argon2

## Commands

### General
| Command | Description |
|---------|-------------|
| `help` | Display available commands |
| `look` | Look at your surroundings |
| `exits` | Show available exits |
| `go <direction>` | Move in a direction (north, south, east, west, up, down) |
| `who` | List online players |
| `quit` | Disconnect from the server |

### Communication
| Command | Description |
|---------|-------------|
| `say <message>` | Speak to players in the same room |
| `shout <message>` | Broadcast to all online players |
| `tell <player> <message>` | Send a private message |
| `whisper <player> <message>` | Whisper to a player in the same room |
| `emote <action>` | Perform an emote action |

### Character
| Command | Description |
|---------|-------------|
| `create <name> <password>` | Create a new character |
| `login <name> <password>` | Log in to an existing character |
| `logout` | Log out (stay connected) |
| `password <new_password>` | Change your password |
| `status` | View your character stats and gold balance |
| `alias <name> <command>` | Create a command alias |
| `unalias <name>` | Remove an alias |

### Items & Gold
| Command | Description |
|---------|-------------|
| `get <item>` | Pick up an item from the room |
| `get <item> from <container>` | Get an item from a container |
| `drop <item>` | Drop an item from your inventory |
| `drop <amount> gold` | Drop gold from your balance |
| `give <item> to <player>` | Give an item to another player |
| `give <amount> gold to <player>` | Give gold to another player |
| `put <item> in <container>` | Put an item into a container |
| `put <amount> gold in <container>` | Put gold into a container |
| `inventory` | List items you are carrying |
| `equipment` | Show what you are wearing |
| `examine <item>` | Examine an item in detail |

### Administration
| Command | Description |
|---------|-------------|
| `setbuilder` | Toggle builder mode (behavior depends on `builder_mode` setting) |
| `setadmin <player> [on\|off]` | Grant or revoke admin access (admin only) |

### Builder (OLC)
| Command | Description |
|---------|-------------|
| `redit <field> <value>` | Edit current room properties |
| `dig <direction> [title]` | Create a new room with exit |
| `link <direction> <room>` | Link exit to existing room |
| `unlink <direction>` | Remove an exit |
| `rgoto <room-id or vnum>` | Teleport to a room |
| `rlist` | List all rooms |
| `rfind <keyword>` | Search rooms by keyword |
| `rdelete` | Delete current room |
| `acreate <name>` | Create a new area |
| `aedit <field> <value>` | Edit area properties |
| `alist` | List all areas |
| `adelete <area-id>` | Delete an area |
| `ospawn <vnum>` | Spawn an item from prototype |
| `mspawn <vnum>` | Spawn a mobile from prototype |
| `gspawn <amount> [container <name>]` | Spawn gold in room or container |

## Online Creation (OLC)

IronMUD supports Online Creation for defining and modifying game content through data and scripts rather than direct Rust code.

**Script Hot-Reloading:**
1.  Game logic is defined in `.rhai` script files within `./scripts/commands/`.
2.  Edit these files directly in any text editor.
3.  Upon saving, the engine detects file changes and hot-reloads the script immediately.

**Room Building:**
Builders can create and modify rooms in-game using OLC commands like `dig`, `redit`, and `link`.

## Configuration

### Command-Line Options

```bash
ironmud [OPTIONS]

Options:
  -p, --port <PORT>          Port to listen on [default: 4000]
  -d, --database <DATABASE>  Database path [default: ironmud.db]
  -h, --help                 Print help
```

Example:
```bash
./ironmud --port 5000 --database /var/lib/ironmud/data.db
```

### Defaults

*   **Telnet Port**: 4000
*   **Database**: `ironmud.db` directory (created automatically)

## Administration

### First User
The first character created on a fresh database automatically becomes an administrator with full builder permissions.

### Admin Utility
An external command-line utility is available for offline administration:

```bash
# Build the utility
cargo build --release --bin ironmud-admin

# User management
./target/release/ironmud-admin user list
./target/release/ironmud-admin user grant-admin <name>
./target/release/ironmud-admin user revoke-admin <name>
./target/release/ironmud-admin user grant-builder <name>
./target/release/ironmud-admin user revoke-builder <name>
./target/release/ironmud-admin user change-password <name>
./target/release/ironmud-admin user require-password-change <name>
./target/release/ironmud-admin user delete <name>

# Server settings
./target/release/ironmud-admin settings list
./target/release/ironmud-admin settings get builder_mode
./target/release/ironmud-admin settings set builder_mode <all|granted|none>
```

### Builder Mode Setting
The `builder_mode` setting controls how the `setbuilder` command works:

| Mode | Behavior |
|------|----------|
| `all` (default) | Any user can toggle their own builder status |
| `granted` | Only admins can grant/revoke builder to others |
| `none` | Builder management disabled (use admin utility) |

## Matrix Integration

IronMUD can optionally connect to a Matrix room to announce game events and receive commands from Matrix users. This works with any Matrix homeserver including self-hosted instances on private networks (e.g., Tailscale).

### Prerequisites

1. **Matrix homeserver** - A running Matrix server (Synapse, Conduit, etc.)
2. **Bot account** - Create a dedicated Matrix account for the bot
3. **Room** - Create or choose a room for game announcements

### Creating a Bot Account

On your Matrix server, create a new user for the bot:

```bash
# For Synapse (adjust for your homeserver)
register_new_matrix_user -c /path/to/homeserver.yaml http://localhost:8008

# Or use the admin API / Element to create an account
```

Choose a username like `ironmud_bot` or `mud_announcer`.

### Finding the Room ID

The room ID is required (not the room alias). To find it:

1. **Element/Web client**: Room Settings → Advanced → "Internal room ID"
2. **Format**: `!randomstring:your.server.com`

Example: `!AbCdEfGhIjK:matrix.example.com`

### Configuration

#### Environment Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `MATRIX_HOMESERVER` | Matrix server URL (HTTP or HTTPS) | `http://matrix.local:8008` |
| `MATRIX_USER` | Bot username (without @) | `ironmud_bot` |
| `MATRIX_PASSWORD` | Bot account password | `secretpassword` |
| `MATRIX_ROOM` | Room ID (not alias) | `!AbCdEf:matrix.local` |

#### For systemd installations

Edit the service file:
```bash
sudo systemctl edit --full ironmud
```

Uncomment and configure the Matrix variables:
```ini
Environment="MATRIX_HOMESERVER=http://matrix.example.com:8008"
Environment="MATRIX_USER=ironmud_bot"
Environment="MATRIX_PASSWORD=your_password_here"
Environment="MATRIX_ROOM=!roomid:example.com"
```

Then reload and restart:
```bash
sudo systemctl daemon-reload
sudo systemctl restart ironmud
```

#### For manual/development runs

```bash
export MATRIX_HOMESERVER="http://matrix.example.com:8008"
export MATRIX_USER="ironmud_bot"
export MATRIX_PASSWORD="your_password"
export MATRIX_ROOM="!roomid:example.com"
cargo run --release
```

#### Private Networks (Tailscale, etc.)

For Matrix servers on private networks, HTTP works fine:
```bash
MATRIX_HOMESERVER="http://matrix.your-tailnet.ts.net:8008"
```

### Room Setup

1. **Invite the bot** to your room (or set the room to public)
2. **Grant permissions** - The bot needs permission to send messages
3. The bot will automatically join when IronMUD starts

### Verifying the Connection

Check the server logs for:
```
INFO ironmud: Matrix bot started
INFO ironmud::matrix: Starting Matrix bot, connecting to http://...
INFO ironmud::matrix: Matrix bot logged in as ironmud_bot
INFO ironmud::matrix: Matrix bot connected to room !...
```

When the server starts successfully, you'll see in the Matrix room:
```
IronMUD server is now online.
```

### Features

**Game to Matrix:**
- Player login announcements ("PlayerName has entered the realm.")
- Player logout announcements ("PlayerName has left the realm.")

**Matrix to Game:**
| Command | Description |
|---------|-------------|
| `!who` | List currently online players |
| `!tell <player> <message>` | Send a message to an online player |
| `!help` | Show available Matrix commands |

### Example Usage

From a Matrix client:
```
!who
> Players online (2): Alice, Bob

!tell Alice Hello from Matrix!
> Message sent to Alice.
```

The player receives in-game:
```
[Matrix] yourname says: Hello from Matrix!
```

### Troubleshooting

| Issue | Solution |
|-------|----------|
| "Matrix integration disabled" in logs | Check all 4 environment variables are set |
| "Failed to create Matrix client" | Verify MATRIX_HOMESERVER URL is correct and reachable |
| "Failed to log in to Matrix" | Check username/password; ensure account exists |
| "Failed to join Matrix room" | Verify room ID format; invite bot to room first |
| Bot doesn't respond to commands | Ensure bot has permission to read messages in room |
| Messages not appearing | Check bot has permission to send messages |

### Disabling Matrix

Simply unset or remove the environment variables. If any required variable is missing, IronMUD runs normally without Matrix integration.

## AI Integration

IronMUD can optionally use AI to assist builders with writing descriptions for rooms, mobiles, and items. Two providers are supported:

- **Claude** (Anthropic) - Requires Anthropic API key
- **Gemini** (Google) - Requires Google AI API key

**Important:** You can only use one AI provider at a time. If both `CLAUDE_API_KEY` and `GEMINI_API_KEY` are set, AI integration will be disabled with an error.

### Prerequisites

**For Claude:**
1. **Anthropic API account** - Sign up at [console.anthropic.com](https://console.anthropic.com)
2. **API key** - Create an API key in the Anthropic console

**For Gemini:**
1. **Google AI account** - Sign up at [aistudio.google.com](https://aistudio.google.com)
2. **API key** - Create an API key in Google AI Studio

### Configuration

#### Claude Environment Variables

| Variable | Required | Description | Default |
|----------|----------|-------------|---------|
| `CLAUDE_API_KEY` | Yes | Your Anthropic API key | - |
| `CLAUDE_MODEL` | No | Model to use | `claude-sonnet-4-20250514` |
| `CLAUDE_MAX_TOKENS` | No | Maximum response tokens | `1024` |

#### Gemini Environment Variables

| Variable | Required | Description | Default |
|----------|----------|-------------|---------|
| `GEMINI_API_KEY` | Yes | Your Google AI API key | - |
| `GEMINI_MODEL` | No | Model to use | `gemini-2.0-flash` |
| `GEMINI_MAX_TOKENS` | No | Maximum response tokens | `1024` |

#### For systemd installations

Edit the service file:
```bash
sudo systemctl edit --full ironmud
```

Add ONE of the following (not both):
```ini
# For Claude:
Environment="CLAUDE_API_KEY=sk-ant-api03-..."

# OR for Gemini:
Environment="GEMINI_API_KEY=AIza..."
```

Then reload and restart:
```bash
sudo systemctl daemon-reload
sudo systemctl restart ironmud
```

#### For manual/development runs

```bash
# For Claude:
export CLAUDE_API_KEY="sk-ant-api03-..."
cargo run --release

# OR for Gemini:
export GEMINI_API_KEY="AIza..."
cargo run --release
```

### Features

AI assists with two description-writing modes:

| Mode | Description |
|------|-------------|
| `help <prompt>` | Generate a new description from your prompt |
| `rephrase` | Reword an existing description |

Both modes show a draft and ask for confirmation before applying changes.

**For rooms only:** AI automatically suggests and adds extra descriptions with appropriate keywords (e.g., examining furniture, features mentioned in the description).

### Usage

#### Room Descriptions (redit)

```
redit desc help a cozy tavern with a crackling fireplace
redit desc rephrase
```

#### Mobile Descriptions (medit)

```
medit <id> short help a grizzled old blacksmith
medit <id> short rephrase
medit <id> long help weathered face, soot-stained apron, strong arms
medit <id> long rephrase
```

#### Item Descriptions (oedit)

```
oedit <id> short help an ornate silver dagger
oedit <id> short rephrase
oedit <id> long help elven runes along the blade, worn leather grip
oedit <id> long rephrase
```

### Confirmation Flow

When AI generates a description, you'll see:

```
=== AI-Generated Description ===
[The generated description text]
================================
Accept this description? (y/n)
```

For rooms, extra descriptions are also shown:

```
=== Suggested Extra Descriptions ===
Keywords: fireplace, hearth, fire
[Description of the fireplace]

Keywords: bar, counter
[Description of the bar]
====================================
```

- Type `y` to accept and apply the description (and extras for rooms)
- Type `n` to reject and discard the draft

### Example Session

```
> redit desc help a mysterious forest clearing with ancient standing stones

Generating description...

=== AI-Generated Description ===
You stand in a hushed clearing where pale shafts of moonlight filter through
the canopy above. Moss-covered standing stones rise in a rough circle around
you, their surfaces etched with symbols worn smooth by countless seasons.
================================

=== Suggested Extra Descriptions ===
Keywords: stones, standing stones, monoliths
Towering nearly twice your height, these ancient monoliths lean at odd angles
as if bowing to some forgotten power. Lichen clings to their weathered surfaces.

Keywords: symbols, runes, carvings
The worn carvings seem to shift in the dim light. You can make out spirals,
interlocking circles, and shapes that might once have been letters.
====================================

Accept this description? (y/n)
> y
Description applied successfully.
Added 2 extra descriptions.
```

### Troubleshooting

| Issue | Solution |
|-------|----------|
| "AI integration disabled" in logs | Set either CLAUDE_API_KEY or GEMINI_API_KEY |
| "Both...are set" error | Remove one API key - only one provider allowed |
| "AI is not enabled" when using commands | Verify API key is set and server was restarted |
| API errors or timeouts | Check your API key is valid and has credits |
| Poor quality descriptions | Try a more detailed prompt or use a different model |

### Disabling AI

Simply unset or remove both `CLAUDE_API_KEY` and `GEMINI_API_KEY` environment variables. IronMUD runs normally without AI assistance.

## Running Tests

```bash
cargo test
```

## Development Status

*   **Networking**: Functional (Telnet, configurable port)
*   **Database**: Functional (Sled embedded database, configurable path)
*   **Scripting**: Functional (Rhai with hot-reloading)
*   **Character System**: Functional (create, login, logout, case-insensitive names)
*   **Room System**: Functional (rooms, exits, areas, vnums, extra descriptions)
*   **OLC (Online Creation)**: Functional (room/area editing, builder permissions)
*   **Matrix Integration**: Functional (announcements, commands from Matrix room)
*   **AI Integration**: Functional (Claude or Gemini for description writing in OLC editors)
