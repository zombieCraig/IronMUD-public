# Unicode/Japanese Language Support Plan

## Executive Summary

This document covers Unicode (specifically Japanese: hiragana, katakana, kanji) support in IronMUD.

**Status:** Levels 1-2 are **COMPLETE** as of January 2026.
- **Level 1:** UTF-8 input parsing - players can type Japanese, accented characters, and emoji
- **Level 2:** MTTS client detection - server detects client capabilities including UTF-8 support

## Project Context

- **Priority:** Low - document now, implement when time permits
- **Target Audience:** Primarily English-speaking, with some users learning Japanese who would benefit from practice opportunities
- **Transport Priority:** Telnet is the primary access method (web client is disabled/incomplete)
- **Scope Decision:** General UTF-8 support (Level 1) is relatively low lift and provides foundation for future Japanese content

## Research Findings

### Current Codebase Status

| Component | UTF-8 Ready | Notes |
|-----------|-------------|-------|
| Database (sled + JSON) | Yes | JSON serialization handles UTF-8 natively |
| Rhai scripting | Yes | Rust strings are UTF-8 internally |
| Output to clients | Yes | `.as_bytes()` on String preserves UTF-8 |
| Character/room descriptions | Yes | Stored as Rust String type |
| Input parsing | Yes | Multi-byte UTF-8 sequences handled (Level 1 complete) |
| Cursor positioning | Yes | Uses `unicode-width` crate for correct display width |

### Resolved Issue: UTF-8 Input Parsing

**Problem (now fixed):** The original `parse_key_byte()` function in `telnet.rs` assumed each byte mapped to one character. A Japanese character like `あ` (U+3042) encoded as 3 bytes (`E3 81 82`) was parsed as 3 separate invalid characters.

**Solution (implemented):** Added `Utf8(Vec<u8>, usize)` state to `EscapeState` enum. The parser now:
1. Detects UTF-8 lead bytes and determines expected sequence length
2. Accumulates continuation bytes until sequence is complete
3. Decodes the complete sequence to a Unicode character

### Telnet Client UTF-8 Support

**Protocol Standards:**
- **MTTS** (Mud Terminal Type Standard): Bit 4 (value 4) indicates UTF-8 support
- **RFC 2066 CHARSET**: Explicit charset negotiation, but limited client support

**Client Compatibility:**
| Client | UTF-8 Support |
|--------|--------------|
| Mudlet | Yes (CHARSET + MTTS) |
| Web clients (maldorne, etc.) | Yes (native) |
| PuTTY/terminal telnet | Yes (passes through) |
| TinTin++ | Yes (MTTS) |
| CMUD | Latin-1 default (poor) |
| KildClient | Latin-1 (poor) |
| MUSHclient | Latin-1 (poor) |

**Recommendation:** Default to UTF-8, use MTTS to detect client capability, fallback gracefully for legacy clients.

## Implementation Scope Options

### Level 1: UTF-8 Content Support - COMPLETE

**Status:** Implemented January 2026 (commit 728a2bb)

**Goal:** Allow Japanese characters in room descriptions, item names, dialogue, etc.

**Changes Made:**
1. `src/telnet.rs` - Added `Utf8(Vec<u8>, usize)` variant to `EscapeState` enum
2. `src/telnet.rs` - Modified `parse_key_byte()` to detect UTF-8 lead bytes and accumulate multi-byte sequences
3. Added 6 unit tests for UTF-8 parsing (2-byte, 3-byte Japanese, 4-byte emoji, error cases)

**What Works Now:**
- Builders can use Japanese in descriptions
- Players with UTF-8 clients see Japanese text correctly
- Players can type Japanese, accented characters, and emoji

**Known Limitations:**
- Legacy clients may see garbled text (Level 2 detection now available)
- No automatic language switching

**Display Width Handling:** Emoji and CJK characters now have correct cursor positioning in readline editing (uses `unicode-width` crate). This prevents garbled display when typing or editing lines containing wide characters.

---

### Level 2: Client Capability Detection - COMPLETE

**Status:** Implemented January 2026 (commit 2672bfd)

**Goal:** Detect UTF-8 support and adapt behavior per-client.

**Changes Made:**
1. `src/telnet.rs` - Added TTYPE subnegotiation constants (`TTYPE_IS`, `TTYPE_SEND`)
2. `src/telnet.rs` - Added MTTS capability flag constants (ANSI, VT100, UTF8, 256_COLORS, etc.)
3. `src/telnet.rs` - Updated `TelnetState` with MTTS fields (`ttype_stage`, `client_name`, `terminal_type`, `mtts_flags`, `utf8_supported`)
4. `src/telnet.rs` - Added helper functions (`build_ttype_send()`, `parse_ttype_is()`, `parse_mtts_flags()`)
5. `src/telnet.rs` - Updated `build_initial_negotiations()` to request TTYPE
6. `src/lib.rs` - Added WILL TTYPE handling to start MTTS 3-stage negotiation
7. `src/lib.rs` - Added TTYPE subnegotiation handler with full 3-stage state machine
8. Added 4 unit tests for MTTS parsing

**What Works Now:**
- Server detects client capabilities via MTTS 3-stage negotiation
- `utf8_supported` flag available in `TelnetState`
- Client info logged when MTTS negotiation completes
- MTTS flags captured: ANSI, VT100, UTF-8, 256 colors, mouse tracking, screen reader, proxy, truecolor

**MTTS Bit Flags:**
| Bit | Value | Name | Meaning |
|-----|-------|------|---------|
| 1 | 1 | ANSI | Supports ANSI color codes |
| 2 | 2 | VT100 | Supports VT100 interface |
| 3 | 4 | **UTF-8** | Uses UTF-8 character encoding |
| 4 | 8 | 256_COLORS | Supports 256 color palette |
| 5 | 16 | MOUSE_TRACKING | Supports xterm mouse tracking |
| 6 | 32 | OSC_COLOR_PALETTE | Supports OSC color palette |
| 7 | 64 | SCREEN_READER | Screen reader in use |
| 8 | 128 | PROXY | Connection is via proxy |
| 9 | 256 | TRUECOLOR | Supports 24-bit truecolor |

---

### Level 3: System Message Localization

**Goal:** Externalize hardcoded English strings; allow player language preference.

**Effort:** High (1-2 weeks)

**Changes Required:**
1. Create `locales/en.json` and `locales/ja.json` message catalogs
2. Add `language: String` field to `CharacterData`
3. Create `get_localized_message(key, lang, args)` Rhai function
4. Update all Rhai scripts to use message keys instead of hardcoded strings
5. Add `language` command for players to change preference

**Scope of String Extraction:**
- Login/character creation prompts
- Error messages
- Command responses (look, inventory, etc.)
- Combat messages
- System notifications

**What Works After:**
- Japanese players can see system messages in Japanese
- Easy to add more languages later

---

### Level 4: Full Localization

**Goal:** Complete Japanese gameplay experience.

**Effort:** Very High (weeks to months)

**Additional Requirements:**
- CJK character width handling for terminal display
- Input method editor (IME) consideration
- All builder-created content needs translation or language variants
- Help system localization
- Potentially room/item/mobile name variants

**Complexity Notes:**
- CJK characters are "full-width" (2 terminal columns)
- Cursor positioning in readline needs width-aware calculation
- Would need `unicode-width` crate

---

## Implementation Status

### Phase 1: Foundation - COMPLETE

**Level 1** is implemented. This provides:
- Japanese characters work in all content
- ~120 lines added to `telnet.rs`
- No breaking changes to existing functionality
- Foundation for future expansion

### Phase 2: Detection - COMPLETE

**Level 2** is implemented. This provides:
- MTTS 3-stage negotiation to detect client capabilities
- `utf8_supported` flag per connection
- Client name and terminal type captured
- Full MTTS bitvector parsing (ANSI, 256 colors, truecolor, screen reader, etc.)
- Logging of client capabilities on connection

### Phase 3+: Localization (Future, If Needed)

Only pursue **Levels 3-4** if there's actual demand. These require:
- Significant ongoing maintenance (keeping translations in sync)
- Content creation in multiple languages
- More complex testing requirements

## Implementation Details

### Level 1: UTF-8 Input Parsing

### Files Modified

1. **`src/telnet.rs`**
   - Added `Utf8(Vec<u8>, usize)` variant to `EscapeState` enum
   - Modified `parse_key_byte()` to detect UTF-8 lead bytes
   - Added UTF-8 state handler to accumulate continuation bytes
   - Added 6 unit tests for UTF-8 parsing

2. **`src/lib.rs`** - No changes needed
   - Existing code already accepts `char` from `KeyEvent::Char`

### UTF-8 Byte Pattern Reference

| Bytes | Pattern | Range |
|-------|---------|-------|
| 1 | 0xxxxxxx | U+0000 to U+007F (ASCII) |
| 2 | 110xxxxx 10xxxxxx | U+0080 to U+07FF |
| 3 | 1110xxxx 10xxxxxx 10xxxxxx | U+0800 to U+FFFF (includes Japanese) |
| 4 | 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx | U+10000 to U+10FFFF |

Japanese characters fall in the 3-byte range:
- Hiragana: U+3040-U+309F
- Katakana: U+30A0-U+30FF
- CJK (Kanji): U+4E00-U+9FFF

### Implementation Reference

```rust
pub enum EscapeState {
    Normal,
    GotEsc,
    GotCsi(Vec<u8>),
    Utf8(Vec<u8>, usize),  // (buffer, expected_length)
}

pub fn parse_key_byte(state: EscapeState, byte: u8) -> (EscapeState, Option<KeyEvent>) {
    match state {
        EscapeState::Utf8(mut buf, expected) => {
            if byte & 0xC0 == 0x80 {  // Continuation byte
                buf.push(byte);
                if buf.len() == expected {
                    // Complete - decode
                    if let Ok(s) = std::str::from_utf8(&buf) {
                        if let Some(c) = s.chars().next() {
                            return (EscapeState::Normal, Some(KeyEvent::Char(c)));
                        }
                    }
                    (EscapeState::Normal, Some(KeyEvent::Unknown))
                } else {
                    (EscapeState::Utf8(buf, expected), None)
                }
            } else {
                // Invalid continuation - reset and process this byte
                (EscapeState::Normal, Some(KeyEvent::Unknown))
            }
        }
        EscapeState::Normal => {
            // ... existing control/escape handling ...
            _ => {
                // Check for UTF-8 multi-byte lead
                let expected = if byte & 0x80 == 0 { 1 }
                    else if byte & 0xE0 == 0xC0 { 2 }
                    else if byte & 0xF0 == 0xE0 { 3 }
                    else if byte & 0xF8 == 0xF0 { 4 }
                    else { 0 };  // Invalid

                if expected == 1 {
                    // ASCII - handle directly
                    (EscapeState::Normal, Some(KeyEvent::Char(byte as char)))
                } else if expected > 1 {
                    // Start accumulating
                    (EscapeState::Utf8(vec![byte], expected), None)
                } else {
                    (EscapeState::Normal, Some(KeyEvent::Unknown))
                }
            }
        }
        // ... other states unchanged ...
    }
}
```

### Level 2: MTTS Client Detection

#### Files Modified

1. **`src/telnet.rs`**
   - Added TTYPE subnegotiation constants (`TTYPE_IS = 0`, `TTYPE_SEND = 1`)
   - Added MTTS capability flag constants (`MTTS_ANSI`, `MTTS_UTF8`, etc.)
   - Updated `TelnetState` struct with MTTS tracking fields
   - Added `build_ttype_send()` function
   - Added `parse_ttype_is()` function
   - Added `parse_mtts_flags()` function
   - Updated `build_initial_negotiations()` to include `DO TTYPE`
   - Added 4 unit tests for MTTS parsing

2. **`src/lib.rs`**
   - Added `OPT_TTYPE` case to `TelnetEvent::Will` handler
   - Added `OPT_TTYPE` case to `TelnetEvent::Subnegotiation` handler
   - Implemented 3-stage MTTS negotiation state machine

#### MTTS 3-Stage Negotiation Sequence

```
Server: IAC DO TTYPE                          (in initial negotiations)
Client: IAC WILL TTYPE
Server: IAC SB TTYPE SEND IAC SE              (stage 1 request)
Client: IAC SB TTYPE IS "MUDLET" IAC SE       (stage 1: client name)
Server: IAC SB TTYPE SEND IAC SE              (stage 2 request)
Client: IAC SB TTYPE IS "XTERM-256COLOR" IAC SE (stage 2: terminal type)
Server: IAC SB TTYPE SEND IAC SE              (stage 3 request)
Client: IAC SB TTYPE IS "MTTS 141" IAC SE     (stage 3: capability flags)
```

#### TelnetState Fields Added

```rust
pub struct TelnetState {
    // ... existing fields ...

    /// TTYPE negotiation stage (0=not started, 1-3=stage, 4=complete)
    pub ttype_stage: u8,
    /// Client name from TTYPE stage 1 (e.g., "MUDLET")
    pub client_name: Option<String>,
    /// Terminal type from TTYPE stage 2 (e.g., "XTERM-256COLOR")
    pub terminal_type: Option<String>,
    /// MTTS capability flags from stage 3
    pub mtts_flags: u32,
    /// Derived: client supports UTF-8 (from MTTS or assumed)
    pub utf8_supported: bool,
}
```

#### Usage Example

```rust
// Check if client supports UTF-8
if session.telnet_state.utf8_supported {
    // Send UTF-8 content
} else {
    // Fallback to ASCII or transliterate
}

// Check for 256 color support
if (session.telnet_state.mtts_flags & MTTS_256_COLORS) != 0 {
    // Use 256 color palette
}
```

## Testing

### Automated Tests (Implemented)

**Level 1 - UTF-8 parsing tests:**
- `test_parse_utf8_2byte` - European characters (é)
- `test_parse_utf8_3byte_japanese` - Hiragana (あ)
- `test_parse_utf8_katakana` - Katakana (カ)
- `test_parse_utf8_4byte_emoji` - Emoji (😀)
- `test_parse_utf8_invalid_continuation` - Error handling
- `test_parse_utf8_invalid_lead` - Error handling

**Level 2 - MTTS parsing tests:**
- `test_build_ttype_send` - Verify TTYPE SEND message format
- `test_parse_ttype_is` - Parse TTYPE IS responses
- `test_parse_mtts_flags` - Parse "MTTS nnn" strings
- `test_mtts_utf8_flag` - Verify UTF-8 flag detection from bitvector

### Manual Testing

**Level 1 - UTF-8 content:**
1. Connect with UTF-8 terminal (Mudlet, PuTTY with UTF-8)
2. Create room with Japanese description: `redit desc This is a test room. (テスト)`
3. Use `look` to verify display
4. Type Japanese in commands (e.g., `say こんにちは`)

**Level 2 - MTTS detection:**
1. Connect with Mudlet (supports MTTS)
2. Check server logs for "Client capabilities" message
3. Verify client_name, terminal_type, and mtts_flags are captured
4. Connect with plain `telnet localhost 4000` - should still work (no MTTS)

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Legacy client display issues | Medium | Low | Document UTF-8 requirement; Level 2 detection now available |
| Cursor positioning bugs | Very Low | Low | Fixed with unicode-width crate |
| Performance impact | Very Low | Low | UTF-8 decoding and MTTS negotiation are cheap |
| Breaking existing content | Very Low | Low | All changes are additive |
| MTTS negotiation timeout | Low | Very Low | Clients that don't respond simply don't get detected |

## Decision Points

1. **Is Japanese content needed now?** Level 1 foundation is complete. Content can be added as needed.

2. **What's the target audience?** Primarily English-speaking, but some users are learning Japanese and would benefit from practice opportunities.

3. **Web client plans?** Web client is on hold; telnet is the priority transport.

## Next Steps (When Needed)

**Level 2** (client detection) is now complete. The `utf8_supported` flag can be used to:
- Filter/transliterate non-ASCII output for legacy clients
- Show/hide certain content based on client capability
- Debug charset-related player issues
- Collect analytics on client demographics

Consider **Level 3+** (localization) only if:
- There's significant demand from Japanese-speaking players
- Resources available for ongoing translation maintenance

## Sources

- [Telnet Unicode Support - MUD Coders Wiki](https://mudcoders.fandom.com/wiki/Telnet:Unicode_Support)
- [MTTS Specification - TinTin++](https://tintin.mudhalla.net/protocols/mtts/)
- [Mudlet Supported Protocols](https://wiki.mudlet.org/w/Manual:Supported_Protocols)
- [RFC 2066 - TELNET CHARSET Option](https://www.rfc-editor.org/rfc/rfc2066.html)
- [Mudlet CHARSET Issue #637](https://github.com/Mudlet/Mudlet/issues/637)
- [Mudlet Unicode Manual](https://wiki.mudlet.org/w/Manual:Unicode)
