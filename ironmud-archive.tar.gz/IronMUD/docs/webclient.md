# Web Client Setup

Browser-based MUD client using the [maldorne/mud-web-client](https://github.com/maldorne/mud-web-client) stack with Docker.

## Current Status

**Work in Progress** - The basic infrastructure is in place but there's a JavaScript error preventing the client from connecting.

### What's Working
- Docker containers build and run successfully
- Nginx serves the web client on https://localhost:4443
- WebSocket proxy receives connections from the browser
- Proxy container can reach IronMUD on host via `host.docker.internal:4000`
- SSL certificates generate correctly

### Current Issue
Browser console error when loading the client:
```
Uncaught (in promise) TypeError: this.options.tabs is not iterable
    at ChatterBox.initializeTabs
```

This prevents the client from sending the `connect` message to the proxy, so no telnet connection is established.

## Architecture

```
Browser (https://localhost:4443)
        │
        ▼
┌───────────────────┐
│  Nginx (4443)     │  ← Serves client + proxies WSS
└─────────┬─────────┘
          │ WSS (/wsproxy)
          ▼
┌───────────────────┐
│  mud-web-proxy    │  ← WebSocket to Telnet bridge
│  (internal 8010)  │
└─────────┬─────────┘
          │ Telnet
          ▼
┌───────────────────┐
│  IronMUD          │  ← Runs natively on host
│  (port 4000)      │
└───────────────────┘
```

## Files

```
webclient/
├── docker-compose.yml      # Orchestrates client + proxy services
├── Dockerfile.proxy        # Builds mud-web-proxy image
├── Dockerfile.client       # Builds mud-web-client + nginx image
├── nginx.conf              # HTTPS + WSS proxy configuration
├── ironmud.json            # MUD client configuration
├── generate-certs.sh       # SSL certificate generator
├── README.md               # Setup instructions
├── .gitignore              # Ignores certs/
└── certs/                  # Generated SSL certs (gitignored)
    ├── cert.pem
    └── privkey.pem
```

## Quick Start

```bash
# 1. Generate SSL certificates (first time only)
cd webclient
./generate-certs.sh

# 2. Start IronMUD on host
cargo run

# 3. Start web client stack
sudo docker-compose up -d --build

# 4. Open browser
# https://localhost:4443
# (Accept self-signed cert warning)
```

## Protocol Support (maldorne stack)

- **MXP** - MUD eXtension Protocol (clickable links, popups)
- **GMCP/ATCP** - JSON-based game data
- **MSDP** - MUD Server Data Protocol
- **MCCP** - Compression
- **256 colors** - Extended color palette
- **UTF-8** - Unicode support

## TODOs

### High Priority
- [ ] Fix ChatterBox initialization error
  - The `tabs` configuration in `ironmud.json` is not being parsed correctly
  - May need to investigate maldorne client source to understand expected format
  - Or try using the full example.json from maldorne as a starting point

### Medium Priority
- [ ] Make proxy URL dynamic (currently hardcoded to `localhost:4443`)
  - For remote access, users need to update `ironmud.json` with their server's hostname
  - Consider a build-time or runtime configuration approach
- [ ] Test MXP protocol features once connected
- [ ] Add IronMUD-specific UI customizations

### Low Priority
- [ ] Production SSL setup (Let's Encrypt)
- [ ] Add health checks to docker-compose
- [ ] Consider adding IronMUD to docker-compose for full containerization

## Debugging

### Check container logs
```bash
sudo docker-compose logs -f
```

### Test proxy connectivity to IronMUD
```bash
sudo docker-compose exec proxy sh -c "nc -zv host.docker.internal 4000"
```

### Check browser console
Press F12 → Console tab to see JavaScript errors

### Verify config is loaded
In browser Network tab, check that `/muds/example.json` returns 200 and contains IronMUD config

## References

- [maldorne/mud-web-client](https://github.com/maldorne/mud-web-client) - Web client
- [maldorne/mud-web-proxy](https://github.com/maldorne/mud-web-proxy) - WebSocket to telnet proxy
- [MXP Specification](https://www.zuggsoft.com/zmud/mxp.htm) - MUD eXtension Protocol
