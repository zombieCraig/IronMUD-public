# OLC (Online Creation) System

IronMUD's OLC system allows builders to create and edit game content while connected to the MUD. This document covers the current implementation, planned features, and relevant MUD standards.

## Current Implementation

### Builder Access

Players must have builder access to use OLC commands. The first character created on a fresh database automatically becomes an administrator with builder permissions.

**Builder Mode Setting:**

The server setting `builder_mode` controls how builder access is managed:

| Mode | setbuilder Behavior |
|------|---------------------|
| `all` (default) | `setbuilder [on\|off]` - Any user toggles their own builder status |
| `granted` | `setbuilder <name> [on\|off]` - Only admins can grant/revoke builder |
| `none` | Builder management disabled (use admin utility) |

**Examples:**

```
# When builder_mode = "all" (default)
setbuilder           # Toggle your own builder status
setbuilder on        # Enable your builder status
setbuilder off       # Disable your builder status

# When builder_mode = "granted" (admin only)
setbuilder Craig on  # Grant builder to Craig
setbuilder Craig off # Revoke builder from Craig
```

**Admin Commands:**

```
setadmin <character_name> on   # Grant admin access (admin only)
setadmin <character_name> off  # Revoke admin access (admin only)
```

Note: Admins cannot remove their own admin status in-game. Use the admin utility for that.

### Room Commands

| Command | Usage | Description |
|---------|-------|-------------|
| `dig` | `dig <direction> [title]` | Create a new room with bidirectional exit (inherits area, auto-generates vnum) |
| `link` | `link <direction> <room_id> [both]` | Link exit to existing room |
| `unlink` | `unlink <direction>` | Remove exit from current room |
| `redit` | `redit [subcommand]` | Edit current room properties |
| `rlist` | `rlist [all\|detail]` | List rooms in current area (use `all` for all rooms) |
| `rgoto` | `rgoto <room_id\|vnum>` | Teleport to a room by ID or vnum |
| `rdelete` | `rdelete <room_id>` | Delete a room (cleans up exits) |
| `rfind` | `rfind <keyword>` | Search rooms by title/description |

### redit Subcommands

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `show` | `redit` or `redit show` | Display room properties |
| `title` | `redit title <text>` | Set room title |
| `desc` | `redit desc [text]` | Edit description (or set directly with text) |
| `flags` | `redit flags` | Show all room flags with status |
| `flag` | `redit flag <name> [on\|off]` | Toggle or set a room flag |
| `extra list` | `redit extra list` | List extra descriptions |
| `extra add` | `redit extra add <keywords>` | Add extra description with line editor |
| `extra edit` | `redit extra edit <keyword>` | Edit existing extra description |
| `extra remove` | `redit extra remove <keyword>` | Remove extra description |
| `vnum` | `redit vnum [alias\|clear]` | Set or clear room vnum |
| `area` | `redit area [id\|prefix\|clear]` | Set or clear room area (accepts UUID or prefix) |
| `trigger` | `redit trigger` | List all triggers on current room |
| `trigger add` | `redit trigger add <type> <script>` | Add trigger (enter/exit/look/periodic/on_time_change/on_weather_change/on_season_change) |
| `trigger remove` | `redit trigger remove <index>` | Remove trigger by index |
| `trigger enable` | `redit trigger enable <index>` | Enable a trigger |
| `trigger disable` | `redit trigger disable <index>` | Disable a trigger |
| `trigger interval` | `redit trigger interval <index> <secs>` | Set periodic interval |
| `trigger chance` | `redit trigger chance <index> <1-100>` | Set trigger fire chance |
| `trigger test` | `redit trigger test <index>` | Test fire a trigger for debugging |
| `door` | `redit door` | List doors and show door help |
| `door add` | `redit door add <direction> <name>` | Add door to an exit |
| `door remove` | `redit door remove <direction>` | Remove door from exit |
| `door name` | `redit door name <direction> <name>` | Change door name |
| `door desc` | `redit door desc <direction> [text]` | Set/view door description |
| `door key` | `redit door key <direction> <vnum\|clear>` | Set key requirement by vnum |
| `door keywords` | `redit door keywords <direction> <kw1> [kw2]...` | Set door keywords |
| `door open` | `redit door open <direction>` | Force door open |
| `door close` | `redit door close <direction>` | Force door closed |
| `door lock` | `redit door lock <direction>` | Force door locked |
| `door unlock` | `redit door unlock <direction>` | Force door unlocked |
| `door sync` | `redit door sync <direction>` | Copy door to connected room |
| `seasonal` | `redit seasonal` | Show all seasonal descriptions |
| `seasonal` | `redit seasonal <season> <text>` | Set seasonal description (spring/summer/autumn/winter) |
| `seasonal` | `redit seasonal <season> help <prompt>` | AI generate seasonal description |
| `seasonal` | `redit seasonal <season> rephrase` | AI rephrase existing seasonal description |
| `seasonal` | `redit seasonal <season> clear` | Clear seasonal description |
| `dynamic` | `redit dynamic` | Show dynamic description |
| `dynamic` | `redit dynamic <text>` | Set dynamic description (for triggers) |
| `dynamic` | `redit dynamic clear` | Clear dynamic description |

### Area Commands

| Command | Usage | Description |
|---------|-------|-------------|
| `alist` | `alist` | List all areas |
| `acreate` | `acreate <prefix> <name>` | Create a new area (you become owner) |
| `aedit` | `aedit <area_id> [subcommand]` | Edit area properties |
| `adelete` | `adelete <area_id>` | Delete an area (unassigns rooms) |

### aedit Subcommands

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `show` | `aedit <id>` or `aedit <id> show` | Display area properties |
| `name` | `aedit <id> name <text>` | Set area name |
| `desc` | `aedit <id> desc <text>` | Set area description |
| `prefix` | `aedit <id> prefix <text>` | Set area prefix |
| `theme` | `aedit <id> theme <text>` | Set area theme |
| `levels` | `aedit <id> levels <min> <max>` | Set level range |
| `owner` | `aedit <id> owner <name\|clear>` | Set or clear area owner |
| `permission` | `aedit <id> permission <level>` | Set permission level |
| `trust` | `aedit <id> trust <name>` | Add to trusted builders |
| `untrust` | `aedit <id> untrust <name>` | Remove from trusted builders |
| `trustees` | `aedit <id> trustees` | List trusted builders |

**Permission Levels:**
- `owner_only` - Only the owner can edit the area and its contents
- `trusted` - Owner and trusted builders can edit
- `all_builders` - Any builder can edit (default)

### Object Commands

| Command | Usage | Description |
|---------|-------|-------------|
| `oedit create` | `oedit create <name>` | Create a new item prototype with auto-generated vnum |
| `oedit` | `oedit <item_id\|vnum> [subcommand]` | Edit item properties |
| `ilist` | `ilist` | List all items (shows [PROTO] for prototypes) |
| `ifind` | `ifind <keyword>` | Search items by name/keywords |
| `idelete` | `idelete <item_id>` | Delete an item |
| `ospawn` | `ospawn <vnum> [room\|inv]` | Spawn item from prototype |

### Mobile/NPC Commands

| Command | Usage | Description |
|---------|-------|-------------|
| `medit create` | `medit create <name>` | Create a new mobile prototype with auto-generated vnum |
| `medit` | `medit <mobile_id\|vnum> [subcommand]` | Edit mobile properties |
| `mlist` | `mlist` | List all mobiles (shows [PROTO] for prototypes) |
| `mfind` | `mfind <keyword>` | Search mobiles by name/keywords/vnum |
| `mdelete` | `mdelete <mobile_id>` | Delete a mobile |
| `mspawn` | `mspawn <vnum>` | Spawn mobile from prototype into room |

### medit Subcommands

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `show` | `medit <id>` or `medit <id> show` | Display mobile properties |
| `name` | `medit <id> name <text>` | Set mobile name |
| `short` | `medit <id> short <text>` | Set short description (room view) |
| `long` | `medit <id> long <text>` | Set long description (examine) |
| `keywords` | `medit <id> keywords <kw1> <kw2>...` | Set mobile keywords |
| `level` | `medit <id> level <value>` | Set mobile level |
| `hp` | `medit <id> hp <value>` | Set max HP |
| `damage` | `medit <id> damage <dice>` | Set damage (e.g., 2d6+3) |
| `ac` | `medit <id> ac <value>` | Set armor class |
| `stat` | `medit <id> stat <str\|dex\|con\|int\|wis\|cha> <value>` | Set attribute |
| `flags` | `medit <id> flags` | Show all flags with toggles |
| `flag` | `medit <id> flag <name> [on\|off]` | Toggle mobile flag |
| `prototype` | `medit <id> prototype [on\|off]` | Mark as prototype template |
| `vnum` | `medit <id> vnum <name\|none>` | Set prototype vnum |
| `spawn` | `medit <id> spawn` | Spawn copy into current room |

**Dialogue Subcommands**:

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `dialogue` | `medit <id> dialogue <keyword> <response>` | Add dialogue response |
| `dialogues` | `medit <id> dialogues` | List all dialogues |
| `rmdialogue` | `medit <id> rmdialogue <keyword>` | Remove dialogue |

**Shop Subcommands** (for shopkeeper NPCs):

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `shop` | `medit <id> shop` | Show shop configuration |
| `shop stock add` | `medit <id> shop stock add <vnum>` | Add item to base stock (infinite) |
| `shop stock remove` | `medit <id> shop stock remove <vnum>` | Remove item from base stock |
| `shop buyrate` | `medit <id> shop buyrate <0-100>` | Set % paid when buying from players |
| `shop sellrate` | `medit <id> shop sellrate <50+>` | Set % charged when selling to players |

**Trigger Subcommands**:

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `trigger` | `medit <id> trigger` | Show trigger help |
| `trigger list` | `medit <id> trigger list` | List all triggers on mobile |
| `trigger add` | `medit <id> trigger add <type> <script>` | Add trigger (greet/attack/death/say/idle) |
| `trigger add` | `medit <id> trigger add <type> @template <args>` | Add template trigger |
| `trigger remove` | `medit <id> trigger remove <index>` | Remove trigger by index |
| `trigger enable` | `medit <id> trigger enable <index>` | Enable a trigger |
| `trigger disable` | `medit <id> trigger disable <index>` | Disable a trigger |
| `trigger chance` | `medit <id> trigger chance <index> <1-100>` | Set trigger fire chance |
| `trigger interval` | `medit <id> trigger interval <index> <secs>` | Set idle trigger interval |
| `trigger test` | `medit <id> trigger test <index>` | Test fire a trigger for debugging |

**Built-in Trigger Templates** (no script required):

| Template | Usage | Description |
|----------|-------|-------------|
| `@say_greeting` | `trigger add greet @say_greeting <message>` | NPC says the message |
| `@say_random` | `trigger add greet @say_random <msg1\|msg2\|...>` | NPC says random message |
| `@emote` | `trigger add greet @emote <action>` | NPC performs the action |

### Recipe Commands

| Command | Usage | Description |
|---------|-------|-------------|
| `recedit create` | `recedit create <vnum>` | Create a new recipe with the given vnum |
| `recedit` | `recedit <vnum> [subcommand]` | Edit recipe properties |
| `reclist` | `reclist [cooking\|crafting]` | List all recipes (optionally filter by skill) |
| `recfind` | `recfind <keyword>` | Search recipes by name, vnum, or ingredient |
| `recdelete` | `recdelete <vnum> [confirm]` | Delete a recipe from the database |

### recedit Subcommands

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `show` | `recedit <vnum>` or `recedit <vnum> show` | Display recipe properties |
| `name` | `recedit <vnum> name <text>` | Set recipe display name |
| `vnum` | `recedit <vnum> vnum <new_vnum>` | Rename/change the recipe vnum |
| `skill` | `recedit <vnum> skill <cooking\|crafting>` | Set which skill this recipe uses |
| `level` | `recedit <vnum> level <0-10>` | Set minimum skill level required |
| `autolearn` | `recedit <vnum> autolearn [on\|off]` | Toggle automatic learning at skill level |
| `difficulty` | `recedit <vnum> difficulty <1-10>` | Set crafting difficulty (affects quality) |
| `xp` | `recedit <vnum> xp <amount>` | Set base XP awarded on success |
| `output` | `recedit <vnum> output <item_vnum> [quantity]` | Set output item prototype and quantity |

**Ingredient Subcommands:**

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `ingredient list` | `recedit <vnum> ingredient list` | List all ingredients |
| `ingredient add` | `recedit <vnum> ingredient add <vnum\|@category> <qty>` | Add ingredient requirement |
| `ingredient remove` | `recedit <vnum> ingredient remove <index>` | Remove ingredient by index |

**Tool Subcommands:**

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `tool list` | `recedit <vnum> tool list` | List all required tools |
| `tool add` | `recedit <vnum> tool add <vnum\|@category> <location>` | Add tool requirement |
| `tool remove` | `recedit <vnum> tool remove <index>` | Remove tool by index |

**Ingredient/Tool Syntax:**

- `material:flour` - Exact item vnum match (requires specific item)
- `@flour` - Category match (requires any item with `category: "flour"`)

**Tool Locations:**

- `inv` or `inventory` - Tool must be in player's inventory
- `room` - Tool must be in the current room
- `either` - Tool can be in inventory or room

### Recipe Creation Example

```
> recedit create food:honey_bread
Created recipe with vnum: food:honey_bread

=== Recipe Editor ===
VNUM: food:honey_bread
Name: New Recipe
Skill: cooking
Level Required: 0
...

> recedit food:honey_bread name Honey Bread
Name set to: Honey Bread

> recedit food:honey_bread skill cooking
Skill set to: cooking

> recedit food:honey_bread level 2
Skill level requirement set to: 2

> recedit food:honey_bread autolearn on
Auto-learn: ON (learned automatically at skill level)

> recedit food:honey_bread difficulty 3
Difficulty set to: 3

> recedit food:honey_bread xp 20
Base XP set to: 20

> recedit food:honey_bread output food:bread_basic 1
Output set to: food:bread_basic (Basic Bread)

> recedit food:honey_bread ingredient add @flour 2
Added ingredient: 2x category 'flour'

> recedit food:honey_bread ingredient add material:honey 1
Added ingredient: 1x vnum 'material:honey' (Honey)

> recedit food:honey_bread tool add @oven room
Added tool: category 'oven' [room]

> recedit food:honey_bread
=== Recipe Editor ===
VNUM: food:honey_bread
Name: Honey Bread
Skill: cooking
Level Required: 2
Auto-Learn: ON (learned at skill level)
Difficulty: 3
Base XP: 20

Output: food:bread_basic (Basic Bread)

Ingredients:
  0: 2x @flour (category)
  1: 1x material:honey (Honey)

Tools:
  0: @oven (category) [room]
```

### Shop Commands (Player)

| Command | Usage | Description |
|---------|-------|-------------|
| `list` | `list` | Show items for sale at a shopkeeper in the room |
| `buy` | `buy <item>` | Buy an item from a shopkeeper |
| `sell` | `sell <item>` | Sell an item to a shopkeeper |

### Spawn Point Commands

| Command | Usage | Description |
|---------|-------|-------------|
| `spedit` | `spedit <area_id> [subcommand]` | Manage spawn points in an area |
| `areset` | `areset <area_id>` | Manually trigger area reset (spawn all) |

### spedit Subcommands

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `list` | `spedit <area_id>` or `spedit <area_id> list` | List spawn points |
| `create` | `spedit <area_id> create <room\|.> <mobile\|item> <vnum> <max> <interval>` | Create spawn point (use `.` for current room) |
| `delete` | `spedit <area_id> delete <spawn_point_id>` | Delete spawn point |
| `enable` | `spedit <area_id> enable <spawn_point_id>` | Enable spawn point |
| `disable` | `spedit <area_id> disable <spawn_point_id>` | Disable spawn point |
| `max` | `spedit <area_id> max <spawn_point_id> <count>` | Set max spawned count |
| `interval` | `spedit <area_id> interval <spawn_point_id> <secs>` | Set respawn interval |

### oedit Subcommands

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `show` | `oedit <id>` or `oedit <id> show` | Display item properties |
| `name` | `oedit <id> name <text>` | Set item name |
| `short` | `oedit <id> short <text>` | Set short description (room view) |
| `long` | `oedit <id> long <text>` | Set long description (examine) |
| `keywords` | `oedit <id> keywords <kw1> <kw2>...` | Set item keywords |
| `type` | `oedit <id> type <type>` | Set item type (armor/weapon/container/liquid_container/food/key/misc) |
| `wear` | `oedit <id> wear <loc1> <loc2>...` | Set wear locations |
| `ac` | `oedit <id> ac <value>` | Set armor class |
| `damage` | `oedit <id> damage <count> <sides>` | Set weapon damage (e.g., 2 6 for 2d6) |
| `damtype` | `oedit <id> damtype <type>` | Set damage type (slash/pierce/blunt/fire/cold/lightning/acid/poison) |
| `twohanded` | `oedit <id> twohanded [on\|off]` | Set two-handed weapon |
| `weight` | `oedit <id> weight <value>` | Set item weight |
| `value` | `oedit <id> value <gold>` | Set item value |
| `level` | `oedit <id> level <value>` | Set level requirement (0=none) |
| `stat` | `oedit <id> stat <str\|dex\|con\|int\|wis\|cha> <value>` | Set stat bonus |
| `flags` | `oedit <id> flags` | Show all flags with toggles |
| `flag` | `oedit <id> flag <name> [on\|off]` | Toggle item flag |
| `prototype` | `oedit <id> prototype [on\|off]` | Mark as prototype template |
| `vnum` | `oedit <id> vnum <name\|none>` | Set prototype vnum |
| `spawn` | `oedit <id> spawn` | Spawn copy into current room |

**Trigger Subcommands**:

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `trigger` | `oedit <id> trigger` | Show trigger help |
| `trigger list` | `oedit <id> trigger list` | List all triggers on item |
| `trigger add` | `oedit <id> trigger add <type> <script>` | Add trigger (get/drop/use/examine) |
| `trigger remove` | `oedit <id> trigger remove <index>` | Remove trigger by index |
| `trigger enable` | `oedit <id> trigger enable <index>` | Enable a trigger |
| `trigger disable` | `oedit <id> trigger disable <index>` | Disable a trigger |
| `trigger chance` | `oedit <id> trigger chance <index> <1-100>` | Set trigger fire chance |
| `trigger test` | `oedit <id> trigger test <index>` | Test fire a trigger for debugging |

**Container Subcommands** (for container items):

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `capacity` | `oedit <id> capacity <items> <weight>` | Set max items/weight (0=unlimited) |
| `closed` | `oedit <id> closed [on\|off]` | Set container closed state |
| `locked` | `oedit <id> locked [on\|off]` | Set container locked state |
| `key` | `oedit <id> key <item_id\|none>` | Set key item for lock |

**Liquid Container Subcommands** (for liquid_container items):

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `liquid` | `oedit <id> liquid <type> <current> <max>` | Set liquid type and amount |
| `fill` | `oedit <id> fill` | Fill to maximum |
| `empty` | `oedit <id> empty` | Empty container |
| `liqpoison` | `oedit <id> liqpoison [on\|off]` | Set liquid poisoned |
| `liqeffect` | `oedit <id> liqeffect <type> <mag> <dur>` | Add drink effect |
| `clearliqeffects` | `oedit <id> clearliqeffects` | Remove all drink effects |

**Food Subcommands** (for food items):

| Subcommand | Usage | Description |
|------------|-------|-------------|
| `nutrition` | `oedit <id> nutrition <value>` | Set nutrition value |
| `spoil` | `oedit <id> spoil <seconds>` | Set spoilage time (0=never) |
| `foodpoison` | `oedit <id> foodpoison [on\|off]` | Set food poisoned |
| `foodeffect` | `oedit <id> foodeffect <type> <mag> <dur>` | Add food effect |
| `clearfoodeffects` | `oedit <id> clearfoodeffects` | Remove all food effects |
| `resetfresh` | `oedit <id> resetfresh` | Reset freshness to now |

### Line Editor

When using `redit desc` or `redit extra add/edit`, you enter a line-based editor that pre-loads any existing content and allows editing:

| Command | Description |
|---------|-------------|
| `.l` | List buffer with line numbers |
| `.d <n>` | Delete line n |
| `.i <n> <text>` | Insert text before line n |
| `.r <n> <text>` | Replace line n with text |
| `.s /old/new/` | Substitute: replace all occurrences of 'old' with 'new' |
| `.c` | Clear entire buffer |
| `.u` | Undo last change |
| `.p` | Preview without line numbers |
| `.h` | Show help for all commands |
| `.` | Save and exit |
| `@` | Cancel and exit |
| `<text>` | Append text as new line |

**Features:**
- Existing descriptions are pre-loaded when editing
- Line numbers are 1-based
- Single-level undo for all editing operations
- Commands are case-insensitive
- Substitute command uses any delimiter (e.g., `.s |old|new|` or `.s #old#new#`)

### Example Session

```
> setbuilder MyChar on
MyChar is now a builder.

> dig north The Dark Forest
Created room: The Dark Forest
Room ID: 550e8400-e29b-41d4-a716-446655440000
Exit north -> The Dark Forest
Reverse exit south -> The Town Square

> n
The Dark Forest
--------------------
This room has no description yet.

Exits: south

> redit desc
Editing description for: The Dark Forest
(empty)

Commands: .h help | .l list | .s /old/new/ | . save | @ cancel
Or type text to append new lines.

> Towering ancient oaks block out the sky above.
> A narrow path winds deeper into the forest.
> .l
  1: Towering ancient oaks block out the sky above.
  2: A narrow path winds deeper into the forest.
> .r 1 Ancient oak trees form a dense canopy overhead.
Line 1 replaced.
> .i 2 Shafts of pale light filter through the leaves.
Line 2 inserted.
> .l
  1: Ancient oak trees form a dense canopy overhead.
  2: Shafts of pale light filter through the leaves.
  3: A narrow path winds deeper into the forest.
> .s /forest/woods/
Replaced 1 occurrence(s).
> .l
  1: Ancient oak trees form a dense canopy overhead.
  2: Shafts of pale light filter through the leaves.
  3: A narrow path winds deeper into the woods.
> .
Description saved.

> redit title A Dark and Mysterious Forest
Title updated to: A Dark and Mysterious Forest
```

### Door System

Doors can be added to room exits to control movement. Doors support names (door, gate, hatch, etc.), descriptions, keywords, lock/unlock with keys, and shared state between connected rooms.

**Key Features:**
- Doors block movement when closed
- Opening/closing a door syncs to the connected room automatically
- Players can interact using direction (`open north`) or keyword (`open door`)
- Closed doors hide the destination room title in `exits` command
- Keys are assigned by item vnum for easy reference

**Adding a Door:**

```
> redit door add north gate
Door 'gate' added to north exit.

> redit door desc north A tall iron gate with intricate scrollwork.
Door description set.

> redit door keywords north iron ornate
Door keywords set: iron, ornate

> redit door key north iron_key
Door now requires key: Iron Key (vnum: iron_key)

> redit door sync north
Door synced to connected room (south exit).
```

**Door States:**
- `open` - Players can pass through
- `closed` - Blocks movement, players must open it first
- `locked` - Closed and locked, requires correct key to unlock

**Player Commands:**
- `open <direction|keyword>` - Open a door or container
- `close <direction|keyword>` - Close a door or container
- `lock <direction|keyword>` - Lock a door or container (requires key)
- `unlock <direction|keyword>` - Unlock a door or container (requires key)

**Example Player Interaction:**

```
> exits
Obvious exits:
  North [closed gate]
  South - Town Square

> open north
The gate is locked.

> unlock gate
You unlock the gate with the Iron Key.

> open gate
You open the gate.

> north
You enter the castle courtyard...
```

### Area Inheritance with dig

When you use `dig` from a room that belongs to an area, the new room automatically:
1. Inherits the same area assignment
2. Gets an auto-generated vnum based on the room title (if a custom title is provided)

**Example:**
```
> redit area forest
Room assigned to area: Dark Forest

> dig north Misty Glade
Created room: Misty Glade
Room ID: 550e8400-e29b-41d4-a716-446655440001
Vnum: forest:misty_glade
Area: Dark Forest [forest]
Exit north -> Misty Glade
Reverse exit south -> Town Square
```

**Vnum generation rules:**
- Title is converted to lowercase
- Spaces and dashes become underscores
- Special characters are removed
- Max 24 characters for the slug portion
- If the vnum already exists, a number suffix is added (`_2`, `_3`, etc.)

**Examples:**
- "The Dark Forest" → `forest:the_dark_forest`
- "Bob's Tavern!" → `forest:bobs_tavern`
- Duplicate "Misty Glade" → `forest:misty_glade_2`

Note: Rooms with the default title "A New Room" do not get auto-generated vnums.

### Item Creation with oedit

The `oedit create` command creates a new item prototype with an auto-generated vnum based on the item name.

**Example:**
```
> oedit create Rusty Sword
Created item prototype with vnum: rusty_sword
=== Item Properties ===
Name: Rusty Sword
ID: 550e8400-e29b-41d4-a716-446655440002
Vnum: rusty_sword
Type: Misc
...

> oedit rusty_sword type weapon
Type set to: Weapon

> oedit rusty_sword damage 2 6
Damage set to: 2d6
```

**Vnum generation rules (same as rooms, but no prefix):**
- Name is converted to lowercase
- Spaces and dashes become underscores
- Special characters are removed
- Max 24 characters
- If the vnum already exists, a number suffix is added (`_2`, `_3`, etc.)

**Examples:**
- "Rusty Sword" → `rusty_sword`
- "Potion of Healing" → `potion_of_healing`
- Duplicate "Rusty Sword" → `rusty_sword_2`

### Mobile Creation with medit

The `medit create` command creates a new mobile prototype with an auto-generated vnum based on the mobile name.

**Example:**
```
> medit create Town Guard
Created mobile prototype with vnum: town_guard
=== Mobile Properties ===
Name: Town Guard
ID: 550e8400-e29b-41d4-a716-446655440003
Vnum: town_guard
Level: 1
...

> medit town_guard level 10
Level set to: 10

> medit town_guard flag shopkeeper on
Flag shopkeeper set to: ON
```

**Vnum generation rules (same as items):**
- Name is converted to lowercase
- Spaces and dashes become underscores
- Special characters are removed
- Max 24 characters
- If the vnum already exists, a number suffix is added (`_2`, `_3`, etc.)

**Examples:**
- "Town Guard" → `town_guard`
- "Goblin Shaman" → `goblin_shaman`
- Duplicate "Town Guard" → `town_guard_2`

### Prototypes and Spawning

Prototypes are template objects used to create instances of items and mobiles. They are never directly interacted with by players - instead, copies are spawned from them.

**Key Concepts:**

- **Prototype**: A template marked with `is_prototype = true`. Prototypes have vnums and are used as blueprints.
- **Instance**: A copy spawned from a prototype. Instances exist in the game world and can be interacted with.
- **Vnum**: A human-readable identifier (e.g., `rusty_sword`, `town_guard`) used to reference prototypes.

**Workflow:**

1. **Create a prototype** using `oedit create` or `medit create`
2. **Configure the prototype** with properties, flags, triggers, etc.
3. **Spawn instances** using `ospawn`/`mspawn` or spawn points

**Manual Spawning:**

```
> oedit create Health Potion
Created item prototype with vnum: health_potion

> oedit health_potion type food
> oedit health_potion nutrition 50

> ospawn health_potion inv
Spawned Health Potion into your inventory.

> mspawn town_guard
Spawned Town Guard into the room.
```

**Automatic Spawning with Spawn Points:**

Spawn points automatically respawn items and mobiles in areas. Use `spedit` to configure:

```
> spedit myarea create . mobile town_guard 3 300
```

This creates a spawn point in your current room that maintains up to 3 Town Guards, respawning every 300 seconds. Use `.` for the current room or specify a room vnum.

**Prototype vs Instance:**

| Aspect | Prototype | Instance |
|--------|-----------|----------|
| `is_prototype` | `true` | `false` |
| Has vnum | Yes (required) | No |
| Visible to players | No | Yes |
| Can be modified | Yes (via oedit/medit) | Limited |
| Location | None (template only) | Room, inventory, etc. |

**Best Practices:**

- Always create items/mobiles as prototypes first, then spawn instances
- Use descriptive vnums (`healing_potion` not `pot1`)
- Set up spawn points for recurring content rather than manual spawning
- Prototype changes don't affect existing instances - respawn to see updates

---

## Planned Features (TODOs)

### Phase 2: Enhanced Room System ✓

- [x] **Vnum system**: Human-readable room aliases (e.g., `forest:1`, `tavern:main`)
- [x] **Room flags**: `dark`, `safe`, `no_mob`, `indoors`, `underwater`
- [x] **Extra descriptions**: Keywords that trigger additional descriptions (e.g., `look fountain`)
- [x] **Areas/Zones**: Group rooms by area with metadata (level range, theme)
- [x] **Room search**: `rfind <keyword>` to search rooms by title/description

### Phase 3: MXP Enhancement ✓

- [ ] **MXP detection**: Negotiate MXP support on connection (deferred - requires telnet layer)
- [x] **Clickable menus**: Make OLC output interactive with `<send>` tags
- [x] **Popup menus**: Right-click context menus for common actions
- [x] **mxp toggle**: Command to enable/disable MXP

### Phase 4: Object Editor (oedit) ✓

- [x] **Item types**: weapon, armor, container, liquid_container, food, key, misc
- [x] **Item properties**: weight, value, level requirement, stat bonuses (str/dex/con/int/wis/cha)
- [x] **Item flags**: no_drop, no_get, no_remove, invisible, glow, hum, no_sell, unique, quest_item
- [x] **Container support**: Items that hold other items, with locking/keys
- [x] **Liquid containers**: Drinks with effects, poisoning, capacity
- [x] **Food system**: Nutrition, spoilage, poisoning, effects
- [x] **Object prototypes**: Templates with vnums for spawning items
- [ ] **Light items**: (deferred to dark room implementation)

### Phase 5: Mobile/NPC Editor (medit) ✓

- [x] **NPC templates**: Base stats, descriptions, behaviors, prototype system
- [x] **AI flags**: aggressive, sentinel, scavenger, shopkeeper, no_attack
- [x] **Simple dialogue**: NPCs respond to keywords when players speak
- [x] **Room integration**: NPCs visible in room with `look` command
- [x] **Spawn points**: Area-based spawn system with automatic respawning
- [x] **Shop system**: NPCs that buy/sell items with configurable rates

### Phase 6: Scripting & Triggers (Complete)

- [x] **Room triggers**: on_enter, on_exit, on_look, periodic
- [x] **Object triggers**: on_get, on_drop, on_use, on_examine
- [x] **NPC triggers**: on_greet, on_say (on_attack, on_death await combat system)
- [ ] **Quest system**: Objectives, rewards, prerequisites (deferred)

### Phase 7: Area Management

- [ ] **Area files**: Export/import areas as files (deferred - not needed)
- [x] **Area reset**: Respawn NPCs and objects on timer (via spawn points)
- [x] **Builder permissions**: Per-area ownership with permission levels (owner_only/trusted/all_builders)
- [ ] **Version control**: Track changes to areas (deferred)

---

## MUD Standards & References

### ROM OLC (Traditional Standard)

The ROM (Rivers of MUD) OLC system established conventions still used today:

- **redit/medit/oedit**: Room/Mobile/Object editors
- **Vnum system**: Virtual numbers for referencing objects
- **Menu-based interface**: Numbered options for editing

Reference: [ROM OLC Documentation](http://www.rom.org/)

### MXP (MUD eXtension Protocol)

MXP enables rich client features like clickable links:

```
<send href="look north">north</send>
<send "cmd1|cmd2" hint="menu|Option 1|Option 2">click</send>
```

- **Specification**: https://www.zuggsoft.com/zmud/mxp.htm
- **Client support**: Mudlet, MUSHclient, CMUD
- **Key features**: Clickable commands, popup menus, custom elements

### GMCP (Generic MUD Communication Protocol)

Out-of-band data for client integration:

```json
Room.Info { "id": "123", "name": "Town Square", "exits": ["north", "east"] }
```

- **Specification**: https://tintin.mudhalla.net/protocols/gmcp/
- **Use cases**: Auto-mapping, health bars, room data
- **Client support**: Mudlet, TinTin++, Blightmud

### MSDP (MUD Server Data Protocol)

Alternative to GMCP for structured data:

- **Specification**: https://tintin.mudhalla.net/protocols/msdp/
- **Simpler than GMCP**: Key-value pairs vs JSON

### Evennia (Modern Python MUD)

Modern MUD engine with excellent documentation:

- **Website**: https://www.evennia.com/
- **Building docs**: https://www.evennia.com/docs/latest/Building/
- **Relevant concepts**: Typeclass system, in-game Python, web integration

### LPMud / DGD

Influential MUD architecture:

- **LPC language**: In-game object-oriented scripting
- **Mudlib concept**: Separation of driver and game logic
- **Reference**: https://www.cs.hmc.edu/~jhsu/wilderness/

---

## Design Principles

### 1. Fun First
Building should feel like play, not work. Minimize friction, maximize creativity.

### 2. Immediate Feedback
Changes take effect instantly. Hot-reloading means no restarts.

### 3. Safety Rails
Prevent accidents (can't delete room you're in, can't delete starting room).

### 4. Progressive Disclosure
Simple commands for common tasks, advanced options when needed.

### 5. Client Agnostic (with Enhancement)
Works in plain telnet, enhanced with MXP-capable clients.

---

## File Structure

```
scripts/commands/
├── dig.rhai        # Create room + exits
├── link.rhai       # Link exit to room
├── unlink.rhai     # Remove exit
├── redit.rhai      # Room editor (title, desc, flags, extra, vnum, area)
├── rlist.rhai      # List rooms with vnums
├── rgoto.rhai      # Teleport to room by ID or vnum
├── rdelete.rhai    # Delete room
├── rfind.rhai      # Search rooms by keyword
├── alist.rhai      # List all areas
├── acreate.rhai    # Create new area
├── aedit.rhai      # Edit area properties
├── adelete.rhai    # Delete area
├── oedit.rhai      # Object editor (all item properties)
├── ilist.rhai      # List items (shows [PROTO] for prototypes)
├── ifind.rhai      # Search items by keyword
├── idelete.rhai    # Delete item
├── ospawn.rhai     # Spawn item from prototype by vnum
├── medit.rhai      # Mobile editor (all NPC properties)
├── mlist.rhai      # List mobiles (shows [PROTO] for prototypes)
├── mfind.rhai      # Search mobiles by keyword
├── mdelete.rhai    # Delete mobile
├── mspawn.rhai     # Spawn mobile from prototype by vnum
├── spedit.rhai     # Spawn point editor
├── areset.rhai     # Area reset (trigger all spawn points)
├── list.rhai       # List items for sale at shopkeeper
├── buy.rhai        # Buy item from shopkeeper
├── sell.rhai       # Sell item to shopkeeper
├── setbuilder.rhai # Grant builder access
├── mxp.rhai        # Toggle MXP clickable links
├── recedit.rhai    # Recipe editor (all recipe properties)
├── reclist.rhai    # List recipes (filter by skill)
├── recfind.rhai    # Search recipes by keyword
└── recdelete.rhai  # Delete recipe

scripts/triggers/
├── trapped_room.rhai     # Room: on_enter - blocks entry without key
├── forest_ambiance.rhai  # Room: periodic - random atmospheric messages
├── guardian_look.rhai    # Room: on_look - adds flavor text
├── safe_zone_exit.rhai   # Room: on_exit - warns on leaving safe area
├── cursed_item.rhai      # Item: on_get - chance to hurt and cancel pickup
├── soulbound_drop.rhai   # Item: on_drop - prevents dropping soulbound item
├── magic_potion.rhai     # Item: on_use - adds flavor when drinking
├── ancient_tome.rhai     # Item: on_examine - reveals hidden knowledge
├── sticky_trap.rhai      # Item: on_get - sticky trap cancels pickup
├── guard_greet.rhai      # NPC: on_greet - guard challenges newcomers
├── innkeeper_greet.rhai  # NPC: on_greet - friendly welcome
├── quest_giver.rhai      # NPC: on_greet - offers quest to players
├── hostile_greet.rhai    # NPC: on_greet - threatens players
└── secret_word.rhai      # NPC: on_say - responds to secret words
```

---

## Room Triggers

Room triggers enable scripted behaviors that fire on specific events. Each trigger points to a Rhai script in `scripts/triggers/`.

### Trigger Types

| Type | Event | Can Cancel |
|------|-------|------------|
| `on_enter` | Player enters room | Yes |
| `on_exit` | Player leaves room | Yes |
| `on_look` | Player looks at room | No |
| `periodic` | Timer-based (every N seconds) | No |
| `on_time_change` | Time of day changes (dawn, dusk, etc.) | No |
| `on_weather_change` | Weather condition changes | No |
| `on_season_change` | Season changes (spring, summer, etc.) | No |

### Trigger Properties

- **script_name**: Name of the script (without path/extension), e.g., `trapped_room`
- **enabled**: Whether the trigger is active
- **interval_secs**: For periodic triggers, how often to fire (default 60)
- **chance**: Percentage chance to fire (1-100, default 100)

### Trigger Script Format

Trigger scripts export a `run_trigger` function:

```rhai
fn run_trigger(room_id, connection_id, context) {
    // room_id: UUID of the room
    // connection_id: UUID of the player's connection
    // context: Map with event-specific data:
    //   on_enter: { direction, source_room }
    //   on_exit: { direction, target_room }
    //   on_look: { }
    //   periodic: { trigger_type: "periodic" }

    // Available functions:
    // send_client_message(connection_id, message)
    // broadcast_to_room(room_id, message, exclude_name)
    // get_player_character(connection_id)
    // get_room_data(room_id)
    // random_int(min, max)

    // Return "continue" to allow action, "cancel" to prevent it
    return "continue";
}
```

### Example: Trapped Room (on_enter)

```rhai
fn run_trigger(room_id, connection_id, context) {
    let char = get_player_character(connection_id);
    if char == () { return "continue"; }

    let roll = random_int(1, 100);
    if roll <= 30 {
        send_client_message(connection_id, "A magical barrier repels you!");
        return "cancel";  // Block entry
    }
    return "continue";
}
```

### Example: Forest Ambiance (periodic)

```rhai
fn run_trigger(room_id, connection_id, context) {
    let messages = [
        "An owl hoots in the distance.",
        "The wind whispers through the branches.",
        "You hear rustling nearby."
    ];
    let idx = random_int(0, messages.len() - 1);
    send_client_message(connection_id, messages[idx]);
    return "continue";
}
```

### Adding Triggers to Rooms

```
> redit trigger add enter trapped_room
Trigger added: enter -> trapped_room

> redit trigger add periodic forest_ambiance
Trigger added: periodic -> forest_ambiance

> redit trigger interval 1 30
Trigger 1 interval set to 30 seconds.

> redit trigger chance 1 50
Trigger 1 chance set to 50%.

> redit trigger
=== Room Triggers ===
  0. on_enter -> trapped_room [ON]
  1. periodic -> forest_ambiance [ON] (every 30s) (50% chance)
```

---

## Environmental Triggers

Environmental triggers fire automatically when game world conditions change. These include time of day, weather, and season changes. Indoor rooms (with the `indoors` or `climate_controlled` flags) are skipped for weather and season triggers.

### Trigger Types

| Type | Event | Skips Indoor |
|------|-------|--------------|
| `on_time_change` | Time of day changes | No |
| `on_weather_change` | Weather condition changes | Yes |
| `on_season_change` | Season changes | Yes |

### Context Variables

Each trigger type provides context variables to your script:

**on_time_change:**
- `old_time`: Previous time of day (dawn, morning, noon, afternoon, dusk, evening, night)
- `new_time`: New time of day
- `is_dawn`: "true" if transitioning to dawn
- `is_dusk`: "true" if transitioning to dusk
- `is_night`: "true" if transitioning to night
- `is_day`: "true" if daytime

**on_weather_change:**
- `old_weather`: Previous weather condition
- `new_weather`: New weather condition
- `is_raining`: "true" if any rain
- `is_snowing`: "true" if any snow
- `is_clear`: "true" if clear or partly cloudy

**on_season_change:**
- `old_season`: Previous season (spring, summer, autumn, winter)
- `new_season`: New season
- `is_spring`, `is_summer`, `is_autumn`, `is_winter`: "true" if matching

### Built-in Templates

For simple room messages, use built-in templates instead of writing scripts:

| Template | Arguments | Description |
|----------|-----------|-------------|
| `@room_message` | `<message>` | Always broadcasts the message |
| `@time_message` | `<time> <message>` | Broadcasts only when `new_time` matches |
| `@weather_message` | `<weather> <message>` | Broadcasts only when `new_weather` matches |
| `@season_message` | `<season> <message>` | Broadcasts only when `new_season` matches |

**Weather Matching:**
The `@weather_message` template supports category matching:
- `raining` - matches light_rain, rain, heavy_rain, thunderstorm
- `snowing` - matches light_snow, snow, blizzard
- `stormy` - matches thunderstorm
- `precipitation` - matches any rain or snow
- Exact weather names also work (e.g., `thunderstorm`, `clear`, `foggy`)

### Examples

**Simple room messages (using templates):**

```
> redit trigger add on_time_change @room_message "The magical torches flicker to life."
Added trigger: on_time_change -> @room_message

> redit trigger add on_weather_change @room_message "You hear the sound of weather changing outside."
Added trigger: on_weather_change -> @room_message

> redit trigger add on_season_change @room_message "The air feels different as the seasons shift."
Added trigger: on_season_change -> @room_message
```

**Conditional messages (fires only for specific conditions):**

```
> redit trigger add on_time_change @time_message dusk "The wall torches flicker to life as dusk settles."
Added trigger: on_time_change -> @time_message

> redit trigger add on_time_change @time_message dawn "Sunlight streams through the windows."
Added trigger: on_time_change -> @time_message

> redit trigger add on_weather_change @weather_message raining "Rain begins to drum against the roof."
Added trigger: on_weather_change -> @weather_message

> redit trigger add on_weather_change @weather_message clear "The clouds part and sunlight breaks through."
Added trigger: on_weather_change -> @weather_message

> redit trigger add on_season_change @season_message winter "Frost forms on the inside of the windows."
Added trigger: on_season_change -> @season_message

> redit trigger add on_season_change @season_message spring "Fresh flower scents drift through the open windows."
Added trigger: on_season_change -> @season_message
```

**Custom script (advanced):**

```
> redit trigger add on_time_change torches_at_night
Added trigger: on_time_change -> torches_at_night
```

Example script `scripts/triggers/torches_at_night.rhai`:
```rhai
fn run_trigger(room_id, connection_id, context) {
    let new_time = context.get("new_time");
    if new_time == () { return "continue"; }

    if new_time == "dusk" || new_time == "night" {
        broadcast_to_room(room_id, "The wall torches flicker to life, casting dancing shadows.", "");
    } else if new_time == "dawn" || new_time == "morning" {
        broadcast_to_room(room_id, "The wall torches extinguish as daylight fills the room.", "");
    }
    return "continue";
}
```

### Room Flags Affecting Environmental Triggers

| Flag | Effect |
|------|--------|
| `indoors` | Skips weather/season triggers; no weather line in `look` |
| `climate_controlled` | Skips weather/season triggers |
| `always_hot` | Shows "The air here is oppressively hot." in `look` |
| `always_cold` | Shows "A bitter cold permeates this place." in `look` |

**Note:** Time change triggers fire everywhere, including indoors. Weather and season triggers only fire in outdoor rooms (rooms without `indoors` or `climate_controlled` flags).

### Weather Display in Rooms

Outdoor rooms automatically show a weather line when using the `look` command:

```
The Town Square
-------------------
A bustling marketplace surrounded by shops and stalls.

Exits: north, east, south, west

It is clear and mild.
```

Indoor rooms do not show weather. Rooms with `always_hot` or `always_cold` flags show those conditions instead.

---

## Seasonal and Dynamic Descriptions

Rooms can have additional descriptions that automatically append to the main room description based on conditions.

### Seasonal Descriptions

Four seasonal description fields automatically display based on the current game season:
- `spring_desc` - Displays during spring months
- `summer_desc` - Displays during summer months
- `autumn_desc` - Displays during autumn months
- `winter_desc` - Displays during winter months

These are perfect for environmental details that change with seasons, like trees, gardens, or weather effects.

**Setting Seasonal Descriptions:**

```
> redit seasonal
=== Seasonal Descriptions ===
Spring: (none)
Summer: (none)
Autumn: (none)
Winter: (none)

Current season: spring

> redit seasonal spring The sakura trees burst with pink blossoms, petals drifting on the breeze.
spring description set to: The sakura trees burst with pink blossoms, petals drifting on the breeze.

> redit seasonal summer The sakura trees provide cool green shade from the summer sun.
> redit seasonal autumn Golden sakura leaves carpet the ground in brilliant colors.
> redit seasonal winter Bare sakura branches glisten with frost in the cold air.
```

**With AI Assistance (if enabled):**

```
> redit seasonal spring help cherry blossom trees in full bloom
Generating spring description... please wait.

> redit seasonal summer rephrase
Rephrasing summer description... please wait.

> redit seasonal winter clear
winter description cleared.
```

### Dynamic Description

A single `dynamic_desc` field can be set by triggers for temporary or event-based content like weather effects, special events, or quest-related changes.

**Setting Dynamic Description:**

```
> redit dynamic
=== Dynamic Description ===
Current: (none)

> redit dynamic Rain patters gently on the cobblestones, forming small puddles.
Dynamic description set to: Rain patters gently on the cobblestones, forming small puddles.

> redit dynamic clear
Dynamic description cleared.
```

**Using in Triggers:**

The dynamic description is typically set by triggers rather than manually:

```rhai
// In a weather change trigger
fn run_trigger(room_id, connection_id, context) {
    let weather = context.get("new_weather");
    if weather == "rain" || weather == "heavy_rain" {
        set_room_dynamic_desc(room_id, "Rain drums against the windows.");
    } else if weather == "clear" {
        clear_room_dynamic_desc(room_id);
    }
    return "continue";
}
```

### Display Order

When a player looks at a room, descriptions are displayed in this order:
1. Base room description
2. Seasonal description (if set for current season)
3. Dynamic description (if set)

All three are combined into a single paragraph.

---

## Item Triggers

Item triggers enable scripted behaviors that fire when players interact with items. Each trigger points to a Rhai script in `scripts/triggers/`.

### Trigger Types

| Type | Event | Can Cancel |
|------|-------|------------|
| `on_get` | Player picks up item | Yes |
| `on_drop` | Player drops item | Yes |
| `on_use` | Player uses item (drink/eat) | Yes |
| `on_examine` | Player examines item | No |

### Trigger Properties

- **script_name**: Name of the script (without path/extension), e.g., `cursed_item`
- **enabled**: Whether the trigger is active
- **chance**: Percentage chance to fire (1-100, default 100)

### Trigger Script Format

Item trigger scripts export a `run_trigger` function:

```rhai
fn run_trigger(item_id, connection_id, context) {
    // item_id: UUID of the item
    // connection_id: UUID of the player's connection
    // context: Map with event-specific data:
    //   on_get: { char_name, room_id, from_container, container_id?, container_name? }
    //   on_drop: { char_name, room_id }
    //   on_use: { char_name, room_id, use_type: "drink"|"eat" }
    //   on_examine: { char_name, room_id }

    // Available functions:
    // send_client_message(connection_id, message)
    // get_player_character(connection_id)
    // get_item_data(item_id)
    // random_int(min, max)

    // Return "continue" to allow action, "cancel" to prevent it
    return "continue";
}
```

### Example: Cursed Item (on_get)

```rhai
fn run_trigger(item_id, connection_id, context) {
    let char = get_player_character(connection_id);
    if char == () { return "continue"; }

    // 30% chance to trigger curse
    let roll = random_int(1, 100);
    if roll <= 30 {
        send_client_message(connection_id, "Dark energy courses through your hand!");
        return "cancel";  // Block pickup
    }
    send_client_message(connection_id, "A chill runs down your spine.");
    return "continue";
}
```

### Example: Soulbound Item (on_drop)

```rhai
fn run_trigger(item_id, connection_id, context) {
    send_client_message(connection_id, "This item is soulbound and cannot be dropped!");
    return "cancel";  // Always prevent drop
}
```

### Example: Ancient Tome (on_examine)

```rhai
fn run_trigger(item_id, connection_id, context) {
    let messages = [
        "The pages whisper of ancient evil.",
        "You glimpse a map before the ink fades.",
        "Strange symbols glow briefly."
    ];
    let idx = random_int(0, messages.len() - 1);
    send_client_message(connection_id, messages[idx]);
    return "continue";  // on_examine can't cancel
}
```

### Adding Triggers to Items

```
> oedit <item_id> trigger add get cursed_item
Added get trigger: cursed_item

> oedit <item_id> trigger add drop soulbound_drop
Added drop trigger: soulbound_drop

> oedit <item_id> trigger chance 0 30
Trigger at index 0 now has 30% chance to fire.

> oedit <item_id> trigger list
=== Triggers on Cursed Blade ===
0: [ON]  on_get -> cursed_item (30% chance)
1: [ON]  on_drop -> soulbound_drop
```

---

## NPC Triggers

NPC triggers enable scripted behaviors that fire when players interact with mobiles. Each trigger points to a Rhai script in `scripts/triggers/`.

### Trigger Types

| Type | Event | Can Cancel |
|------|-------|------------|
| `on_greet` | Player enters room with NPC | No |
| `on_say` | Player says something in room | No |
| `on_idle` | Periodic when players present | No |
| `on_attack` | NPC is attacked (future) | Yes |
| `on_death` | NPC dies (future) | No |

### Trigger Properties

- **script_name**: Name of the script (without path/extension), e.g., `guard_greet`, or a template like `@say_greeting`
- **enabled**: Whether the trigger is active
- **chance**: Percentage chance to fire (1-100, default 100)
- **interval_secs**: For idle triggers, how often to fire (default 60)
- **args**: Template arguments (for `@say_greeting`, `@say_random`, `@emote`)

### Trigger Script Format

NPC trigger scripts export a `run_trigger` function:

```rhai
fn run_trigger(mobile_id, connection_id, context) {
    // mobile_id: UUID of the NPC
    // connection_id: UUID of the player's connection
    // context: Map with event-specific data:
    //   on_greet: { char_name, direction, source_room, mobile_name }
    //   on_say: { char_name, message, room_id, mobile_name }
    //   on_idle: { trigger_type: "idle", mobile_name }
    //   on_attack: { char_name, damage, weapon } (future)
    //   on_death: { killer_name } (future)

    // Available functions:
    // send_client_message(connection_id, message)
    // broadcast_to_room(room_id, message, exclude)  // For idle triggers
    // get_player_character(connection_id)
    // get_mobile_data(mobile_id)
    // random_int(min, max)

    // Return "continue" to allow action, "cancel" to prevent it
    return "continue";
}
```

### Example: Guard Greeting (on_greet)

```rhai
fn run_trigger(mobile_id, connection_id, context) {
    let char = get_player_character(connection_id);
    if char == () { return "continue"; }

    let mobile = get_mobile_data(mobile_id);
    let roll = random_int(1, 3);

    if roll == 1 {
        send_client_message(connection_id, mobile.name + " eyes you suspiciously.");
    } else if roll == 2 {
        send_client_message(connection_id, mobile.name + " nods curtly.");
    } else {
        send_client_message(connection_id, mobile.name + " says: \"State your business.\"");
    }
    return "continue";
}
```

### Example: Secret Word Response (on_say)

```rhai
fn run_trigger(mobile_id, connection_id, context) {
    let message = context.get("message");
    if message == () { return "continue"; }

    let mobile = get_mobile_data(mobile_id);
    let msg_lower = message.to_lower();

    if msg_lower.contains("xyzzy") {
        send_client_message(connection_id, mobile.name + " gasps: \"You know the ancient word!\"");
    }
    return "continue";
}
```

### Adding Triggers to NPCs

```
> medit <mobile_id> trigger add greet guard_greet
Added greet trigger: guard_greet

> medit <mobile_id> trigger add say secret_word
Added say trigger: secret_word

> medit <mobile_id> trigger chance 0 50
Trigger at index 0 now has 50% chance to fire.

> medit <mobile_id> trigger list
=== Triggers on Guard Captain ===
0: [ON]  on_greet -> guard_greet (50% chance)
1: [ON]  on_say -> secret_word
```

### Built-in Trigger Templates

For simple NPC behaviors, you can use built-in templates instead of writing Rhai scripts:

| Template | Arguments | Behavior |
|----------|-----------|----------|
| `@say_greeting` | `<message>` | NPC says the message when triggered |
| `@say_random` | `<msg1\|msg2\|...>` | NPC randomly picks and says one message |
| `@emote` | `<action>` | NPC performs the emote action |

**Examples:**

```
> medit shopkeeper trigger add greet @say_greeting Welcome to my shop!
Added greet template: @say_greeting

> medit innkeeper trigger add greet @say_random Hello there!|Welcome, traveler!|Make yourself at home.
Added greet template: @say_random

> medit guard trigger add greet @emote eyes you suspiciously.
Added greet template: @emote

> medit shopkeeper trigger list
=== Triggers on Shopkeeper ===
0: [ON]  on_greet -> @say_greeting "Welcome to my shop!"
```

### Testing Triggers

Use the `trigger test` command to manually fire a trigger for debugging:

```
> medit <mobile_id> trigger test 0
Testing trigger 0...
Trigger executed successfully!
Result: continue
```

If a trigger fails, the error message will help identify the problem:

```
> medit <mobile_id> trigger test 0
Testing trigger 0...
Trigger test failed: Script not found: scripts/triggers/missing_script.rhai
```

### Idle Triggers

Idle triggers fire periodically when players are present in the same room as the NPC. They're perfect for ambient NPC behavior like random comments, emotes, or actions.

**Key Features:**
- Only fire when at least one player is in the room
- Each trigger has its own interval (default 60 seconds)
- Can use the existing templates (`@say_greeting`, `@say_random`, `@emote`)
- Combine with chance percentage for more natural randomness

**Adding Idle Triggers:**

```
> medit town_guard trigger add idle @say_random "Nice weather today.|I could use a break.|*yawns*"
Added idle template: @say_random

> medit town_guard trigger interval 0 30
Trigger at index 0 now has 30 second interval.

> medit town_guard trigger chance 0 50
Trigger at index 0 now has 50% chance to fire.

> medit town_guard trigger list
=== Triggers on Town Guard ===
0: [ON]  on_idle -> @say_random ["Nice weather today.", "I could use a break.", "*yawns*"] (50% chance) [every 30s]
```

**Idle Trigger Examples:**

```
# NPC says random things every minute
medit innkeeper trigger add idle @say_random "Business has been slow lately.|*polishes a glass*|Welcome, traveler!"

# NPC performs emotes every 45 seconds with 30% chance
medit blacksmith trigger add idle @emote wipes sweat from his brow.
medit blacksmith trigger interval 0 45
medit blacksmith trigger chance 0 30

# NPC says something specific
medit merchant trigger add idle @say_greeting Anyone looking for quality goods?
medit merchant trigger interval 0 90
```

**Custom Idle Script:**

Create `scripts/triggers/guard_idle.rhai`:
```rhai
fn run_trigger(mobile_id, connection_id, context) {
    let mobile = get_mobile_data(mobile_id);
    if mobile == () { return "continue"; }

    let actions = [
        mobile.name + " shifts his weight from foot to foot.",
        mobile.name + " scans the area with a watchful eye.",
        mobile.name + " adjusts his weapon belt."
    ];

    let idx = random_int(0, actions.len() - 1);
    broadcast_to_room("", actions[idx], "");
    return "continue";
}
```

Then add it to an NPC:
```
> medit town_guard trigger add idle guard_idle
Added idle trigger: guard_idle

> medit town_guard trigger interval 0 120
Trigger at index 0 now has 120 second interval.
```

---

## MXP (Clickable Links)

MXP (MUD eXtension Protocol) enables clickable links in supported clients like Mudlet, MUSHclient, and CMUD.

### Enabling MXP

```
> mxp on
MXP enabled. Clickable links are now active.
Test link: [Click here to look]

> mxp off
MXP disabled. Plain text mode.
```

### MXP-Enhanced Commands

When MXP is enabled, these commands show clickable elements:

| Command | Clickable Features |
|---------|-------------------|
| `look` | Exit directions (click to move) |
| `exits` | Exit directions with destinations |
| `redit` | Commands, flag toggles, exit menus |
| `redit flags` | Click flags to toggle on/off |
| `rlist` | Room titles (popup: Go To / Edit) |
| `alist` | Area names (popup: Edit / Delete) |

### MXP Tag Format

For script developers, MXP helper functions are available:

```rhai
// Simple clickable link
mxp_send("look", "Click to look")  // -> <send href="look">Click to look</send>

// Popup menu
mxp_menu(["cmd1", "cmd2"], ["Option 1", "Option 2"], "Click me")

// Conditional output (MXP or plain text)
mxp_or(mxp_version, plain_version, connection_id)

// Send with MXP secure line prefix
send_mxp_message(connection_id, output)
```

---

## Technical Notes

### Data Model

```rust
pub struct RoomData {
    pub id: Uuid,
    pub title: String,
    pub description: String,
    pub exits: RoomExits,      // north, south, east, west, up, down
    pub flags: RoomFlags,      // dark, safe, no_mob, indoors, underwater
    pub extra_descs: Vec<ExtraDesc>,
    pub vnum: Option<String>,  // Human-readable alias
    pub area_id: Option<Uuid>,
    pub doors: HashMap<String, DoorState>,  // direction -> door
    // Seasonal descriptions - auto-display based on current game season
    pub spring_desc: Option<String>,
    pub summer_desc: Option<String>,
    pub autumn_desc: Option<String>,
    pub winter_desc: Option<String>,
    // Dynamic description - set by triggers for weather, events, etc.
    pub dynamic_desc: Option<String>,
}

pub struct DoorState {
    pub name: String,           // "door", "gate", "hatch", etc.
    pub is_closed: bool,
    pub is_locked: bool,
    pub key_id: Option<Uuid>,   // Key item required to unlock
    pub description: Option<String>,
    pub keywords: Vec<String>,  // Additional keywords like "wooden", "iron"
}

pub struct RoomFlags {
    pub dark: bool,       // Room is too dark to see without light
    pub safe: bool,       // No PvP combat allowed
    pub no_mob: bool,     // NPCs cannot enter
    pub indoors: bool,    // Weather does not affect room
    pub underwater: bool, // Requires water breathing
}

pub struct ExtraDesc {
    pub keywords: Vec<String>,
    pub description: String,
}

pub enum AreaPermission {
    OwnerOnly,      // Only owner can edit
    Trusted,        // Owner + trusted builders
    AllBuilders,    // Any builder (default)
}

pub struct AreaData {
    pub id: Uuid,
    pub name: String,
    pub prefix: String,
    pub description: String,
    pub level_min: i32,
    pub level_max: i32,
    pub theme: String,
    pub owner: Option<String>,           // Owner character name
    pub permission_level: AreaPermission,
    pub trusted_builders: Vec<String>,   // For Trusted permission level
}

pub struct CharacterData {
    // ...
    pub is_builder: bool,
    pub is_admin: bool,
    pub level: i32,
    pub gold: i32,
}

pub struct ItemData {
    pub id: Uuid,
    pub name: String,
    pub short_desc: String,
    pub long_desc: String,
    pub keywords: Vec<String>,
    pub item_type: ItemType,        // Misc, Armor, Weapon, Container, LiquidContainer, Food, Key
    pub wear_locations: Vec<WearLocation>,
    pub armor_class: Option<i32>,
    pub flags: ItemFlags,
    pub weight: i32,
    pub value: i32,
    pub location: ItemLocation,
    // Weapon fields
    pub damage_dice_count: i32,
    pub damage_dice_sides: i32,
    pub damage_type: DamageType,
    pub two_handed: bool,
    // Container fields
    pub container_contents: Vec<Uuid>,
    pub container_max_items: i32,
    pub container_max_weight: i32,
    pub container_closed: bool,
    pub container_locked: bool,
    pub container_key_id: Option<Uuid>,
    // Liquid container fields
    pub liquid_type: LiquidType,
    pub liquid_current: i32,
    pub liquid_max: i32,
    pub liquid_poisoned: bool,
    pub liquid_effects: Vec<ItemEffect>,
    // Food fields
    pub food_nutrition: i32,
    pub food_poisoned: bool,
    pub food_spoil_duration: i64,
    pub food_created_at: Option<i64>,
    pub food_effects: Vec<ItemEffect>,
    // Level/stats
    pub level_requirement: i32,
    pub stat_str: i32,
    pub stat_dex: i32,
    pub stat_con: i32,
    pub stat_int: i32,
    pub stat_wis: i32,
    pub stat_cha: i32,
    // Prototype fields
    pub is_prototype: bool,
    pub vnum: Option<String>,
}

pub struct ItemFlags {
    pub no_drop: bool,      // Cannot be dropped
    pub no_get: bool,       // Cannot be picked up
    pub no_remove: bool,    // Cannot be removed once worn
    pub invisible: bool,    // Hidden from normal view
    pub glow: bool,         // Emits light
    pub hum: bool,          // Makes humming sound
    pub no_sell: bool,      // Cannot be sold to shops
    pub unique: bool,       // Only one can exist in world
    pub quest_item: bool,   // Special quest item
}

pub struct MobileData {
    pub id: Uuid,
    pub name: String,
    pub short_desc: String,
    pub long_desc: String,
    pub keywords: Vec<String>,
    pub current_room_id: Option<Uuid>,
    pub is_prototype: bool,
    pub vnum: String,
    // Combat stats
    pub level: i32,
    pub max_hp: i32,
    pub current_hp: i32,
    pub damage_dice: String,    // e.g., "2d6+3"
    pub armor_class: i32,
    // Attributes
    pub stat_str: i32,
    pub stat_dex: i32,
    pub stat_con: i32,
    pub stat_int: i32,
    pub stat_wis: i32,
    pub stat_cha: i32,
    // Behavior
    pub flags: MobileFlags,
    pub dialogue: HashMap<String, String>,  // keyword -> response
    // Shop system (requires shopkeeper flag)
    pub shop_stock: Vec<String>,     // Vnums for infinite base stock
    pub shop_inventory: Vec<Uuid>,   // Items bought from players (finite)
    pub shop_buy_rate: i32,          // % paid when buying from player (default 50)
    pub shop_sell_rate: i32,         // % charged when selling (default 150)
}

pub struct MobileFlags {
    pub aggressive: bool,   // Attacks players on sight (future)
    pub sentinel: bool,     // Never wanders from spawn room
    pub scavenger: bool,    // Picks up items from ground (future)
    pub shopkeeper: bool,   // Can buy/sell items
    pub no_attack: bool,    // Cannot be attacked
}

pub enum SpawnEntityType {
    Mobile,
    Item,
}

pub struct SpawnPointData {
    pub id: Uuid,
    pub area_id: Uuid,              // Which area owns this spawn point
    pub room_id: Uuid,              // Where to spawn
    pub entity_type: SpawnEntityType,
    pub vnum: String,               // Prototype vnum to spawn
    pub max_count: i32,             // Maximum instances from this spawn point
    pub respawn_interval_secs: i64, // Seconds between respawn attempts
    pub enabled: bool,
    pub last_spawn_time: i64,       // Unix timestamp of last spawn
    pub spawned_entities: Vec<Uuid>, // Track spawned instance IDs
}
```

### Access Control

Commands in `commands.json` can specify access levels:
- `guest`: Before login only
- `any`: Always available
- `user`: Logged in users
- `builder`: Users with `is_builder = true` (admins also have builder access)
- `admin`: Users with `is_admin = true`

**Admin Utility:**

An external command-line utility is available for offline administration:

```bash
# User management
ironmud-admin user list                         # List all users with permissions
ironmud-admin user grant-admin <name>           # Grant admin privileges
ironmud-admin user revoke-admin <name>          # Revoke admin privileges
ironmud-admin user grant-builder <name>         # Grant builder privileges
ironmud-admin user revoke-builder <name>        # Revoke builder privileges
ironmud-admin user change-password <name>       # Change a user's password
ironmud-admin user require-password-change <name>  # Force password change on next login
ironmud-admin user delete <name>                # Delete a character

# Server settings
ironmud-admin settings list                # List all settings
ironmud-admin settings get <key>           # Get a setting value
ironmud-admin settings set <key> <value>   # Set a setting value
ironmud-admin settings delete <key>        # Delete a setting

# Use custom database path
ironmud-admin -d /path/to/ironmud.db user list
```

### Rhai Functions Available to OLC Scripts

```rhai
// Room operations
create_room(title, description) -> RoomData
get_room_data(room_id) -> RoomData or ()
save_room_data(room)
delete_room(room_id) -> bool
list_all_rooms() -> array of RoomData
set_room_title(room_id, title) -> bool
set_room_description(room_id, description) -> bool
set_room_exit(room_id, direction, target_room_id) -> bool
clear_room_exit(room_id, direction) -> bool
search_rooms(keyword) -> array of RoomData

// Room flags
set_room_flag(room_id, flag_name, value) -> bool
get_room_flag(room_id, flag_name) -> bool

// Extra descriptions
get_room_extra_desc(room_id, keyword) -> string
remove_room_extra_desc(room_id, keyword) -> bool
set_room_extra_desc(room_id, keyword, description) -> bool  // Upsert: updates if exists, adds if not

// Seasonal and dynamic descriptions
set_room_spring_desc(room_id, description) -> bool
set_room_summer_desc(room_id, description) -> bool
set_room_autumn_desc(room_id, description) -> bool
set_room_winter_desc(room_id, description) -> bool
set_room_dynamic_desc(room_id, description) -> bool
clear_room_dynamic_desc(room_id) -> bool
get_current_season() -> string  // "spring", "summer", "autumn", "winter"

// Vnum system
set_room_vnum(room_id, vnum) -> bool
clear_room_vnum(room_id) -> bool
get_room_by_vnum(vnum) -> RoomData or ()
resolve_room_id(identifier) -> string  // UUID or vnum -> UUID

// Door operations
get_door(room_id, direction) -> DoorState or ()
has_door(room_id, direction) -> bool
get_exit_target(room_id, direction) -> string  // target room_id or ""
add_door(room_id, direction, name) -> bool
remove_door(room_id, direction) -> bool
set_door_closed(room_id, direction, closed) -> bool
set_door_locked(room_id, direction, locked) -> bool
set_door_name(room_id, direction, name) -> bool
set_door_description(room_id, direction, description) -> bool
set_door_key(room_id, direction, key_item_id) -> bool
set_door_key_by_vnum(room_id, direction, vnum) -> bool  // Lookup item by vnum
set_door_keywords(room_id, direction, keywords_array) -> bool

// Area operations
create_area(name, prefix) -> AreaData
create_area_with_owner(name, prefix, owner_name) -> AreaData
get_area_data(area_id) -> AreaData or ()
save_area_data(area)
delete_area(area_id) -> bool
list_all_areas() -> array of AreaData
set_room_area(room_id, area_id) -> bool
clear_room_area(room_id) -> bool
get_rooms_in_area(area_id) -> array of RoomData

// Area property setters
set_area_name(area_id, name) -> bool
set_area_description(area_id, desc) -> bool
set_area_prefix(area_id, prefix) -> bool
set_area_theme(area_id, theme) -> bool
set_area_levels(area_id, min, max) -> bool

// Area permissions
set_area_owner(area_id, owner_name) -> bool  // empty string clears owner
set_area_permission(area_id, level) -> bool  // owner_only/trusted/all_builders
add_area_trustee(area_id, char_name) -> bool
remove_area_trustee(area_id, char_name) -> bool
can_edit_area(area_id, char_name) -> bool    // check permission

// Item operations
new_item(name, short_desc, long_desc) -> ItemData
get_item_data(item_id) -> ItemData or ()
save_item_data(item) -> bool
delete_item(item_id) -> bool
list_all_items() -> array of ItemData
search_items(keyword) -> array of ItemData
set_item_name(item_id, name) -> bool
set_item_short_desc(item_id, desc) -> bool
set_item_long_desc(item_id, desc) -> bool
set_item_keywords(item_id, keywords_array) -> bool
set_item_type(item_id, type_str) -> bool
set_item_wear_locations(item_id, locations_array) -> bool
set_item_armor_class(item_id, ac) -> bool
set_item_weight(item_id, weight) -> bool
set_item_value(item_id, value) -> bool
set_item_damage(item_id, dice_count, dice_sides) -> bool
set_item_damage_type(item_id, type_str) -> bool
set_item_two_handed(item_id, two_handed) -> bool

// Item flags
set_item_flag(item_id, flag_name, value) -> bool
get_item_flag(item_id, flag_name) -> bool

// Level and stats
set_item_level_requirement(item_id, level) -> bool
set_item_stat(item_id, stat_name, value) -> bool  // str/dex/con/int/wis/cha

// Container operations
set_container_capacity(item_id, max_items, max_weight) -> bool
set_container_closed(item_id, closed) -> bool
set_container_locked(item_id, locked) -> bool
set_container_key(item_id, key_item_id) -> bool  // empty string clears
get_items_in_container(container_id) -> array of ItemData
add_item_to_container(item_id, container_id) -> bool
remove_item_from_container(item_id) -> bool

// Liquid container operations
set_liquid(item_id, liquid_type, current, max) -> bool
set_liquid_poisoned(item_id, poisoned) -> bool
add_liquid_effect(item_id, effect_type, magnitude, duration) -> bool
clear_liquid_effects(item_id) -> bool
get_all_liquid_types() -> array of strings

// Food operations
set_food_properties(item_id, nutrition, spoil_duration) -> bool
set_food_poisoned(item_id, poisoned) -> bool
set_food_created_at(item_id, timestamp) -> bool  // 0 = now
add_food_effect(item_id, effect_type, magnitude, duration) -> bool
clear_food_effects(item_id) -> bool
consume_food(item_id) -> bool  // deletes item
get_all_effect_types() -> array of strings

// Prototype operations
set_item_prototype(item_id, is_prototype) -> bool
set_item_vnum(item_id, vnum) -> bool  // empty string clears
get_item_by_vnum(vnum) -> ItemData or ()
spawn_item_from_prototype(vnum) -> ItemData or ()

// Item location
move_item_to_room(item_id, room_id) -> bool
move_item_to_inventory(item_id, char_name) -> bool
move_item_to_equipped(item_id, char_name) -> bool
get_items_in_room(room_id) -> array of ItemData
get_inventory_items(char_name) -> array of ItemData
find_item_by_keyword(keyword, items_array) -> ItemData or ()
find_item_in_inventory(char_name, keyword) -> ItemData or ()
find_item_in_room(room_id, keyword) -> ItemData or ()

// Mobile/NPC operations
new_mobile(name) -> MobileData
get_mobile_data(mobile_id) -> MobileData or ()
save_mobile_data(mobile) -> bool
delete_mobile(mobile_id) -> bool
list_all_mobiles() -> array of MobileData
search_mobiles(keyword) -> array of MobileData
get_mobiles_in_room(room_id) -> array of MobileData
get_mobile_by_vnum(vnum) -> MobileData or ()
move_mobile_to_room(mobile_id, room_id) -> bool
spawn_mobile_from_prototype(vnum) -> MobileData or ()
find_mobile_by_keyword(keyword, mobiles_array) -> MobileData or ()

// Mobile property setters
set_mobile_keywords(mobile_id, keywords_array) -> bool
set_mobile_level(mobile_id, level) -> bool
set_mobile_hp(mobile_id, max_hp) -> bool
set_mobile_damage(mobile_id, damage_dice) -> bool
set_mobile_ac(mobile_id, armor_class) -> bool
set_mobile_stat(mobile_id, stat_name, value) -> bool  // str/dex/con/int/wis/cha
set_mobile_flag(mobile_id, flag_name, value) -> bool
set_mobile_vnum(mobile_id, vnum) -> bool
set_mobile_prototype(mobile_id, is_prototype) -> bool

// Mobile dialogue
get_mobile_dialogue(mobile_id, keyword) -> string
set_mobile_dialogue(mobile_id, keyword, response) -> bool
remove_mobile_dialogue(mobile_id, keyword) -> bool
get_all_mobile_dialogues(mobile_id) -> map

// Gold operations
get_character_gold(char_name) -> i64
set_character_gold(char_name, gold) -> bool
add_character_gold(char_name, amount) -> bool  // Returns false if would go negative

// Shop operations
find_shopkeeper_in_room(room_id) -> MobileData or ()
add_shop_stock(mobile_id, vnum) -> bool
remove_shop_stock(mobile_id, vnum) -> bool
get_shop_inventory(mobile_id) -> array of ItemData
add_to_shop_inventory(mobile_id, item_id) -> bool
remove_from_shop_inventory(mobile_id, item_id) -> bool
set_shop_buy_rate(mobile_id, rate) -> bool
set_shop_sell_rate(mobile_id, rate) -> bool
calculate_buy_price(base_value, buy_rate) -> i64  // Price shop pays to player
calculate_sell_price(base_value, sell_rate) -> i64  // Price player pays to shop

// Recipe operations
new_recipe(vnum) -> Recipe
get_recipe(vnum) -> Recipe or ()
save_recipe(recipe) -> bool
delete_recipe(vnum) -> bool
recipe_exists(vnum) -> bool
search_recipes(keyword) -> array of Recipe
get_recipes_by_skill(skill) -> array of Recipe
set_recipe_name(vnum, name) -> bool
set_recipe_skill(vnum, skill) -> bool  // cooking/crafting
set_recipe_level(vnum, level) -> bool  // 0-10
set_recipe_autolearn(vnum, autolearn) -> bool
set_recipe_difficulty(vnum, difficulty) -> bool  // 1-10
set_recipe_xp(vnum, xp) -> bool
set_recipe_output(vnum, output_vnum, quantity) -> bool
add_recipe_ingredient(vnum, item_spec, quantity) -> bool  // item_spec: vnum or @category
remove_recipe_ingredient(vnum, index) -> bool
add_recipe_tool(vnum, item_spec, location) -> bool  // location: inventory/room/either
remove_recipe_tool(vnum, index) -> bool
rename_recipe_vnum(old_vnum, new_vnum) -> bool  // Change recipe vnum

// OLC mode (for line editor input)
set_olc_mode(connection_id, mode)
get_olc_mode(connection_id) -> string
set_olc_edit_room(connection_id, room_id)
get_olc_edit_room(connection_id) -> string
set_olc_buffer(connection_id, lines_array)  // Pre-populate buffer
append_olc_buffer(connection_id, line)
get_olc_buffer(connection_id) -> array
clear_olc_buffer(connection_id)
set_olc_extra_keywords(connection_id, keywords)

// Builder and admin management
set_builder_flag(character_name, is_builder) -> bool
set_admin_flag(character_name, is_admin) -> bool

// Server settings
get_setting(key) -> string  // Empty if not set
get_setting_or_default(key, default) -> string
set_setting(key, value) -> bool

// Character counting
count_characters() -> i64  // Total characters in database

// Spawn point operations
create_spawn_point(area_id, room_id, entity_type, vnum, max_count, interval_secs) -> SpawnPointData or ()
get_spawn_point(spawn_point_id) -> SpawnPointData or ()
delete_spawn_point(spawn_point_id) -> bool
list_spawn_points_in_area(area_id) -> array of SpawnPointData
set_spawn_point_enabled(spawn_point_id, enabled) -> bool
set_spawn_point_max_count(spawn_point_id, max_count) -> bool
set_spawn_point_interval(spawn_point_id, interval_secs) -> bool
trigger_area_reset(area_id) -> int  // Returns count of spawned entities
get_item_by_vnum(vnum) -> ItemData or ()

// MXP (clickable links)
is_mxp_enabled(connection_id) -> bool
set_mxp_enabled(connection_id, enabled) -> bool
mxp_send(command, display) -> string  // Generate <send> tag
mxp_menu(commands_array, hints_array, display) -> string  // Popup menu
mxp_or(mxp_text, plain_text, connection_id) -> string  // Conditional
send_mxp_message(connection_id, message)  // Send with MXP prefix
strip_mxp_tags(text) -> string  // Remove MXP tags
```
